# from deepspeed.runtime.zero.stage3 import estimate_zero3_model_states_mem_needs_all_cold

# estimate_zero3_model_states_mem_needs_all_cold(2851e6, 32e6, num_gpus_per_node=8)


from transformers import AutoModel
from deepspeed.runtime.zero.stage3 import estimate_zero3_model_states_mem_needs_all_live


model = AutoModel.from_pretrained('t5-11b')
estimate_zero3_model_states_mem_needs_all_live(model, num_gpus_per_node=8)
