# --------------------------------------------------------
# [Text Classification Training Pipeline]
# Copyright (c) 2022 Moffett.AI
# Licensed under Moffett.AI
# Written by CW
# --------------------------------------------------------

"""
    Finetuning a model for question answering task(mainly on SQUAD).
    Run tips:
    i.   Run: accelerate config
    ii.  Reply the questions in order to setup your configuration
    iii. Run this script like:

    OMP_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false MPLBACKEND='Agg' \
        accelerate launch run_qa.py --config [CONFIG_FILE]
"""

import os
import math
import time
import argparse
import datetime

from torch.optim import optimizer

from accelerate import Accelerator, DistributedType
from transformers.utils.versions import require_version


require_version("datasets>=1.8.0", 
                "To fix: pip install -r examples/pytorch/text-classification/requirements.txt")

import sys

BASE_DIR = os.path.dirname(__file__)
sys.path.append(os.path.join(BASE_DIR, '..'))

from utils.seed import setup_seed
from utils.logger import build_logger
from utils.dist import init_accelerator, kill_all_process
from utils.misc import is_seq_of, load_checkpoint

from models.builder import build_model
from data.builder import build_data_container

from engine.pruner import build_pruner
from engine.trainer import build_trainer

from engine.optim.optimizer import build_optimizer
from engine.optim.lr_scheduler import build_lr_scheduler

from config.cfg import get_config_from_args


def parse_args():
    parser = argparse.ArgumentParser(
        description="Finetune a model on a question answering task"
    )
    parser.add_argument('--config', type=str, default=None, help='path to config file(yaml or py)')
    parser.add_argument('--epochs', type=int, help='training epochs')
    parser.add_argument('--prune', action='store_true', help='do pruning')
    parser.add_argument('--kd', action='store_true', help='do knowledge distillation')
    parser.add_argument('--debug', action='store_true', help='turn on debug mode')

    return parser.parse_args()


if __name__ == '__main__':
    '''i. Parse arguments & Update configs'''
    args = parse_args()
    cfg = get_config_from_args(args)

    '''ii. Set logger'''
    logger = build_logger(cfg)

    '''iii. Initialize the accelerator'''
    # We will let the accelerator handle device placement for us in this example.
    accelerator = Accelerator()
    # We only want one process per machine to log things on the screen.
    init_accelerator(accelerator)

    '''iv. Fix random seed'''
    setup_seed(cfg.seed)

    logger.info(f"\nProcess id: {os.getpid()}\nRandom seed: {cfg.seed}\n{accelerator.state}")
    accelerator.wait_for_everyone()

    '''v. Load dataset'''
    s = time.time()
    qa_container = build_data_container(
        cfg.data,
        default_args=dict(
            train_batch_size=cfg.train.batch_size,
            val_batch_size=cfg.val.batch_size,
            use_fp16=accelerator.use_fp16,
            seed=cfg.seed,
            rank=cfg.local_rank,
            logger=logger,
            debug=cfg.debug
        )
    )
    used = time.time() - s
    logger.info(f"=> Load data takes time:{datetime.timedelta(seconds=used)}\n")

    '''vi. Build model and tokenizer'''
    # In distributed training, the 'from_pretrained' methods guarantee that 
    # only one local process can concurrently download model & vocab.
    tokenizer, model, teacher = build_model(cfg.model, default_args=dict(logger=logger, kd=cfg.trainer.kd))

    '''vii. Preprocess dataset then feed in dataloader'''
    s = time.time()
    features = qa_container.gen_features(model, tokenizer, accelerator=accelerator)
    dataloaders = qa_container.get_dataloaders(tokenizer=tokenizer)
    train_dataloader, val_dataloader, test_dataloader = dataloaders['train'], dataloaders['validation'], dataloaders['test']
    used = time.time() - s
    logger.info(f"=> Process data takes time:{datetime.timedelta(seconds=used)}\n")

    '''viii. Build optimizer & lr_scheduler'''
    # Linear scale the learning rate according to total batch size
    if cfg.train.linear_scaled_lr:
        cfg.defrost()

        scaled = (cfg.train.batch_size * accelerator.num_processes / cfg.train.base_batch_size) / math.sqrt(2.)
        cfg.train.lr *= scaled
        cfg.train.min_lr *= scaled
        cfg.train.warmup_lr *= scaled

        cfg.freeze()

    optimizer = build_optimizer(model, cfg)
    logger.info(f"=> Build optimizer: {str(optimizer)}\n")
    if cfg.optimizer.type == 'child_tuning_adamw' and cfg.optimizer.mode == 'D':
        optimizer.set_grad_mask(model=model, dataloader=train_dataloader, max_grad_norm=1.)

    # In multi-process, each will get its own individual data
    # (cuz the length of dataloader would be shorter than the original)
    model, optimizer, train_dataloader, val_dataloader = accelerator.prepare(
        model, optimizer, train_dataloader, val_dataloader
    )
    if teacher is not None:
        teacher = accelerator.prepare_model(teacher)
    
    # Note: Don't forget to refresh dataloaders in data container!
    qa_container.dataloaders.update(train=train_dataloader, validation=val_dataloader)
    if test_dataloader is not None:
        test_loader = accelerator.prepare(test_dataloader)
        qa_container.dataloaders.update(test=test_dataloader)

    # Note: this 'num_train_steps' considers gradient accumulation
    # this is the frequency that lr scheduler updates
    lr_scheduler, num_update_steps = build_lr_scheduler(optimizer, cfg, len(train_dataloader))

    '''ix. Auto resume(optional)'''
    if cfg.train.auto_resume:
        if cfg.resume_path is not None:
            logger.info(f"=> Auto resuming from '{cfg.resume_path}'..\t")
            # Dict: metric type -> metric value
            best_val_results = load_checkpoint(
                accelerator.unwrap_model(model), accelerator.unwrap_model(optimizer), 
                lr_scheduler, cfg, logger
            )
            num_update_steps = (cfg.trainer.epochs - cfg.trainer.start_epoch) * \
                math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps)
            logger.info(
                f"Done!\n"
                f"[Start Epoch]:{cfg.trainer.start_epoch}\t"
                f"[Lr]:{optimizer.param_groups[0]['lr']}\t[Metric]:{best_val_results}\n"
            )
        else:
            logger.warning(f"=> No checkpoint found in '{cfg.output}', ignoring auto resume\n")

    '''x. Pruner setting'''
    if cfg.train.prune and not cfg.pruner.sparse_step:
        cfg.defrost()
        cfg.pruner.sparse_step = num_update_steps
        cfg.freeze()

    pruner = build_pruner(
        cfg.pruner, 
        default_args=dict(
            prune=cfg.train.prune,
            model=model,
            model_name=cfg.model.name,
            logger=logger
        )
    )

    # Log config
    logger.info(f"\n[Config]\n{cfg.dump()}\n")

    # Log Training info
    # Note: these samples are tokenized data(i.e. features), may more than raw data.
    num_train_samples = len(train_dataloader.dataset)
    num_val_samples = len(val_dataloader.dataset)
    num_test_samples = len(test_dataloader.dataset) if test_dataloader is not None else 0
    num_epochs = cfg.trainer.epochs - cfg.trainer.start_epoch
    num_train_steps = num_epochs * len(train_dataloader)
    total_train_batch_size = cfg.train.batch_size * accelerator.num_processes * cfg.trainer.grad_accumulation_steps
    
    logger.info("***** Start Training *****")
    logger.info(f"  Num train samples = {num_train_samples}")
    logger.info(f"  Num val samples = {num_val_samples}")
    logger.info(f"  Num test samples = {num_test_samples}")
    logger.info(f"  Num epochs = {num_epochs}")
    logger.info(f"  Num train steps = {num_train_steps}")
    logger.info(f"  Num update steps = {num_update_steps}")
    logger.info(f"  Num gradient Accumulation steps = {cfg.trainer.grad_accumulation_steps}")
    logger.info(f"  Train batch size per device = {cfg.train.batch_size}")
    logger.info(f"  Total train batch size (batch size per device x num devices x gradient accumulation steps) = {total_train_batch_size}\n")

    '''xi. Training'''
    accelerator.wait_for_everyone()

    trainer = build_trainer(
        cfg.trainer, 
        default_args=dict(
            model=model, optimizer=optimizer, lr_scheduler=lr_scheduler,
            teacher=teacher, logger=logger, output_dir=logger.log_dir
        )
    )
    if cfg.get('data_container_to_trainer'):
        args_key = cfg.data_container_to_trainer
        if isinstance(args_key, str):
            args_key = [args_key]
        assert is_seq_of(args_key, str)

        cfg.trainer_fit_args.update({
            key: getattr(qa_container, key) for key in args_key if hasattr(qa_container, key)
        })
    logger.info(f"\n[Trainer fit args]\n{cfg.trainer_fit_args.dump()}\n")
    trainer.fit(accelerator, qa_container, pruner=pruner, **cfg.trainer_fit_args)

    # Release all references to the internal objects stored and call the garbage collector
    accelerator.free_memory()
    if accelerator.distributed_type == DistributedType.MULTI_GPU:
        # Destroy all processes, and de-initialize the distributed package
        kill_all_process()
