import torch
import numpy as np

from transformers import AutoConfig, AutoModelForSeq2SeqLM
from deepspeed.utils.zero_to_fp32 import load_state_dict_from_zero_checkpoint

import os

BASE = os.path.dirname(__file__)
ROOT = os.path.join(BASE, '..')


def get_max_prune_rate(in_channel):
    if in_channel <= 8:
        return 0.0
    elif in_channel <= 16:
        return 1 / 2
    elif in_channel <= 32:
        return 3 / 4
    elif in_channel <= 64:
        return 7 / 8
    else:
        return 1.0


def generate_prune_dict(model, model_name, sparsity):
    prune_dict = {}
    for name, parameter in model.named_parameters():
        # DeBERTa
        if 'deberta' in model_name.lower():
            # FFN
            if ('intermediate.dense.weight' in name or 'output.dense.weight' in name) \
                and ('attention' not in name):
                prune_dict[name] = sparsity
            # Attention
            # Optional: prune all kind of attentions(i.e. pos_proj, pos_q_proj)
            # if 'attention.self.in_proj.weight' in name or 'attention.self.pos_proj.weight' in name \
            #     or 'attention.self.pos_q_proj.weight' in name or 'attention.output.dense.weight' in name:
            if 'attention.self.in_proj.weight' in name or 'attention.output.dense.weight' in name:
                prune_dict[name] = sparsity
        # Bert
        elif 'bert' in model_name.lower():
            # FFN
            if ('intermediate.dense.weight' in name or 'output.dense.weight' in name) \
                and ('attention' not in name):
                prune_dict[name] = sparsity
            # Attention
            if 'attention.self.query.weight' in name or 'attention.self.key.weight' in name or \
                'attention.self.value.weight' in name or 'attention.output.dense.weight' in name:
                prune_dict[name] = sparsity
        # T5
        elif 't5' in model_name.lower():
            # FFN
            if 'DenseReluDense' in name:
                sub_module = ['wi', 'wo']
                for mod_name in sub_module:
                    if f'DenseReluDense.{mod_name}.weight' in name:
                        prune_dict[name] = sparsity
            # Attention
            if 'SelfAttention' in name or 'EncDecAttention' in name:
                sub_module = ['q', 'k', 'v', 'o']
                for mod_name in sub_module:
                    if f'Attention.{mod_name}.weight' in name:
                        prune_dict[name] = sparsity
        # Other cases
        else:
            if 'weight' in name and len(parameter.shape)>=2:
                if len(parameter.shape)==4:
                    if list(parameter.shape)[2:] == [1, 1]:
                        max_prune_rate = get_max_prune_rate(list(parameter.shape)[1])
                    else:
                        max_prune_rate = 1.0
                else:
                    max_prune_rate = 0.75
            prune_dict[name] = min(sparsity, max_prune_rate)

    return prune_dict


def get_model_sparsity(model, prune_dict, eps=0.):
    # total_param = 0
    # total_nonezero = 0
    # layer_sparse_rate = {}

    # for name, parameter in model.named_parameters():
    #     if any(name == one for one in prune_dict):
    #         temp = parameter.data.cpu().numpy()
    #         total_param = total_param + temp.size
    #         total_nonezero = total_nonezero + np.flatnonzero(temp).size
    #         layer_sparse_rate[name] = 1 - np.flatnonzero(temp).size / temp.size
    
    # total_sparse_rate = 1 - total_nonezero / total_param
    # return layer_sparse_rate, total_sparse_rate

    total_params = total_zeros = 0
    layer_sparsity = {}.fromkeys(prune_dict.keys(), 0.)

    for n, p in filter(lambda np: np[0] in prune_dict, model.named_parameters()):
        num_ele = torch.numel(p)
        num_zero = (p.abs() <= eps).sum().item()
        layer_sparsity[n] = num_zero / num_ele
        print(f"update sparsity of param:{n}")

        total_params += num_ele
        total_zeros += num_zero
    total_sparsity = total_zeros / total_params

    return layer_sparsity, total_sparsity


if __name__ == '__main__':
    pretrained_id = 't5-large'

    model_config_path = os.path.join(ROOT, f'models/hf_local/{pretrained_id}/config.json')
    model_config = AutoConfig.from_pretrained(model_config_path)
    
    # ckpt_dir = os.path.join(ROOT, 'model_cards/t5')
    # tag = 'Eval-ep1-bs4-lr8e-05-avg81.667-exact_match80.000-f183.333'
    
    ckpt_path = os.path.join(
        ROOT,
        "scripts/test/output/t5-large/squad/ep1-lr8e-05-optimizeradamw-schedulerlinear/pruneTrue-pfreq1-sparsity0.5/04-09-18-06/prune/sparsity0.5_best.pth"
    )
    state_dict = torch.load(ckpt_path, map_location='cpu')
    model_state_dict = state_dict.get('model')
    if model_state_dict is None:
        model_state_dict = state_dict

    model = AutoModelForSeq2SeqLM.from_pretrained(pretrained_id, config=model_config)
    # model = load_state_dict_from_zero_checkpoint(model, ckpt_dir, tag=tag)
    model.load_state_dict(model_state_dict, strict=True)

    min_param = np.inf
    for p in model.parameters():
        min_p = p.abs().min().item()
        min_param = min(min_param, min_p)
    print(f"min param value:{min_param}\n")
    
    sparsity = 0.5
    prune_dict = generate_prune_dict(model, pretrained_id, sparsity)
    print(prune_dict)

    layer_sparsity, total_sparsity = get_model_sparsity(model, prune_dict, eps=0.)
    print(f"\n[Sparsity Info]\n\nLayer:\n{layer_sparsity}\n\nTotal:{total_sparsity}")
