from transformers import AutoTokenizer

# import os

# BASE = os.path.dirname(__file__)
# ROOT = os.path.join(BASE, '..')


if __name__ == '__main__':
    # model_pretrained_id = 't5-3b'
    # tokenizer_dir = f'models/hf_local/{model_pretrained_id}/'
    
    # full_tokenizer_path = os.path.join(ROOT, tokenizer_dir)
    # if not os.path.exists(full_tokenizer_path):
    #     raise FileNotFoundError(f"tokenzier config dir:'{full_tokenizer_path}' mot found.")
    
    # tokenizer = AutoTokenizer.from_pretrained(full_tokenizer_path, use_fast=False)
    # print(tokenizer)

    pretrained_id = 't5-base'
    tokenizer = AutoTokenizer.from_pretrained(pretrained_id)
    
    input_ids = [3, 51, 29, 40, 23, 3, 17398, 10]
    decoded = tokenizer.batch_decode(input_ids)
    print(decoded)
