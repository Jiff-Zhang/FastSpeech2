import random

import torch
import numpy as np

from tqdm import tqdm
from itertools import chain, cycle
from functools import partial
from bisect import bisect_right
from typing import Dict, Iterable, List

from datasets import load_dataset
from dataclasses import dataclass

from torch.utils.data.dataloader import DataLoader

# from transformers import PretrainedConfig, AutoConfig, AutoModelForSequenceClassification
from transformers import AutoTokenizer, BatchEncoding, PreTrainedTokenizerBase
from transformers.models.t5.modeling_t5 import T5ForConditionalGeneration

import os

BASE = os.path.dirname(__file__)
ROOT = os.path.join(BASE, '..')

import sys
sys.path.append(ROOT)


def compute_inputs_and_targets_len(inputs_len, noise_density, mean_noise_span_len):
    """
    Refer to: <https://github.com/google-research/text-to-text-transfer-transformer/blob/84f8bcc14b5f2c03de51bd3587609ba8f6bbd1cd/t5/data/preprocessors.py#L2466>
    
    We assume that each noise span in the input is replaced by extra_tokens_per_span_inputs sentinel tokens,
    and each non-noise span in the targets is replaced by extra_tokens_per_span_targets sentinel tokens.
    This function tells us the required number of tokens in the raw example (for split_tokens())
    as well as the length of the encoded targets. Note that this function assumes
    the inputs and targets will have EOS appended and includes that in the reported length.

    Args:
        inputs_len (int): desired length of the tokenized input tokens.
        noise_density (float): ratio of tokens to mask for span masked language modeling loss.
        mean_noise_span_len (float): mean span length of masked tokens.
    """

    def _tokens_len_to_inputs_and_targets_len(tokens_len):
        num_noise_tokens = int(round(tokens_len * noise_density))
        num_non_noise_tokens = tokens_len - num_noise_tokens
        num_noise_spans = int(round(num_noise_tokens / mean_noise_span_len))

        # Inputs contain all non-noise tokens, sentinels for all noise spans and one EOS token.
        _inputs_len = num_non_noise_tokens + num_noise_spans + 1
        # Targets contain all noise tokens, sentinels for all noise spans and one EOS token.
        _targets_len = num_noise_tokens + num_noise_spans + 1

        return _inputs_len, _targets_len
    
    expected_tokens_len = inputs_len
    expected_inputs_len, _ = _tokens_len_to_inputs_and_targets_len(expected_tokens_len + 1)
    while expected_inputs_len <= inputs_len:
        expected_tokens_len += 1
        expected_inputs_len, _ = _tokens_len_to_inputs_and_targets_len(expected_tokens_len + 1)
    
    inputs_len, targets_len = _tokens_len_to_inputs_and_targets_len(expected_tokens_len)
    # Minor hack to get the targets length to be equal to inputs length
    # which is more likely to have been set to a nice round number.
    if noise_density == .5 and targets_len > inputs_len:
        targets_len -= 1
        expected_tokens_len -= 1
    
    return expected_tokens_len, targets_len


def gen_features(examples, tokenizer, expanded_inputs_len, text_column_name='text'):
    tokenized_examples = tokenizer(examples[text_column_name], return_attention_mask=False)

    # Concatenate all texts from dataset and generate chunks of expanded_inputs_length.
    concated_examples = {k: list(chain(*tokenized_examples[k])) for k in tokenized_examples.keys()}
    
    total_texts_len = len(concated_examples[list(tokenized_examples.keys())[0]])
    if total_texts_len >= expanded_inputs_len:
        total_texts_len = (total_texts_len // expanded_inputs_len) * expanded_inputs_len
    
    # Split by chunks of max_len
    features = {
        k: [v[i:i + expanded_inputs_len] for i in range(0, total_texts_len, expanded_inputs_len)]
        for k, v in concated_examples.items()
    }
    return features


@dataclass
class DataCollatorForSpanMaksedLanguageModeling:
    """
    Data collator used for T5 span-masked language modeling.
    It is made sure that after masking the inputs are of length `data_args.max_seq_length` and targets are also of fixed length.
    For more information on how T5 span-masked language modeling works, one can take a look
    at the `official paper <https://arxiv.org/pdf/1910.10683.pdf>`__
    or the `official code for preprocessing <https://github.com/google-research/text-to-text-transfer-transformer/blob/master/t5/data/preprocessors.py>`__ .
    
    Args:
        tokenizer (:class:`~transformers.PreTrainedTokenizer` or :class:`~transformers.PreTrainedTokenizerFast`):
            The tokenizer used for encoding the data.
        noise_density (:obj:`float`):
            The probability with which to (randomly) mask tokens in the input.
        mean_noise_span_len (:obj:`float`):
            The average span length of the masked tokens.
        input_length (:obj:`int`):
            The expected input length after masking.
        target_length (:obj:`int`):
            The expected target length after masking.
        pad_token_id: (:obj:`int`):
            The pad token id of the model
        decoder_start_token_id: (:obj:`int):
            The decoder start token id of the model
    """

    tokenizer: PreTrainedTokenizerBase

    noise_density: float
    mean_noise_span_len: float

    input_length: int
    target_length: int

    pad_token_id: int
    decoder_start_token_id: int

    return_tensors: bool
    prepend_batch_axis: bool

    def __call__(self, examples: List[Dict[str, np.ndarray]]) -> Dict[str, np.ndarray]:
        # Convert list to dict and tensorize input
        batch = BatchEncoding({
            k: np.array([examples[i][k] for i in range(len(examples))])
            for k in examples[0].keys()
        })

        input_ids = batch['input_ids']
        batch_size, expanded_inputs_len = input_ids.shape

        # Bool type, True for masked tokens, False for other input tokens
        noise_masks = np.asarray([self._create_noise_mask(expanded_inputs_len) for _ in range(batch_size)])
        # Labels are those masked input tokens, so the 'label_masks' is reversed 'noise_masks'
        label_masks = ~noise_masks

        input_ids_sentinel = self._create_sentinel_ids(noise_masks.astype(np.int8))
        labels_sentinel = self._create_sentinel_ids(label_masks.astype(np.int8))

        batch['input_ids'] = self._filter_input_ids(input_ids, input_ids_sentinel)
        assert batch['input_ids'].shape[-1] == self.input_length, \
            f"`input_ids` are incorrectly preprocessed. `input_ids` length is {batch['input_ids'].shape[-1]}, but should be {self.target_length}."
        batch['labels'] = self._filter_input_ids(input_ids, labels_sentinel)
        assert batch['labels'].shape[-1] == self.target_length, \
            f"`labels` are incorrectly preprocessed. `labels` length is {batch['labels'].shape[-1]}, but should be {self.target_length}."

        # Note: to check that tokens are correctly preprocessed, u can run 
        # `self.tokenizer.batch_decode(input_ids)` and `self.tokenizer.batch_decode(labels)` here.
        batch['decoder_input_ids'] = self._shift_tokens_right(batch['labels'], self.pad_token_id, self.decoder_start_token_id)
        
        if self.return_tensors:
            batch = self._convert_to_tensors(batch)

        return batch

    def _create_noise_mask(self, seq_len: int) -> np.ndarray:
        """
        This function is copy of `random_spans_helper <https://github.com/google-research/text-to-text-transfer-transformer/blob/84f8bcc14b5f2c03de51bd3587609ba8f6bbd1cd/t5/data/preprocessors.py#L2682>`__ .
        
        Noise mask consisting of random spans of noise tokens.
        The number of noise tokens and the number of noise spans and non-noise spans
        are determined deterministically as follows:
            
            num_noise_tokens = round(length * noise_density)
            num_non_noise_spans = num_noise_spans = round(num_noise_tokens / mean_noise_span_len)

        Spans alternate between non-noise and noise, beginning with non-noise.
        Subject to the above restrictions, all masks are equally likely.
        
        Args:
            seq_len (int): length of the in-coming token sequence
            noise_density (float): approximate density of output mask
            mean_noise_span_len (float): the average span length of the masked tokens.
        
        Returns:
            a boolean array with shape (seq_len,)
        """

        # Avoid degeneracy by ensuring positive numbers of noise and nonnoise tokens.
        num_noise_tokens = min(
            max(int(round(self.noise_density * seq_len)), 1),
            seq_len - 1
        )
        num_non_noise_tokens = seq_len - num_noise_tokens
        # Avoid degeneracy by ensuring positive numbers of noise and nonnoise tokens.
        num_noise_spans = max(int(round(num_noise_tokens / self.mean_noise_span_len)), 1)

        def _random_segment(num_items, num_segments):
            """
            Partition a sequence of items randomly into non-empty segments.
            
            Args:
                num_items: an integer scalar > 0
                num_segments: an integer scalar in [1, num_items]
            
            Returns:
                a Tensor with shape [num_segments] containing positive integers that add
                up to num_items
            """

            # Mark the count of segments to: x, so x segments only need (x-1) segment indicator.
            # and because we will insert a item to make the segment id start with 0(see below),
            # the range should be 'num_items' - 1 (instead of num_items).
            mask = np.arange(num_items - 1) < num_segments - 1
            np.random.shuffle(mask)
            # Pad 1 zero-value to the head, in order to make the 'segment_id' start with 0
            mask = np.pad(mask, (1, 0))

            # Those positions with same ids belong to a common segment.
            segment_ids = np.cumsum(mask)
            # Count length of sub segments assuming that list is sorted
            _, segments_len = np.unique(segment_ids, return_counts=True)

            return segments_len

        # Pick the lengths of the noise spans and the non-noise spans
        noise_span_lens = _random_segment(num_noise_tokens, num_noise_spans)
        non_noise_span_lens = _random_segment(num_non_noise_tokens, num_noise_spans)
        
        # Spans alternate between non-noise and noise, beginning with non-noise.
        interleaved_span_lens = np.reshape(
            np.stack([non_noise_span_lens, noise_span_lens], axis=-1),
            (num_noise_spans * 2,)
        )
        # The last span start position is indicated by the 2nd last
        spans_start = np.cumsum(interleaved_span_lens)[:-1]
        
        spans_start_indicator = np.zeros((seq_len,), dtype=np.int8)
        spans_start_indicator[spans_start] = 1

        span_ids = np.cumsum(spans_start_indicator)
        # 0 for non-noise & 1 for noise
        # Let odd position be the noise since we beginning with non-noise spans(see above),
        # this ensure that masked positions belong to noise tokens.
        is_noise = (span_ids % 2).astype(bool)

        return is_noise[:seq_len]

    def _create_sentinel_ids(self, mask):
        """
        Sentinel ids creation given the indices that should be masked.
        The start indices of each mask are replaced by the sentinel ids in increasing order. 
        Consecutive mask indices to be deleted are replaced with `-1`.
        """

        # Only the start position of each span will be kept
        start_indicators = mask * (1 - np.roll(mask, 1, axis=-1))
        start_indicators[:, 0] = mask[:, 0]

        sentinel_ids = np.where(start_indicators != 0, np.cumsum(start_indicators, axis=-1), 0)
        sentinel_ids = np.where(start_indicators != 0, len(self.tokenizer) - sentinel_ids, 0)
        
        # Masked positions with start position excluded of each masked span(1 for these postions)
        masked_exclude_each_start = mask - start_indicators
        # So the value of masked positions with start position excluded of each span will be replaced by -1
        sentinel_ids -= masked_exclude_each_start

        return sentinel_ids

    def _filter_input_ids(self, input_ids, sentinel_ids):
        """
        Puts sentinel mask on `input_ids` and fuse consecutive mask tokens into a single mask token by deleting.
        This will reduce the sequence length from `expanded_inputs_length` to `input_length`.
        """

        batch_size = input_ids.shape[0]

        # 'sentinel_ids == 0' are those postions of non-masked tokens.
        input_ids_w_sentinel = np.where(sentinel_ids == 0, input_ids, sentinel_ids)
        # Filter out those masked tokens(which indicated by value -1)
        input_ids_wo_masked_tokens = input_ids_w_sentinel[input_ids_w_sentinel >= 0].reshape((batch_size, -1))

        # Append eos token
        filtered_input_ids = np.concatenate(
            [
                input_ids_wo_masked_tokens,
                np.full((batch_size, 1), self.tokenizer.eos_token_id, dtype=np.int32)
            ],
            axis=-1
        )
        return filtered_input_ids

    def _shift_tokens_right(self, input_ids: np.array, pad_token_id: int, decoder_start_token_id: int) -> np.ndarray:
        """
        Shift input ids one token to the right.
        """

        shifted_input_ids = np.zeros_like(input_ids)
        shifted_input_ids[:, 1:] = input_ids[:, :-1]
        
        shifted_input_ids[:, 0] = decoder_start_token_id
        shifted_input_ids = np.where(shifted_input_ids == -100, pad_token_id, shifted_input_ids)

        return shifted_input_ids
    
    def _convert_to_tensors(self, items):
        """
        Convert the inner content to tensors.

        Args:
            tensor_type (`str` or [`~file_utils.TensorType`], *optional*):
                The type of tensors to use. If `str`, should be one of the values of the enum
                [`~file_utils.TensorType`]. If `None`, no modification is done.
            prepend_batch_axis (`int`, *optional*, defaults to `False`):
                Whether or not to add the batch dimension during the conversion.
        """

        # Do the tensor conversion in batch
        for key, value in items.items():
            try:
                if self.prepend_batch_axis:
                    value = [value]
                if not torch.is_tensor(value):
                    items[key] = torch.tensor(value)
            except:  # noqa E722
                if key == "overflowing_tokens":
                    raise ValueError(
                        "Unable to create tensor returning overflowing tokens of different lengths. "
                        "Please see if a fast version of this tokenizer is available to have this feature available."
                    )
                raise ValueError(
                    "Unable to create tensor, you should probably activate truncation and/or padding "
                    "with 'padding=True' 'truncation=True' to have batched tensors with the same length."
                )

        return items


if __name__ == '__main__':
    pretrained_id = 't5-base'

    model = T5ForConditionalGeneration.from_pretrained(pretrained_id)
    model.eval()

    tokenizer = AutoTokenizer.from_pretrained(pretrained_id, use_fast=True)
    print(f"tokenizer len: {len(tokenizer)}\n")

    max_seq_length = 128  # tokenizer.model_max_length

    mlm_prob = 0.15
    mean_noise_span_len = 3.

    # T5-like span masked language modeling will fuse consecutively masked tokens to a single sentinel token.
    # To ensure that the input length is `max_seq_length`, we need to increase the maximum length
    # according to `mlm_probability` and `mean_noise_span_length`. We can also define the label length accordingly.
    expanded_inputs_len, targets_len = compute_inputs_and_targets_len(max_seq_length, mlm_prob, mean_noise_span_len)
    num_noise_tokens = int(round(expanded_inputs_len * mlm_prob))
    num_noise_spans = int(round(num_noise_tokens / mean_noise_span_len))
    print(
        f"inputs len: {max_seq_length}\nexpanded inputs len: {expanded_inputs_len}\n"
        f"targets len: {targets_len}\nnum noise tokens: {num_noise_tokens}\n"
        f"num noise spans: {num_noise_spans}\n"
    )

    data_collator = DataCollatorForSpanMaksedLanguageModeling(
        tokenizer=tokenizer,
        noise_density=mlm_prob,
        mean_noise_span_len=mean_noise_span_len,
        input_length=max_seq_length,
        target_length=targets_len,
        pad_token_id=model.config.pad_token_id,
        decoder_start_token_id=model.config.decoder_start_token_id,
        return_tensors=True,
        prepend_batch_axis=False
    )

    root_dir = '/ssd1/datasets/realnewslike'
    fmt = 'json'

    data_files_a = os.path.join(root_dir, 'train', 'c4-train.00021-of-00512.json')
    dataset_dict_a = load_dataset(fmt, data_files={'train': data_files_a})
    print(dataset_dict_a)

    data_files_b = os.path.join(root_dir, 'val', 'c4-train.00239-of-00512.json')
    dataset_dict_b = load_dataset(fmt, data_files={'train': data_files_b})
    print(dataset_dict_b)

    features_a = dataset_dict_a.map(
        partial(gen_features, tokenizer=tokenizer, expanded_inputs_len=expanded_inputs_len),
        num_proc=4,
        batched=True,
        load_from_cache_file=True,
        remove_columns=dataset_dict_a['train'].column_names
    )['train']
    dataloader_a = DataLoader(
        features_a, batch_size=32, shuffle=True,
        num_workers=4, pin_memory=True, collate_fn=data_collator
    )
    print(f"dataloader_a len = {len(dataloader_a)}")

    features_b = dataset_dict_b.map(
        partial(gen_features, tokenizer=tokenizer, expanded_inputs_len=expanded_inputs_len),
        num_proc=4,
        batched=True,
        load_from_cache_file=True,
        remove_columns=dataset_dict_b['train'].column_names
    )['train']
    dataloader_b = DataLoader(
        features_b, batch_size=32, shuffle=True,
        num_workers=4, pin_memory=True, collate_fn=data_collator
    )
    print(f"dataloader_b len = {len(dataloader_b)}")

    dataloader_list = [dataloader_a, dataloader_b]
    
    max_idx = 0
    max_dataloader_len = len(dataloader_a)
    for i, dataloader in enumerate(dataloader_list[1:]):
        if len(dataloader) > max_dataloader_len:
            max_idx = i
            max_dataloader_len = len(dataloader)

    max_len_dataloader = dataloader_list.pop(max_idx)
    dataloader_list = [cycle(dataloader) for dataloader in dataloader_list]
    dataloader_list.append(max_len_dataloader)

    for epoch in range(1, 3):
        print(f"Epoch[{epoch}]")
        for batch_idx, batch in enumerate(tqdm(iter(zip(*dataloader_list)), desc='Checking batches')):
            concat_batch_dict = {}
            for k in batch[0].keys():
                concat_batch_size = sum(sub_batch[k].size(0) for sub_batch in batch)
                concat_batch = torch.zeros(
                    (concat_batch_size,) + batch[0][k].shape[1:],
                    dtype=batch[0][k].dtype, device=batch[0][k].device
                )

                random_indices = torch.randperm(concat_batch_size, device=concat_batch.device)
                concat_batch[random_indices] = torch.cat(tuple(sub_batch[k] for sub_batch in batch))

                concat_batch_dict[k] = concat_batch 

            if not batch_idx:
                print(f"concat batch size = {concat_batch_size}, concat batch dict:\n{concat_batch_dict}")
    