import os
import sys


BASE = os.path.dirname(__file__)
sys.path.append(os.path.join(BASE, '..'))

from config.cfg import load_config
from data import build_data_container


if __name__ == '__main__':
    cfg_file = 'data/image_classification.yaml'
    cfg = load_config(cfg_file)
    
    data_container = build_data_container(
        cfg.data,
        default_args={
            'train_batch_size': cfg.train.batch_size,
            'val_batch_size': cfg.val.batch_size
        }
    )
    train_pipe = data_container.data['train']
    print(f"device id:{train_pipe.device_id}")
    print(f"train data epoch size:{list(train_pipe.epoch_size().values())[0]}")
    from pprint import pprint
    pprint(f"train pipe attr:\n{train_pipe.__dict__}\n")

    # Note: _api_type of Pipeline becomes PipelineAPIType.BASIC after we invoke Pipeline.run()
    # but DALIIterator need its pipelines' _api_type to be PipelineAPIType.ITERATOR
    # So we will explicitly invoke _set_api_type() to set _api_type to be PipelineAPIType.ITERATOR
    images, labels = train_pipe.run()

    from nvidia.dali.types import PipelineAPIType
    # Reset _api_type
    train_pipe._set_api_type(PipelineAPIType.ITERATOR)

    print(f"train pipe api type:{train_pipe._api_type}\n")
    print(type(images), type(labels))
    print(images.is_dense_tensor(), labels.is_dense_tensor())

    try:
        print(len(images))
    except:
        print(f"images does not have attribute '__len__'")
    try:
        print(len(labels))
    except:
        print(f"labels does not have attribute '__len__'")

    import numpy as np

    try:
        images_ts = images.as_tensor()
        images_arr = np.array(images_ts.as_cpu())
        print(type(images_ts), images_ts.shape(), images_ts.dtype())
    except:
        print("images is not densed")
    try:
        labels_ts = labels.as_tensor()
        print(type(labels_ts), labels_ts.shape(), labels_ts.dtype())
    except:
        print("labels is not densed")
    
    import torch

    torch.set_printoptions(precision=7, edgeitems=5)

    to_torch_dtype = {
        np.dtype(np.float32) : torch.float32,
        np.dtype(np.float64) : torch.float64,
        np.dtype(np.float16) : torch.float16,
        np.dtype(np.uint8)   : torch.uint8,
        np.dtype(np.int8)    : torch.int8,
        np.dtype(np.int16)   : torch.int16,
        np.dtype(np.int32)   : torch.int32,
        np.dtype(np.int64)   : torch.int64
    }

    device = torch.device('cuda', train_pipe.device_id)
    images_pt_ts = torch.empty(images_ts.shape(), dtype=to_torch_dtype[np.dtype(images_ts.dtype())], device=device)
    print(images_pt_ts[0][0][:4, :4])

    import nvidia.dali.plugin.pytorch as dali_pt
    from nvidia.dali.backend import TensorGPU, TensorListGPU

    if isinstance(images_ts, (TensorGPU, TensorListGPU)):
        # Using same cuda_stream used by torch.zeros to set the memory
        stream = torch.cuda.current_stream()
        dali_pt.feed_ndarray(images_ts, images_pt_ts, cuda_stream=stream)
    else:
        dali_pt.feed_ndarray(images_ts, images_pt_ts)
    
    print(images_arr[0][0][:6, :6])
    print(images_pt_ts[0][0][:6, :6])
    images_pt_ts_from_arr = torch.from_numpy(images_arr).to(images_pt_ts.device)
    print(images_pt_ts_from_arr[0][0][:6, :6])
    print(torch.allclose(images_pt_ts, images_pt_ts_from_arr))

    dataloaders = data_container.get_dataloaders()
    train_loader, val_loader = dataloaders['train'], dataloaders['validation']
    print(train_loader.batch_size == train_pipe.max_batch_size)

    import time
    import datetime

    start = time.time()
    for step, (data, label) in enumerate(train_loader, start=1):
        if step < 200:
            continue

        print(type(data), type(label))
        print(data.dtype, label.dtype)
        print(data.shape, label.shape)
        print(label)

        break
    end = time.time()
    print(f"200 batches time used:{datetime.timedelta(seconds=(end - start))}")
