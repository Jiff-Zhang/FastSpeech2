from datasets import load_dataset
from transformers import AutoTokenizer


data = load_dataset('squad')
train_data = data['train']
print(len(train_data))
example = train_data[0]
print(example)

tokenizer = AutoTokenizer.from_pretrained('t5-small', use_fast=True)

max_seq_length = 384

for i, example in enumerate(train_data):
    if len(tokenizer(example['question'], example['context'])['input_ids']) > max_seq_length:
        print(f"find longer than mas seq length example:\n{example}\n")
        break
example = train_data[i]

tokenized_example = tokenizer(
    example['question'].lstrip(), example['context'].lstrip(),
    max_length=max_seq_length, padding="max_length", truncation=True,
    # return_overflowing_tokens=True, return_offsets_mapping=True
)
print(tokenized_example)

# def concat_questions_and_contexts(q, c):
#     return ' '.join(['question:', q.lstrip(), 'context:', c.lstrip()])


# def gen_features(examples):
#     question_name, context_name, answer_name = 'question', 'context', 'answers'
    
#     questions = examples[question_name]
#     contexts = examples[context_name]
#     answers = examples[answer_name]

#     if isinstance(questions, str):
#         questions = [questions]
#     if isinstance(contexts, str):
#         contexts = [contexts]
#     if isinstance(answers, dict):
#         answers = [answers]
    
#     inputs = [
#         concat_questions_and_contexts(question, context)
#         for question, context in zip(questions, contexts)
#     ]
#     targets = [answer['text'][0] if len(answer['text']) else '' for answer in answers]

#     max_seq_length = 384
#     max_answer_length = 30
#     padding = "max_length"
#     ignore_pad_token_for_loss = True

#     tokenized_examples = tokenizer(
#         inputs, max_length=max_seq_length,
#         padding=padding, truncation=True,
#         return_overflowing_tokens=True,
#         return_offsets_mapping=True
#     )

#     # self.logger.info(f"\ntokenized examples:{tokenized_examples}\n")
#     # Setup the tokenizer for targets
#     with tokenizer.as_target_tokenizer():
#         labels = tokenizer(
#             targets, max_length=max_answer_length,
#             padding=padding, truncation=True
#         )

#     if padding and ignore_pad_token_for_loss:
#         labels["input_ids"] = [
#             [(l if l != tokenizer.pad_token_id else -100) for l in label]
#             for label in labels["input_ids"]
#         ]
#     tokenized_examples["labels"] = labels["input_ids"]

#     sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")
#     examples_id = examples["id"]
#     if not isinstance(examples_id, list):
#         examples_id = [examples_id]
#     tokenized_examples["example_id"] = [examples_id[sample_idx] for sample_idx in sample_mapping]

#     return tokenized_examples


# train_features = train_data.map(
#     gen_features,
#     batched=True,
#     num_proc=4,
#     remove_columns=train_data.column_names,
#     load_from_cache_file=False,
#     desc="Running tokenizer on train dataset"
# )
# print(len(train_features['input_ids']), len(train_features['labels']))

# for input_ids in train_features['input_ids']:
#     print(len(input_ids))
# for labels in train_features['labels']:
#     print(len(labels))


# data = load_dataset('glue', 'rte')
# train_data = data['train']
# print(len(train_data))
# example = train_data[0]
# print(example)

# tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased', use_fast=True)

# max_seq_length = 128
# padding = "max_length"

# for i, example in enumerate(train_data):
#     if len(tokenizer(example['sentence1'], example['sentence2'])['input_ids']) > max_seq_length:
#         break
# example = train_data[i]

# tokenized_example = tokenizer(
#     example['sentence1'], example['sentence2'],
#     padding=padding, max_length=max_seq_length, truncation=True
# )
# if 'label' in example:
#     tokenized_example['labels'] = example['label']

# print(tokenized_example)
