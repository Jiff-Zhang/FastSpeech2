import torch
import argparse
import numpy as np

from tqdm import tqdm

from accelerate import Accelerator, DistributedType
from transformers.utils.versions import require_version

require_version("datasets>=1.8.0", 
                "To fix: pip install -r examples/pytorch/text-classification/requirements.txt")

import os

BASE = os.path.dirname(__file__)
ROOT = os.path.join(BASE, '..')

import sys

sys.path.append(ROOT)

from utils.misc import Timer
from utils.seed import setup_seed
from utils.logger import build_logger
from utils.dist import init_accelerator, kill_all_process

from data.builder import build_data_container
from models.builder import build_model, build_model_config

from config.cfg import get_config_from_args


REMOVE_COLUMNS = ("id", "class_id", "example_id", "offset_mapping",)


def parse_args():
    parser = argparse.ArgumentParser(description="Generate embeddings")

    parser.add_argument('--config', type=str, default=None, help='path to config file(yaml or py).')

    parser.add_argument('--data_split_key', type=str, default='train', help='keyword for specify data split.')
    parser.add_argument('--batch_size', type=int, default=128)

    parser.add_argument('--target_layer', type=int, default=-1, help='which hidden state layer to generate embeddings.')
    parser.add_argument('--target_keyword', type=str, default='hidden_states', 
                        help='keyword for getting the target from model outputs, which will be used to generate embeddings.')

    parser.add_argument('--embed_way', type=str, default='first', help='the way to generate embeddings.')
    parser.add_argument('--embed_keyword', type=str, default='embeddings', help='keyword for store embeddings.')
    parser.add_argument('--embed_counts', type=int, default=-1, help='target embedding counts.')

    parser.add_argument('--debug', action='store_true', help='turn on debug mode.')
    parser.add_argument('--num_debug_samples', type=int, default=-1, help='Num samples will be selected when in debug mode.')
    
    return parser.parse_args()


def get_embed_from_hs(hs, embed_way, **kwargs):
    # The way for getting target embedding
    if embed_way == 'first':
        embed = hs[:, 0, :]
    elif embed_way == 'last':
        embed = hs[:, -1, :]
    # After decoder start token
    elif embed_way == 'after_sos':
        embed = hs[:, 1, :]
    elif embed_way == 'pool':
        embed = hs.mean(dim=1)
    elif embed_way == 'attn_mask':
        model_inputs = kwargs.pop('model_inputs')
        last_token = model_inputs['attention_mask'].sum(-1) - 1
        embed = hs[torch.arange(hs.size(0), device=hs.device), last_token, :]
    # Filter out padded tokens
    elif embed_way == 'seq_length':
        model_config = kwargs.pop('model_config', None)
        model_inputs = kwargs.pop('model_inputs')
        seq_length = torch.ne(model_inputs['input_ids'], model_config.pad_token_id).sum(-1) - 1
        embed = hs[torch.arange(hs.size(0), device=hs.device), seq_length, :]
    else:
        raise NotImplementedError(f"Not supported emebdding way: {args.embed_way}.")
    
    return embed


if __name__ == '__main__':
    '''i. Arguments & Configs'''
    args = parse_args()
    cfg = get_config_from_args(args)

    '''ii. Logger'''
    logger = build_logger(cfg)

    '''iii. Distributed wrappers(e.g. Accelerator, DeepSpeedEngine)'''
    # Accelerator
    # We will let the accelerator handle device placement for us.
    accelerator = Accelerator()
    # We only want one process per machine to log things on the screen.
    init_accelerator(accelerator)

    '''iv. Random Seed'''
    setup_seed(cfg.seed)

    # Log some basic info
    logger.info(f"\n[Process Id]: {os.getpid()}\n[Random seed]: {cfg.seed}\n{accelerator.state}")
    # Sync all processes
    accelerator.wait_for_everyone()

    '''v. Dataset'''
    with Timer(logger, job='Load data'):
        # Some arguments required by DataContainer's 'gen_features()' method
        # We pop it & use it later, cuz DataContainer's initialization don't need them.
        gen_features_args = cfg.data.pop('gen_features_args', {})
        default_args=dict(
            use_fp16=accelerator.use_fp16,
            seed=cfg.seed,
            rank=cfg.local_rank,  # this will set by environment if u didn't pass this argument through cmd
            logger=logger,
            debug=cfg.debug  # we will random select few samples if in debug mode
        )

        if 'train' in args.data_split_key:
            default_args.update(train_batch_size=args.batch_size)
        elif 'validation' in args.data_split_key:
            default_args.update(val_batch_size=args.batch_size)
        elif 'test' in args.data_split_key:
            default_args.update(test_batch_size=args.batch_size)
        else:
            raise ValueError(f"Not supported data split key: {args.data_split_key}.")

        data_container = build_data_container(
            cfg.data,
            default_args=default_args
        )

    '''vi. Model(w Tokenizer)'''
    # In distributed training, the 'from_pretrained' methods guarantee that 
    # only one local process can concurrently download model & vocab.
    tokenizer = build_model(cfg.tokenizer, default_args=dict(logger=logger))
    model_config = build_model_config(cfg.model_config, default_args=dict(logger=logger))
    model = build_model(
        cfg.model,
        default_args=dict(model_config=model_config, logger=logger)
    )

    '''vii. Tokenize'''
    data_container.gen_features(tokenizer, model_config=model_config, accelerator=accelerator, **gen_features_args)

    '''viii. Dataloader'''
    with Timer(logger, job='Build dataloaders'):
        # A dict: {'train': DataLoader(), 'validation': DataLoader(), 'test': DataLoader()}
        dataloader = data_container._get_dataloader(
            data_container.features[args.data_split_key], args.batch_size, mode='eval',
            num_workers=data_container.num_workers, pin_memory=data_container.pin_memory,
            use_fp16=data_container.use_fp16, seed=data_container.seed, rank=data_container.rank, logger=logger,
            pad_to_max_seq_length=data_container.pad_to_max_seq_length, tokenizer=tokenizer, model=model
        )
        # In multi-process, each will get its own individual data
        # (cuz the length of dataloader would be shorter than the original)
        dataloader = accelerator.prepare_data_loader(dataloader)
    
    model_unwrapped = model
    model = accelerator.prepare_model(model)

    # Log config
    logger.info(f"\n[Config]\n{cfg.dump()}\n")

    # Log Training info
    # Note: these samples are tokenized data(i.e. features), may more than raw data.
    num_samples = len(dataloader.dataset)
    num_steps = len(dataloader)
    total_batch_size = args.batch_size * accelerator.num_processes
    
    logger.info("***** Start *****")
    logger.info(f"  Num samples(all devs) = {num_samples}")
    logger.info(f"  Num steps(per dev) = {num_steps}")
    logger.info(f"  Batch size(per dev) = {args.batch_size}")
    logger.info(f"  Total batch size (batch size per device x num devices x gradient accumulation steps) = {total_batch_size}\n")

    # Sync all processes before start.
    accelerator.wait_for_everyone()

    '''ix. Embeddings'''
    model.eval()
    
    all_embeddings = []
    all_example_ids = []

    for batch in tqdm(dataloader, disable=cfg.local_rank, desc='Generating embeddings'):
        model_inputs = {k: v.to(model.device) for k, v in batch.items() if k not in REMOVE_COLUMNS}
        # We don't need label here
        model_inputs.pop('labels', -1)

        # No need gradient
        with torch.no_grad():
            outputs = model(**model_inputs, output_hidden_states=True)
        
        # (B,L,D)
        hs = getattr(outputs, args.target_keyword)[args.target_layer]
        # (B,D)
        embed = get_embed_from_hs(hs, args.embed_way, model_inputs=model_inputs, model_config=model_config)

        # Gather all gpus' embeddings
        # (B,D) -> (N_GPUS*B,D)
        embed = accelerator.gather(embed.contiguous())
        assert embed.size(0) == accelerator.num_processes * args.batch_size
        all_embeddings.append(embed.cpu().numpy())

        if 'id' in batch:
            # Gather all gpus' examples
            example_ids = accelerator.gather(batch['id'])
            assert embed.size(0) == accelerator.num_processes * args.batch_size
            all_example_ids.append(example_ids.cpu().numpy())
    
    all_embeddings = np.concatenate(all_embeddings)
    assert all_embeddings.shape[0] == num_steps * accelerator.num_processes * args.batch_size
    logger.info(f"Get {len(all_embeddings)} embeddings total.")

    if len(all_example_ids):
        all_example_ids = np.concatenate(all_example_ids)
        assert all_example_ids.shape[0] == num_steps * accelerator.num_processes * args.batch_size

    if accelerator.is_local_main_process:
        # Remove duplicated embeddings(make examples & embeddings 1-to-1)
        # if all_example_ids:
            # visited = set()
            # unique_embeddings = np.empty((0, all_embeddings.shape[-1]), dtype=all_embeddings.dtype)
            
            # for example_id, embedding in zip(all_example_ids, all_embeddings):
            #     if example_id not in visited:
            #         visited.add(example_id)
            #         unique_embeddings = np.append(unique_embeddings, [embedding], axis=0)

            #     if len(visited) == num_samples:
            #         assert len(unique_embeddings) == num_samples
            #         all_embeddings = unique_embeddings

            #         break

        if data_container.task_name:
            file_name = f'{data_container.task_name}_{cfg.model.name}_embed'
        else:
            file_name = f'{data_container.dataset_name}_{cfg.model.name}_embed'
        dst = os.path.join(logger.log_dir, file_name)

        target_embed_counts = args.embed_counts
        if target_embed_counts == -1:
            target_embed_counts = all_embeddings.shape[0]

        if len(all_example_ids):
            np.savez_compressed(
                dst,
                example_ids=all_example_ids[:target_embed_counts],
                embeddings=all_embeddings[:target_embed_counts]
            )
        else:
            np.savez_compressed(dst, embeddings=all_embeddings[:target_embed_counts])

        logger.info(f'Embeddings have been saved to: {dst}.')
    
    '''x. Realease Memory'''
    accelerator.wait_for_everyone()

    # Release all references to the internal objects stored and call the garbage collector
    accelerator.free_memory()
    if accelerator.distributed_type == DistributedType.MULTI_GPU:
        # Destroy all processes, and de-initialize the distributed package
        kill_all_process()
