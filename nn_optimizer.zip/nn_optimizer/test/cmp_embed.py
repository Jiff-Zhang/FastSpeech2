import argparse
from matplotlib.pyplot import axis
import numpy as np


def parse_args():
    parser = argparse.ArgumentParser(description='Compare embeddings')

    parser.add_argument('--embed1', type=str, required=True, help='path to embeddings.')
    parser.add_argument('--embed2', type=str, required=True, help='path to embeddings.')

    parser.add_argument('--embed1_num', type=int, default=-1, help='number of embeddings to extract.')
    parser.add_argument('--embed2_num', type=int, default=-1, help='number of embeddings to extract.')

    parser.add_argument('--embed1_reduction', type=str, default=None, help='reduction for embeddings.')
    parser.add_argument('--embed2_reduction', type=str, default=None, help='reduction for embeddings.')

    return parser.parse_args()


def get_embeddings(embed_path, num=-1, reduction=None, axis=0, keepdims=True):
    embed_info = np.load(embed_path)
    embeddings = embed_info['embeddings']
    example_ids = embed_info['example_ids']
    del embed_info
    if num == -1:
        num = len(example_ids)

    embeddings, example_ids = embeddings[:num], example_ids[:num]

    if reduction is None:
        return embeddings, example_ids
    elif reduction == 'mean':
        return embeddings.mean(axis=axis, keepdims=keepdims), example_ids.mean(axis=axis, keepdims=keepdims)
    elif reduction == 'sum':
        return embeddings.sum(axis=axis, keepdims=keepdims), example_ids.sum(axis=axis, keepdims=keepdims)
    elif reduction == 'max':
        return embeddings.max(axis=axis, keepdims=keepdims), example_ids.max(axis=axis, keepdims=keepdims)
    elif reduction == 'max_norm':
        embeddings_norm = np.linalg.norm(embeddings, axis=-1, keepdims=keepdims)
        max_idx = embeddings_norm.argmax(axis=0)
        return embeddings[None, max_idx, :], example_ids[None, max_idx, :] if keepdims \
            else embeddings[max_idx, :], example_ids[max_idx, :]
    else:
        raise NotImplementedError(f"Not supported reduction: {reduction}.")


def get_embeddings_norm(embeddings, ord=None, axis=-1, keepdims=True):
    return np.linalg.norm(embeddings, ord=ord, axis=axis, keepdims=keepdims)


if __name__ == '__main__':
    args = parse_args()

    embeddings1, example_ids1 = get_embeddings(args.embed1, num=args.embed1_num, reduction=args.embed1_reduction)
    embeddings2, example_ids2 = get_embeddings(args.embed2, num=args.embed2_num, reduction=args.embed2_reduction)

    norm1 = get_embeddings_norm(embeddings1)
    norm2 = get_embeddings_norm(embeddings2)
    corr = np.matmul(embeddings1, embeddings2.T) / (norm1 * norm2.T)

    print(f"correlation matrix:\n{corr}\n")
    # print(f"mean corr per row:\n{corr.mean(axis=1)}\n")
    # print(f"max corr idx per row:\n{corr.argmax(axis=1)}")
