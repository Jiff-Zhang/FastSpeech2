"""
Enter this directory, then type:

    CUDA_VISIBLE_DEVICES=0,1 accelerate launch test_accelerate.py

This is for evaluating the data sample order of each rank(process) under the Accelerate framework.
"""

from datasets import load_dataset
from accelerate import Accelerator

from torch.utils.data import DataLoader

from transformers.models.auto.tokenization_auto import AutoTokenizer
from transformers.data.data_collator import default_data_collator, DataCollatorWithPadding

import os
import sys

DIR = os.path.dirname(__file__)
sys.path.append(os.path.join(DIR, '..'))

from utils.dist import init_accelerator


def gen_features(
    examples,
    question_column_name='question',
    context_column_name='context',
    answer_column_name='answers',
    max_seq_length=384, doc_stride=128,
    pad_to_max_seq_length=True
):
    # Some of the questions and context have lots of whitespace on the left, which is not useful and will make the
    # truncation of the context fail (the tokenized question will take a lots of space).
    # So we remove those left whitespace.
    examples[question_column_name] = [q.lstrip() for q in examples[question_column_name]]
    examples[context_column_name] = [c.lstrip() for c in examples[context_column_name]]
    
    # Tokenize our examples with truncation and maybe padding, but keep the overflows using a stride.
    # This results in one example possible giving several features when a context is long,
    # each of those features having a context that overlaps a bit the context of the previous feature.
    tokenized_examples = tokenizer(
        examples[question_column_name if pad_on_right else context_column_name],
        examples[context_column_name if pad_on_right else question_column_name],
        truncation="only_second" if pad_on_right else "only_first",
        max_length=max_seq_length,
        stride=doc_stride,
        return_overflowing_tokens=True,
        return_offsets_mapping=True,
        padding="max_length" if pad_to_max_seq_length else False
    )

    # Since one example might give us several features if it has a long context, 
    # we need a map from a feature to its corresponding example. This key gives us just that.
    sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")
    # The offset mappings will give us a map from token to character position in the original context.
    # This will help us compute the start_positions and end_positions.
    offset_mapping = tokenized_examples["offset_mapping"]
    # For evaluation, we will need to convert our predictions to substrings of the context, so we keep the
    # corresponding example_id and we will store the offset mappings.
    tokenized_examples["example_id"] = []

    # Let's label those examples!
    tokenized_examples["start_positions"] = []
    tokenized_examples["end_positions"] = []

    for i, offsets in enumerate(offset_mapping):
        # We will label impossible answers with the index of the CLS token.
        input_ids = tokenized_examples["input_ids"][i]
        # Note: some tokenizers don't have cls token
        cls_index = input_ids.index(tokenizer.cls_token_id) if tokenizer.cls_token_id is not None else 0

        context_id = 1 if pad_on_right else 0
        # Grab the sequence corresponding to that example (to know what is the context and what is the question).
        sequence_ids = tokenized_examples.sequence_ids(i)

        # One example can give several spans, this is the index of the example containing this span of text.
        sample_index = sample_mapping[i]
        tokenized_examples['example_id'].append(examples['id'][sample_index])

        answers = examples[answer_column_name][sample_index]
        # If no answers are given, set the cls_index as answer.
        if len(answers["answer_start"]) == 0:
            tokenized_examples["start_positions"].append(cls_index)
            tokenized_examples["end_positions"].append(cls_index)
        else:
            # Start/end character index of the answer in the text.
            start_char = answers["answer_start"][0]
            end_char = start_char + len(answers["text"][0])

            # Start token index of the current span in the text.
            token_start_index = 0
            while sequence_ids[token_start_index] != context_id:
                token_start_index += 1

            # End token index of the current span in the text.
            token_end_index = len(input_ids) - 1
            while sequence_ids[token_end_index] != context_id:
                token_end_index -= 1
            
            # Detect if the answer is out of the span (in which case this feature is labeled with the CLS index).
            if not (offsets[token_start_index][0] <= start_char and offsets[token_end_index][1] >= end_char):
                tokenized_examples["start_positions"].append(cls_index)
                tokenized_examples["end_positions"].append(cls_index)
            else:
                # Otherwise move the token_start_index and token_end_index to the two ends of the answer.
                # Note: we could go after the last offset if the answer is the last word (edge case).
                while token_start_index < len(offsets) and offsets[token_start_index][0] <= start_char:
                    token_start_index += 1
                tokenized_examples["start_positions"].append(token_start_index - 1)

                while offsets[token_end_index][1] >= end_char:
                    token_end_index -= 1
                tokenized_examples["end_positions"].append(token_end_index + 1)
        
        # Set to None the offset_mapping that are not part of the context
        # so it's easy to determine if a token position is part of the context or not.
        offsets = [
            token_offset if sequence_ids[token_idx] == context_id else None \
                for token_idx, token_offset in enumerate(offsets)
        ]

    return tokenized_examples


if __name__ == '__main__':
    """
    We checkout 4 examples, 2 for each rank(process).
    Let's checkout that the first rank will get the first 2 examples and the last rank will get the last 2.
    """
    
    # Accelerator
    # We will let the accelerator handle device placement for us.
    accelerator = Accelerator()
    # We only want one process per machine to log things on the screen.
    init_accelerator(accelerator)
    print(accelerator.state)

    dataset = 'squad'
    data = load_dataset(dataset)
    val_data = data['validation']
    if accelerator.is_main_process:
        print(f"val data:\n{val_data[:4]}\n")

    pretrained_id = 'bert-base-uncased'
    tokenizer = AutoTokenizer.from_pretrained(pretrained_id)

    # Padding side: (question|context) or (context|question).
    pad_on_right = tokenizer.padding_side == "right"

    max_seq_length = 384
    if max_seq_length > tokenizer.model_max_length:
        print(
            f"The max_seq_length passed ({max_seq_length}) is larger than the maximum length for the"
            f"model ({tokenizer.model_max_length}). Using max_seq_length={tokenizer.model_max_length}."
        )
        max_seq_length = tokenizer.model_max_length
    
    val_features = val_data.map(
        gen_features,
        batched=True,
        num_proc=4,
        remove_columns=val_data.column_names,
        load_from_cache_file=True,
        desc="Running tokenizer on validation dataset"
    )
    if accelerator.is_main_process:
        print(f"val features:\n{val_features[:4]}\n")

    remove_columns = ["example_id", "offset_mapping"]
    val_features_for_dataloader = val_features.remove_columns(remove_columns)

    batch_size = 2
    num_workers = 8
    pad_to_max_seq_length = True
    
    if pad_to_max_seq_length:
        # If padding was already done ot max length, 
        # we use the default data collator that will just convert everything to tensors.
        data_collator = default_data_collator
    else:
        # Otherwise, `DataCollatorWithPadding` will apply dynamic padding for us (by padding to the maximum length of
        # the samples passed). When using mixed precision, we add `pad_to_multiple_of=8` to pad all tensors to multiple
        # of 8s, which will enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta).
        assert tokenizer is not None
        data_collator = DataCollatorWithPadding(tokenizer, pad_to_multiple_of=None)

    dataloader = DataLoader(
        val_features_for_dataloader,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=data_collator
    )
    dataloader = accelerator.prepare_data_loader(dataloader)
    for batch in dataloader:
        print(f"rank:{accelerator.local_process_index}\nbatch:\n{batch}")
        break
