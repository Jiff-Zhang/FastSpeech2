import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

import os
import sys


BASE = os.path.dirname(__file__)
ROOT = os.path.join(BASE, '..')

sys.path.append(ROOT)


if __name__ == '__main__':
    # Tokenizer
    pretrained_model = 't5-base'  # 't5-large'
    tokenizer = AutoTokenizer.from_pretrained(pretrained_model, use_fast=True)

    # Checkpoint(fine-tuned)
    ckpt = "model_cards/t5/base-squad-4x3090-ep3-bs8-lr5e-5-avg85.4-em82.0-f188.8.pth"  # t5-base
    # ckpt = "model_cards/t5/large-squad-4x3090-ep3-bs4-lr5e-5-avg88.1-em85.0-f191.2.pth"  # t5-large
    if not os.path.exists(ckpt):
        ckpt = os.path.join(ROOT, ckpt)
    state_dict = torch.load(ckpt, map_location='cpu')

    # Model config object
    config_cls = state_dict['model_config_cls']
    config_dict = state_dict['model_config_dict']
    model_config = config_cls.from_dict(config_dict)

    # Model
    model = AutoModelForSeq2SeqLM.from_config(model_config)

    # Load weights(fine-tuned)
    model_dict = state_dict['model']
    model.load_state_dict(model_dict, strict=False)
    model.to('cuda')

    # Batch size = 1
    question_context = [
        "question: To whom did the Virgin Mary allegedly appear in 1858 in Lourdes France? "
        "context: Architecturally, the school has a Catholic character. Atop the Main Building\'s gold "
        "dome is a golden statue of the Virgin Mary. Immediately in front of the Main Building and facing it, "
        "is a copper statue of Christ with arms upraised with the legend 'Venite Ad Me Omnes'. "
        "Next to the Main Building is the Basilica of the Sacred Heart. Immediately behind the basilica is "
        "the Grotto, a Marian place of prayer and reflection. It is a replica of the grotto at Lourdes, "
        "France where the Virgin Mary reputedly appeared to Saint Bernadette Soubirous in 1858. At the end of the "
        "main drive (and in a direct line that connects through 3 statues and the Gold Dome), is a simple, modern "
        "stone statue of Mary."
    ]
    answer = ["Saint Bernadette Soubirous"]

    MAX_SEQ_LEN = 384
    MAX_ANS_LEN = 30

    # One sample may generate multiple features(i.e. sub-sample)
    # due to truncation & setting 'return_overflowing_tokens=True'
    tokenized_examples = tokenizer(
        question_context[0], max_length=MAX_SEQ_LEN,
        padding="max_length", truncation=True,
        return_overflowing_tokens=True,
        return_tensors="pt"
    )
    with tokenizer.as_target_tokenizer():
        labels = tokenizer(
            answer[0], max_length=MAX_ANS_LEN,
            padding="max_length", truncation=True,
            return_tensors="pt"
        )
    label_token_ids = labels["input_ids"].where(labels["input_ids"] == tokenizer.pad_token_id, torch.tensor(-100))

    sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")
    num_features = sample_mapping.size(0)
    if len(sample_mapping) == 1:
        tokenized_examples["labels"] = label_token_ids
    else:
        # Expand labels for each feaures
        tokenized_examples["labels"] = label_token_ids.expand(num_features, -1)

    gen_kwargs = {
        "num_beams": 1,
        "max_length": MAX_ANS_LEN
    }

    try:
        model_input_names = tokenizer.model_input_names
    except:
        model_input_names = ["input_ids"]
    generation_inputs = {k: v.to('cuda') for k, v in tokenized_examples.items() if k in model_input_names}

    generated_tokens = model.generate(**generation_inputs, **gen_kwargs)
    for i, generated_tokens_per_example in enumerate(generated_tokens, start=1):
        prediction = tokenizer.decode(generated_tokens_per_example, skip_special_token=True)
        print(f"example:{i} prediction: {prediction}")
