import os
import sys


BASE = os.path.dirname(__file__)
sys.path.append(os.path.join(BASE, '..'))

from utils.logger import BaseLogger
from config.cfg import load_config

from engine.pruner import build_pruner
# from models.builder import build_model
# from data.builder import build_data_container


if __name__ == '__main__':
    '''For Registry Testing'''

    logger = BaseLogger('test/output', name='testing registry')

    # Build data container from config file
    # data_cfg_yaml_file = 'config/data/glue/glue.yaml'
    # cfg = load_config(data_cfg_yaml_file)
    # data_cfg = cfg.data.clone()
    # data_cfg.update(logger=logger)
    # print(data_cfg, '\n')

    # data_container = build_data_container(data_cfg)
    # print(data_container.data, '\n')

    # # Build model from config file
    # model_cfg_py_file = 'config/model/deberta/deberta-base-mnli.py'

    # model_cfg = load_config(model_cfg_py_file)
    # model_cfg.update(logger=logger)
    # print(model_cfg, '\n')

    # model, teacher, kd_logit_loss, kd_layer_loss = build_model(model_cfg)

    import torch.nn as nn

    model = nn.Conv2d(3, 1, 3)
    cfg_file = 'model/bert/base-rte.yaml'
    cfg = load_config(cfg_file)
    pruner = build_pruner(
        cfg.pruner,
        default_args=dict(
            prune=cfg.train.prune,
            model=model,
            model_name=cfg.model.name,
            logger=logger
        )
    )
    assert pruner._model is model
