import torch
import torch.nn as nn

from torch.optim import AdamW


if __name__ == '__main__':
    '''i. Module'''
    model = nn.Sequential(
        nn.Linear(10, 1024, bias=False),
        nn.Linear(1024, 1, bias=False)
    ).cuda()
    # (10x1024+1024)x4
    print(torch.cuda.memory_allocated())

    optimizer = AdamW(model.parameters())

    '''ii. Input'''
    # + min allocated memory(1 page): 512
    x = torch.randn(1, 10).cuda(non_blocking=True)
    print(torch.cuda.memory_allocated())

    '''iii. Intermediate Activations'''
    # + 1024x4(layer1)+512(layer2)
    y = model(x)
    print(torch.cuda.memory_allocated())

    # iv. Gradients
    # + 512
    loss = y.sum()
    tmp = torch.cuda.memory_allocated()
    print(tmp)
    # + (10x1024+1024)x4 - 1024x4(layer1 released)
    # Note: layer2(i.e. y) & loss will not realeased,
    # cuz their references are remained
    loss.backward()
    print(torch.cuda.memory_allocated())

    # v. optimizer states
    # + (10x1024+1024)x2x4
    # AdamW allocate 2 states(momentum&variance) for each parameter
    # so each parameter will require additional 2x4 bytes.
    optimizer.step()
    print(torch.cuda.memory_allocated())

    # Pytorch cached memory, min(1 block)=2MB
    # allocated memory will first from here,
    # if not enough, Pytorch will apply for more memory
    print(torch.cuda.memory_reserved())

    # Max gpu memory already used until now
    print(torch.cuda.max_memory_allocated())
