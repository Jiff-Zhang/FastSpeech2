import torch

from transformers import AutoModelForSeq2SeqLM


FP16 = torch.float16
FP16_LOW, FP16_HIGH = 5.9e-8, 6.5e4


def to_fp16(module):
    print(type(module))
    if not module._modules:
        for name, param in module.named_parameters():
            if not param.requires_grad or param.dtype is FP16:
                continue

            prev = param.detach()
            print(f'name:{name}\nvalue:\n{prev}\n')
            truncated = prev.sign() * prev.abs().clamp(min=FP16_LOW, max=FP16_HIGH)
            param.data.copy_(truncated)
            param.data = param.data.to(FP16)
            print(param.dtype, param.data.dtype)


model = AutoModelForSeq2SeqLM.from_pretrained('t5-small')
model.apply(to_fp16)

for param in model.parameters():
    print(param.dtype)
