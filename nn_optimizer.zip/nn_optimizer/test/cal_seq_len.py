from functools import partial
from typing import Union, List, Tuple

from datasets import load_dataset
from transformers import AutoTokenizer, PreTrainedTokenizerBase


def _concat_sentence_pair(sentence_pair: Union[Tuple, List], keys: Union[List[str], Tuple[str]]):
    """
    Concat multiple sentences to a sentence.
    Note: num of input sentences must equals to num of keys that are not None.
    """
    
    sentence_to_join = [
        f"{feat_key}: {sentence_pair[i]}" \
            for i, feat_key in enumerate(filter(lambda k: k is not None, keys))
    ]
    return ' '.join(sentence_to_join)


def gen_features(
    examples, tokenizer: PreTrainedTokenizerBase,
    feature_keys: Tuple, task_name: str = None

):
    '''Process input texts'''

    sentence_pairs = [examples[feat_key] for feat_key in feature_keys if feat_key is not None]
    texts = [_concat_sentence_pair(pair, feature_keys) for pair in zip(*sentence_pairs)]
    # Text-to-text model need task prompt to do classification task
    if task_name is not None:
        texts = [f"{task_name} {text}" for text in texts]
    
    '''Tokenize'''

    features = tokenizer(texts)
    return features


def cal_seq_len(features):
    max_seq_len = 0
    for i, input_ids in enumerate(features['input_ids']):
        max_seq_len = len(input_ids)
        if not i:
            print(input_ids)
    print(f"max sequence length = {max_seq_len}")


if __name__ == '__main__':
    # Load data
    dataset_name, task_name = 'glue', 'mnli'
    data = load_dataset(dataset_name, task_name)
    train_data, val_data_m, val_data_mm = data['train'], data['validation_matched'], data['validation_mismatched']

    # Setup tokenzier
    pretrained_id = 't5-base'
    tokenizer = AutoTokenizer.from_pretrained(pretrained_id)

    # Tokenze
    feature_keys = ("premise", "hypothesis")

    train_features = train_data.map(
        partial(gen_features, tokenizer=tokenizer, feature_keys=feature_keys, task_name=task_name),
        batched=True,
        remove_columns=train_data.column_names,
        desc='Running tokenizer on train data',
        load_from_cache_file=True
    )

    val_features_m = val_data_m.map(
        partial(gen_features, tokenizer=tokenizer, feature_keys=feature_keys, task_name=task_name),
        batched=True,
        remove_columns=train_data.column_names,
        desc='Running tokenizer on validation-matched data',
        load_from_cache_file=True
    )

    val_features_mm = val_data_mm.map(
        partial(gen_features, tokenizer=tokenizer, feature_keys=feature_keys, task_name=task_name),
        batched=True,
        remove_columns=train_data.column_names,
        desc='Running tokenizer on validation-mismatched data',
        load_from_cache_file=True
    )
    
    # Calculate sequence length
    for features in (train_features, val_features_m, val_features_mm):
        cal_seq_len(features)  # train: 102, val-m: 32, val-mm: 79
