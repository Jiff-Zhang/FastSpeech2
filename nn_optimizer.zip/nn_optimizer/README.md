```
compressor
├─ .git
├─ .gitignore
├─ .gitmodules
├─ .pkl_memoize_py3
├─ README.md
├─ examples
│  ├─ gen_train_infos.py
│  ├─ test_reconstructor.py
│  └─ train_classification.py
├─ frontendcompiler
│  ├─ .git
│  ├─ .gitignore
│  ├─ README.md
│  ├─ __init__.py
│  ├─ compiler
│  ├─ convertor
│  │  ├─ __init__.py
│  │  ├─ bf16_convertor.py
│  │  ├─ calibrate.py
│  │  ├─ convertor.py
│  │  ├─ quant_convertor.py
│  │  └─ utils.py
│  ├─ kernels
│  │  ├─ __init__.py
│  │  ├─ functions
│  │  └─ modules
│  ├─ moffett_ops
│  │  ├─ __init__.py
│  │  ├─ cmodel_ops
│  │  └─ quantization_op
│  ├─ runtime
│  │  ├─ __init__.py
│  │  ├─ front_runtime.py
│  │  ├─ mid_runtime.py
│  │  └─ runtime.py
│  └─ utils
│     ├─ __init__.py
│     ├─ log_utils.py
│     ├─ tensor_utils.py
│     └─ utils.py
├─ output_model
├─ reconstructor
│  ├─ __init__.py
│  ├─ reconstructor.py
│  ├─ torch_base_module.py
│  ├─ torch_fake_module.py
│  └─ torch_reconstructor.py
├─ trainer
│  ├─ __init__.py
│  ├─ loss.py
│  ├─ pruning.py
│  ├─ torch_keep_zero_sgd.py
│  └─ trainer.py
└─ trainingcompiler
   └─ compile.py

```

Installation
   - native requirement

      1、[tvm](http://gitlab.moffettsys.com:5180/Jianwei/tvm0.7)
   
   - download & build

      1、git clone ssh://git@gitlab.moffettsys.com:5122/shijinyuan/compressor.git --recursive

      2、git submodule foreach git checkout master

      3、git submodule foreach git pull
      
      4、cd frontendcompiler;./build.sh
      
   - install necessary Linux packages:
      - apt install -y cmake libtinfo-dev


1、How to run reconstructor
   - prepare ir dir
     - /home/shijinyuan/workspace/git_project/compressor/resnet50/ (217 server)
     - train/val data examples :/home/shijinyuan/data/imagenet/val/ (217 server)
   - python examples/test_reconstructor.py --ir_path resnet50

2、How to run trainer

   1) 拷贝config.default.yaml->config.yaml
      检查数据以及模型路径是否正确
   2) CUDA_VISIBLE_DEVICES=2,3 WORLD_SIZE=2 python -m torch.distributed.launch --nproc_per_node=2 --master_port 56789 example_top_api.py
   
3、How to run experiment

   - {commit log} | run -m classification
   - {commit log} | run -m 1_2
   - {commit log} | run -m 1_2 -lr 0.01 -epochs 100 -optimizer adam -schedule step
   - {commit log} | run -m 1_ -lr 0.01 -epochs 100 -optimizer adam -schedule step



