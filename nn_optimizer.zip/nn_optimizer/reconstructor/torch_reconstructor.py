from collections import OrderedDict
from torch.nn import Parameter, parameter
from typing import List, Optional
import numpy as np
import torch
import torch.nn as nn
import copy
from tqdm import tqdm

from nn_compiler.runtime.kernels import modules

from .base_reconstructor import BaseReconstructor
# from .torch_fake_module import module_factory
from .torch_fake_module_v2 import module_factory
from nn_compiler.compiler.frontend.frontend_mfg import FrontendMFG


class TorchReconstructor(BaseReconstructor, nn.Module):
    def __init__(
        self,
        mf_graph: FrontendMFG,
        input_node_ids: Optional[List] = None,
        output_node_ids: Optional[List] = None,
        update_node_cfg: Optional[List] = None,
        ir_name = None
    ):
        super().__init__(
            mf_graph=mf_graph,
            input_node_ids=input_node_ids,
            output_node_ids=output_node_ids,
            update_node_cfg=update_node_cfg,
        )
        self.ir_name = ir_name
        self.model = torch.nn.ModuleList()
        self.load()
        self._parse_model()
        self.node_used_info = self.count_inputs_used()

    def count_inputs_used(self):
        node_used_info = dict()
        for module in self.model:
            for input_name in module.real_inputs:
                if input_name in node_used_info:
                    node_used_info[input_name] += 1
                else:
                    node_used_info[input_name] = 1
        return node_used_info

    def _parse_model(self):
        for gnode in self.node_list:
            op_type = gnode.op_type
            # print(f'append {op_type}')
            self.model.append(
                module_factory[op_type](
                    gnode, self._parameters, self.quantization_info
                )
            )

    def load(self):
        self.load_weights()
        # self.load_quantization_info()

    def export(self):
        self.export_weights()
        self.export_quantization_info()
        graph = self.export_graph()
        return graph

    def preprocess_conv_weight(self, weight, kernel_layout):
        # original HWIO, expected OIHW
        if kernel_layout == "HWIO":
            weight = weight.transpose(3, 2, 0, 1)
        elif kernel_layout == "HWOI":
            weight = weight.transpose(2, 3, 0, 1)
        else:
            pass
        return weight

    def postprocess_params(self, weight, kernel_layout):
        # original HWIO, expected OIHW
        if kernel_layout == "HWIO":
            weight = weight.transpose(2, 3, 1, 0)
        elif kernel_layout == "HWOI":
            weight = weight.transpose(2, 3, 0, 1)
        else:
            pass
        return weight

    def dequant_weight(self, weight, M1, in_max, out_max):
        shape = [1 for _ in range(len(weight.shape))]
        shape[0] = len(M1)
        M1 = np.reshape(M1, shape)
        weight = M1 * out_max * weight / in_max
        return weight

    def dequant_bias(self, bias, M1, out_max):
        bias = bias * np.array(M1) * out_max / 127
        return bias

    def load_conv_dense_weight(self, int8_weight, node, in_max, out_max, M1):
        if node.op_type != 'nn.dense':
            int8_weight = self.preprocess_conv_weight(int8_weight, node.attrs.kernel_layout)
            fp32_weight = self.dequant_weight(int8_weight, M1, in_max[0], out_max)
        else:
            O, I = int8_weight.shape
            int8_weight = int8_weight.reshape(O, I, 1, 1)
            fp32_weight = self.dequant_weight(int8_weight, M1, in_max[0], out_max)
            fp32_weight = fp32_weight.reshape(O, I)
        return fp32_weight

    def load_matmul_weight(self, int8_weight, in_max, out_max, M1):
        int8_weight = np.expand_dims(int8_weight, 3).transpose(1, 0, 2, 3)
        fp32_weight = self.dequant_weight(int8_weight, M1, in_max[0], out_max)
        fp32_weight = np.squeeze(fp32_weight, 3).transpose(1, 0, 2)
        return fp32_weight


    def load_weights(self):
        if self.params is None:
            return 
        new_params = copy.deepcopy(self.params)
        for node in tqdm(self.node_list, desc="Loading weight ..."):
            if node.attrs.dtype != 'int8':
                if node.op_type in ['nn.conv2d', 'nn.conv2d_transpose']:
                    new_params[node.inputs[1]]= self.preprocess_conv_weight(new_params[node.inputs[1]], node.attrs.kernel_layout)
                if node.op_type == 'nn.batch_norm':
                    # new_params[node.inputs[1]]= self.preprocess_conv_weight(new_params[node.inputs[1]], node.attrs.kernel_layout)
                    # new_params[node.inputs[2]]= self.preprocess_conv_weight(new_params[node.inputs[2]], node.attrs.kernel_layout)
                    #     if 'params' in node.inputs[i]:
                    aaaaaaaaaa=0
                continue
            for idx, input_name in enumerate(node.inputs):
                if input_name == '' or 'params' not in input_name:
                    continue
                in_max = self.quantization_info[node.name]['input_max']
                out_max = self.quantization_info[node.name]['output_max']
                if node.op_type in ['nn.conv2d', 'nn.conv2d_transpose', 'nn.dense']:
                    assert idx > 0, "conv2d/conv2d_transpose/dense input idx 0 is params which is not support yet"
                    M1 = self.quantization_info[node.name]['M1']
                    if idx == 1:
                        int8_weight = self.params[input_name]
                        new_params[input_name] = self.load_conv_dense_weight(int8_weight, node, in_max, out_max, M1)
                    elif idx == 2:
                        int32_bias = self.params[input_name]
                        new_params[input_name] = self.dequant_bias(int32_bias, M1, out_max)
                    else:
                        int8_ele_add = self.params[input_name]
                        new_params[input_name] = in_max[idx] / 127 * int8_ele_add
                elif node.op_type == 'nn.batch_matmul':
                    M1 = self.quantization_info[node.name]['M1']
                    assert idx > 0, "batch_matmul input idx 0 is params which is not support yet"
                    if idx == 1:
                        int8_weight = self.params[input_name]
                        new_params[input_name] = self.load_matmul_weight(int8_weight, in_max, out_max, M1)
                    elif idx == 2:
                        int32_bias = self.params[input_name]
                        new_params[input_name] = self.dequant_bias(int32_bias, M1, out_max)
                    else:
                        int8_ele_add = self.params[input_name]
                        new_params[input_name] = in_max[idx] / 127 * int8_ele_add
                else:
                    int8_data = self.params[input_name]
                    new_params[input_name] = in_max[idx] / 127 * int8_data

        for param_name, param_data in new_params.items():
            if "params/const" in param_name:
                is_constant = True
            else:
                is_constant = False
                param_data = param_data.astype(np.float32)
            if 'running_mean' in param_name or 'running_var' in param_name or 'add_mean' in param_name or 'sub_mean' in param_name:
                param_data = param_data.astype(np.float32)
                self.register_buffer(
                    name=param_name.replace('.', '_'),
                    tensor=torch.Tensor(torch.from_numpy(param_data))
                )
                # self.register_buffer('running_mean', torch.zeros(self.num_features))
                    
            else:
                # if 'add_mean' in param_name or 'sub_mean' in param_name:
                #     self.register_parameter(
                #     name=param_name.replace('.', '_'),
                #     param=Parameter(torch.from_numpy(param_data), requires_grad=False)
                #     )
                # else:
                self.register_parameter(
                    name=param_name.replace('.', '_'),
                    param=Parameter(torch.from_numpy(param_data), requires_grad=not is_constant)
                )
            

    def export_weights(self):
        if self.params is not None:
            for node in tqdm(self.node_list, desc="Exporting weight ..."):
                for idx, input_name in enumerate(node.inputs):
                    if input_name == '' or 'params' not in input_name or 'params/const' in input_name:
                        continue
                    if idx == 1 and node.op_type in ['nn.conv2d', 'nn.conv2d_transpose']:
                        trained_param = self.get_parameter(input_name.replace('.', '_')).detach().cpu().numpy()
                        self.params[input_name] = self.postprocess_params(trained_param, node.attrs.kernel_layout)
                    else:
                        self.params[input_name] = self.get_parameter(input_name.replace('.', '_')).detach().cpu().numpy()

    def load_quantization_info(self):
        if self.params is not None:
            for m in self.model:
                m.load_quantization_info()

    def export_quantization_info(self):
        self.table = dict()
        for name, value in self.quantization_info.items():
            self.table[name] = value['output_max']
        for module in self.model:
            for idx, inp_name in enumerate(module.inputs):
                quant_desc = module.input_quantizer[idx]
                if quant_desc is None:
                    continue
                if module.input_quantizer[idx] is not None:
                    if "#" in inp_name:
                        inp_name, idx_name = inp_name.split('#')
                        self.table[inp_name][int(idx_name)] = module.input_quantizer[idx].amax.detach().cpu().numpy().squeeze().tolist()
                    else:
                        self.table[inp_name] = module.input_quantizer[idx].amax.detach().cpu().numpy().squeeze().tolist()
    
    def export_graph(self):
        from nn_compiler.compiler.frontend.passes.transform import transform
        from nn_compiler.common.moffett_pass import PassContext
        graph = FrontendMFG(node_list=self.node_list, params=self.params)
        graph.set_params_to_node()
        if self.table is not None:
            pctx = PassContext(
                stage="frontend",
            )
            int8_pass = transform.ConvertQuant(
                pctx=pctx,
                table=self.table,
                max_data=self.max_data,
                mix_precision=True,
                fuse_actlut=False,
            )
            graph = int8_pass([graph])[0]
        return graph



    def get_prunable_params(self):
        prunable_params = list()
        if self.params is not None:
            for m in self.model:
                prunable_params.extend(m.get_prunable_params())
        return prunable_params

    def _registe_const(self, outs):
        for name in self.params:
            if name.startswith("params/const"):
                if type(self.params) == np.array:
                    outs[name] = torch.from_numpy(self.params[name])
                else:
                    outs[name] = torch.from_numpy(np.array(self.params[name]))

    def forward(self, *args):
        sorted_inputs = sorted(self.input_node_ids, key=lambda info: (int(info)))
        outs = dict((name, x) for (name, x) in zip(sorted_inputs, args))
        used_node_info = copy.deepcopy(self.node_used_info)
        name_op_shape = []
        for idx, module in enumerate(self.model):
            if module.op_type == 'nn.batch_norm':
                aaaaaaaaaaaaaa=0
            tsrs_in = []
            if module.op_type == "Placeholder":
                if module.module_node.param_name == 'attention_mask':
                    tsrs_in.append(args[2])
                elif module.module_node.param_name == 'input_ids':
                    tsrs_in.append(args[0])
                elif module.module_node.param_name == 'token_type_ids':
                    tsrs_in.append(args[1])
                else:
                    tsrs_in.append(outs[module.name])
            else:
                for name in module.real_inputs:
                    if name == "":
                        tsrs_in.append(None)
                        continue
                    if "#" in name:
                        name, idx = name.split("#")
                        tsrs_in.append(outs[name][idx])
                    elif "params" in name:
                        if 'running_mean' in name or 'running_var' in name or 'add_mean' in name or 'sub_mean' in name:
                            tsrs_in.append(self._buffers[name.replace('.', '_')])    
                        else:
                            tsrs_in.append(self._parameters[name.replace('.', '_')])
                    else:
                        tsrs_in.append(outs[name])

                    if "params" not in name:
                        used_node_info[name] -= 1
                        if (
                            used_node_info[name] == 0
                            and name not in self.output_node_ids
                        ):
                            del outs[name]
            y = module(*tsrs_in)
            # tmpdata = []
            # tmpdata.append(module.module_node.name)
            # tmpdata.append(module.module_node.op_type)
            # for i in range(len(module.inputs)):
            #     tmpdata.append(module.inputs[i])
            # for i in range(len(tsrs_in)):
            #     if isinstance(module, module_factory['concatenate']):
            #         tmpdata.append(list(tsrs_in[0][i].shape))
            #     else:
            #         tmpdata.append(list(tsrs_in[i].shape))
            # name_op_shape.append(tmpdata)
            
            outs[module.name] = y
        if len(self.output_node_ids) == 26: # for nlp bert KD
            attention_kd_layers = []
            encoder_kd_layers = []

            for ni in self.output_node_ids:
                for node in self.node_list:
                    if ni == node.id:
                        if self.ir_name == 'ir_graph.json' or self.ir_name == 'ir_quantized_graph.json':
                            if node.op_type == 'add':
                                attention_kd_layers.append(outs[ni])
                            elif node.op_type == 'nn.bias_add':
                                encoder_kd_layers.append(outs[ni])
                        elif self.ir_name == 'ir_for_pruning_graph.json':
                            if node.op_type == 'add':
                                attention_kd_layers.append(outs[ni])
                            elif node.op_type == 'nn.dropout' or node.op_type == 'nn.layer_norm':
                                encoder_kd_layers.append(outs[ni])

            y = [outs[self.output_node_ids[-1]], attention_kd_layers, encoder_kd_layers]
            del outs
            return y[0], y[1], y[2]
        else:
            y = [outs[name] for name in self.output_node_ids]
            del outs
            if len(y) > 1:
                return y[-1], y[:-1]
                # return y[1]
            else:
                if type(y[0])==list or type(y[0])==tuple:
                    return y[0][0], y[0][1:] # yolov3 only
                elif torch.is_tensor(y[0]):  # torch.Tensor:
                    return y[0]
                else:
                    raise ValueError('unknown output data after forwarding of the model.')

    def disable_observer(self):
        self.model.apply(torch.quantization.disable_observer)

    def enable_observer(self):
        self.model.apply(torch.quantization.enable_observer)

    def iter_modules(self):
        for module in self.model:
            yield module


class DataParallel(torch.nn.DataParallel):
    @property
    def model(self):
        return self.module.model

    def disable_observer(self):
        self.model.apply(torch.quantization.disable_observer)

    def enable_observer(self):
        self.model.apply(torch.quantization.enable_observer)

    def named_modules(self, **kwargs):
        return self.module.named_modules(**kwargs)

    def named_parameters(self, **kwargs):
        return self.module.named_parameters(**kwargs)
