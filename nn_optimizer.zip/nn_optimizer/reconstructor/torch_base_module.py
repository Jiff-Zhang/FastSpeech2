import numpy as np
import torch
from torch import Tensor
from torch.nn import Module, Parameter
import torch.nn.functional as F
from torch.nn.modules.utils import _pair
import numpy as np


__all__ = [
    "AddSingle",
    "AddTwoInputs",
    "SubtractSingle",
    "SubtractTwoInputs",
    "MulSingle",
    "MulTwoInputs",
    "MulNoInput",
    "DivLeft",
    "DivRight",
    "DivTwoInputs",
    "DivNoInput",
    "QConv2d",
    "QLinear",
    "Concatenate",
    "StridedSlice",
    "Split",
    "Where",
    "Exp",
    "Identify",
    "Sum",
    "Mean",
    "ExpandDims",
    "Squeeze",
    "Equal",
    "NotEqual",
    "Cast",
    "Transpose",
    "Pad",
    "Reshape",
    "Reciprocal",
    "BroadcastToLikeSingle",
    "BroadcastToLikeTwoInputs",
    "Take",
    "MatMulSingle",
    "MatMulTwoInputs",
    "AddBiasSingle",
    "AddBiasTwoInputs",
    "Pack",
    "Clip",
]


class Clip(Module):
    def __init__(self, a_min, a_max):
        super().__init__()
        self._a_min = a_min
        self._a_max = a_max

    def forward(self, input_tensor: Tensor) -> Tensor:
        return torch.clamp(input_tensor, self._a_min, self._a_max)


class AddSingle(Module):
    def __init__(self, shape, dtype, constant=False):
        super().__init__()
        self.parameter = Parameter(
            torch.from_numpy(np.zeros(shape).astype(dtype)), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        return torch.add(input_tensor, self.parameter)


class AddTwoInputs(Module):
    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        return torch.add(input_1, input_2)


class AddBiasSingle(Module):
    def __init__(self, shape, dtype, axis, constant=False):
        super().__init__()
        self.axis = axis
        self.parameter = Parameter(
            torch.from_numpy(np.zeros(shape).astype(dtype)), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        last_axis = input_tensor.dim() - 1
        if last_axis != self.axis:
            input_tensor = torch.transpose(input_tensor, self.axis, last_axis)
            return torch.transpose(torch.add(input_tensor, self.parameter), self.axis, last_axis)
        else:
            return torch.add(input_tensor, self.parameter)


class AddBiasTwoInputs(Module):
    def __init__(self, axis):
        self.axis = axis
        super().__init__()

    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        last_axis = input_1.dim() - 1
        if last_axis != self.axis:
            input_1 = torch.transpose(input_1, self.axis, last_axis)
            return torch.transpose(torch.add(input_1, input_2), self.axis, last_axis)
        else:
            return torch.add(input_1, input_2)


class SubtractSingle(Module):
    def __init__(self, shape, dtype, param_index, constant=False):
        super().__init__()
        self.param_index = param_index
        self.parameter = Parameter(
            torch.from_numpy(np.zeros(shape).astype(dtype)), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        if self.param_index == 0:
            return torch.sub(self.parameter, input_tensor)
        else:
            return torch.sub(input_tensor, self.parameter)


class SubtractTwoInputs(Module):
    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        return torch.sub(input_1, input_2)


class MulTwoInputs(Module):
    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        return torch.mul(input_1, input_2)


class MulSingle(Module):
    def __init__(self, shape, dtype, constant=False):
        super().__init__()
        self.parameter = Parameter(
            torch.from_numpy(np.zeros(shape).astype(dtype)), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        return torch.mul(input_tensor, self.parameter)


class MulNoInput(Module):
    def __init__(self, shape_1, constant_1, shape_2, constant_2, dtype):
        super().__init__()
        self.parameter_1 = Parameter(
            torch.from_numpy(np.zeros(shape_1).astype(dtype)),
            requires_grad=not constant_1,
        )
        self.parameter_2 = Parameter(
            torch.from_numpy(np.zeros(shape_2).astype(dtype)),
            requires_grad=not constant_2,
        )

    def forward(self) -> Tensor:
        return torch.mul(self.parameter_1, self.parameter_2)


class DivTwoInputs(Module):
    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        return torch.div(input_1, input_2)


class DivLeft(Module):
    def __init__(self, shape, dtype, constant=False):
        super().__init__()
        self.parameter = Parameter(
            torch.from_numpy(np.zeros(shape).astype(dtype)), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        return torch.div(self.parameter, input_tensor)


class DivRight(Module):
    def __init__(self, shape, dtype, constant=False):
        super().__init__()
        self.parameter = Parameter(
            torch.from_numpy(np.zeros(shape).astype(dtype)), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        return torch.div(input_tensor, self.parameter)


class DivNoInput(Module):
    def __init__(self, shape_1, constant_1, shape_2, constant_2, dtype):
        super().__init__()
        self.parameter_1 = Parameter(
            torch.from_numpy(np.zeros(shape_1).astype(dtype)),
            requires_grad=not constant_1,
        )
        self.parameter_2 = Parameter(
            torch.from_numpy(np.zeros(shape_2).astype(dtype)),
            requires_grad=not constant_2,
        )

    def forward(self) -> Tensor:
        return torch.div(self.parameter_1, self.parameter_2)


def load_quantization_info(fake_quant, X):
    original_observer_enabled = fake_quant.observer_enabled.clone().detach()
    fake_quant.observer_enabled.copy_(torch.tensor([1]))

    fake_quant(X.detach())
    _scale, _zero_point = fake_quant.calculate_qparams()
    _scale, _zero_point = _scale.to(fake_quant.scale.device), _zero_point.to(
        fake_quant.zero_point.device
    )
    fake_quant.scale.resize_(_scale.shape)
    fake_quant.scale.copy_(_scale)
    fake_quant.zero_point.resize_(_zero_point.shape)
    fake_quant.zero_point.copy_(_zero_point)
    fake_quant.observer_enabled.copy_(original_observer_enabled)


# self implemented Conv2d which support bias quantization
class QConv2d(torch.nn.Conv2d):
    r"""
    A Conv2d module attached with FakeQuantize modules for weight,
    used for quantization aware training.

    We adopt the same interface as `torch.nn.Conv2d`, please see
    https://pytorch.org/docs/stable/nn.html?highlight=conv2d#torch.nn.Conv2d
    for documentation.

    Similar to `torch.nn.Conv2d`, with FakeQuantize modules initialized to
    default.

    Attributes:
        weight_fake_quant: fake quant module for weight
    """
    _FLOAT_MODULE = torch.nn.Conv2d

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=True,
        padding_mode="zeros",
        weight_qconfig=None,
        bias_qconfig=None,
    ):
        super().__init__(
            in_channels,
            out_channels,
            kernel_size,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
            bias=bias,
            padding_mode=padding_mode,
        )
        assert weight_qconfig, "qconfig must be provided for QAT module"
        self.weight_fake_quant = weight_qconfig()
        self.has_bias = bias

    def _conv_forward(self, input, weight, bias=None):
        if self.padding_mode != "zeros":
            return F.conv2d(
                F.pad(
                    input, self._reversed_padding_repeated_twice, mode=self.padding_mode
                ),
                weight,
                bias,
                self.stride,
                _pair(0),
                self.dilation,
                self.groups,
            )
        return F.conv2d(
            input, weight, bias, self.stride, self.padding, self.dilation, self.groups
        )

    def forward(self, input):
        if self.has_bias:
            return self._conv_forward(
                input, self.weight_fake_quant(self.weight), self.bias
            )
        else:
            return self._conv_forward(input, self.weight_fake_quant(self.weight))

    def load_quantization_info(self):
        load_quantization_info(fake_quant=self.weight_fake_quant, X=self.weight)
        # if self.bias_fake_quant:
        #     load_quantization_info(fake_quant=self.bias_fake_quant, X=self.bias)


# self implemented Linear which support bias quantization
class QLinear(torch.nn.Linear):
    r"""
    A linear module attached with FakeQuantize modules for weight,
    used for quantization aware training.

    We adopt the same interface as `torch.nn.Linear`, please see
    https://pytorch.org/docs/stable/nn.html#torch.nn.Linear
    for documentation.

    Similar to `torch.nn.Linear`, with FakeQuantize modules initialized to
    default.

    Attributes:
        weight: fake quant module for weight
    """
    _FLOAT_MODULE = torch.nn.Linear

    def __init__(
        self,
        in_features,
        out_features,
        bias=True,
        weight_qconfig=None,
        bias_qconfig=None,
    ):
        super().__init__(in_features, out_features, bias)
        assert weight_qconfig, "qconfig must be provided for QAT module"
        self.weight_fake_quant = weight_qconfig()
        self.has_bias = bias

    def forward(self, input):
        if self.has_bias:
            return F.linear(input, self.weight_fake_quant(self.weight), self.bias)
        else:
            return F.linear(input, self.weight_fake_quant(self.weight))

    def load_quantization_info(self):
        load_quantization_info(fake_quant=self.weight_fake_quant, X=self.weight)
        # if self.bias_fake_quant:
        #     load_quantization_info(fake_quant=self.bias_fake_quant, X=self.bias)


class Concatenate(Module):
    def __init__(self, axis):
        super().__init__()
        self._axis = axis

    def forward(self, *tensors) -> Tensor:
        # if isinstance(tensors, (list, tuple)):
        #     tensors = torch.as_tensor([np.array(i) for i in tensors])
        return torch.cat(tensors=tensors[0], dim=self._axis)


class StridedSlice(Module):
    def __init__(self, begin, end, strides):
        super().__init__()
        self._begin = begin
        self._end = end
        self._strides = strides

    def forward(self, x: Tensor):
        if len(self._begin) == 2:
            return x[
                self._begin[0] : self._end[0] : self._strides[0],
                self._begin[1] : self._end[1] : self._strides[1],
            ]
        elif len(self._begin) == 4:
            return x[
                self._begin[0] : self._end[0] : self._strides[0],
                self._begin[1] : self._end[1] : self._strides[1],
                self._begin[2] : self._end[2] : self._strides[2],
                self._begin[3] : self._end[3] : self._strides[3],
            ]
        else:
            raise RuntimeError("unknown input dimensions")


class Split(Module):
    def __init__(self, indices_or_sections, axis):
        super().__init__()
        self._indices_or_sections = indices_or_sections
        self._axis = axis

    def forward(self, x: Tensor):
        return torch.split(
            x, split_size_or_sections=self._indices_or_sections, dim=self._axis
        )


class Where(Module):
    def forward(self, condition: Tensor, x: Tensor, y: Tensor):
        return torch.where(condition, x, y)


class ExpandDims(Module):
    def __init__(self, axis):
        super().__init__()
        self._axis = axis

    def forward(self, x: Tensor):
        return torch.unsqueeze(x, dim=self._axis)


class Squeeze(Module):
    def __init__(self, axis):
        super().__init__()
        self._axis = axis

    def forward(self, x: Tensor):
        return torch.squeeze(x, dim=self._axis)


class Identify(Module):
    def __init__(self, index):
        super().__init__()
        self._index = index

    def forward(self, *x):
        return x[self._index]


class Exp(Module):
    def forward(self, x: Tensor):
        return torch.exp(x)


class Reciprocal(Module):
    def forward(self, x: Tensor):
        return torch.reciprocal(x)


class Sum(Module):
    def __init__(self, axis, keepdim):
        super().__init__()
        self._axis = axis
        self._keepdim = keepdim

    def forward(self, x: Tensor):
        return torch.sum(input=x, dim=self._axis, keepdim=self._keepdim)


class Mean(Module):
    def __init__(self, axis, keepdims):
        super().__init__()
        self._axis = axis
        self._keepdims = keepdims

    def forward(self, x: Tensor):
        return torch.mean(x, self._axis, self._keepdims)


class Equal(Module):
    def forward(self, x: Tensor, y: Tensor):
        return x == y


class NotEqual(Module):
    def forward(self, x: Tensor, y: Tensor):
        return x != y


class Cast(Module):
    def __init__(self, dtype):
        super().__init__()
        self._dtype = dtype

    def forward(self, x: Tensor):
        if self._dtype == "float32":
            return x.float()
        elif self._dtype == "float64":
            return x.double()
        elif self._dtype == "int32":
            return x.int()
        elif self._dtype == "int64":
            return x.long()
        else:
            raise TypeError(f"unknown type to cast {self._dtype}")


class Transpose(Module):
    def __init__(self, axes):
        super().__init__()
        self._axes = axes

    def forward(self, x: Tensor):
        return x.permute(*self._axes)


class Pad(Module):
    def __init__(self, pad_top, pad_bottom, pad_left, pad_right):
        super().__init__()
        self.pad_top = pad_top
        self.pad_bottom = pad_bottom
        self.pad_left = pad_left
        self.pad_right = pad_right

    def forward(self, x):
        return torch.nn.functional.pad(
            x, (self.pad_left, self.pad_right, self.pad_top, self.pad_bottom)
        )


class Reshape(Module):
    def __init__(self, newshape):
        super().__init__()
        self._newshape = newshape

    def forward(self, x: Tensor):
        return torch.reshape(x, self._newshape)


class BroadcastToLikeSingle(Module):
    def __init__(self, init_params, param_index, constant=False):
        super().__init__()
        self.param_index = param_index
        self.parameter = Parameter(
            torch.from_numpy(init_params), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        if self.param_index == 0:
            return self.parameter.expand(input_tensor.size())
        else:
            return input_tensor.expand(self.parameter.size())


class BroadcastToLikeTwoInputs(Module):
    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        return input_1.expand(input_2.size())


class Take(Module):
    def __init__(self, init_params, param_index, axis, constant=False):
        super().__init__()
        self.param_index = param_index
        self.parameter = Parameter(
            torch.from_numpy(init_params), requires_grad=not constant
        )
        self._axis = axis

    @staticmethod
    def batch_wise_index_select(input, axis, index):
        out = []
        for i in range(index.size(0)):
            out.append(torch.index_select(input, dim=axis, index=index[i].view(-1)))
        return torch.stack(out, dim=0)

    def forward(self, x: torch.tensor):
        if self.param_index == 0:
            return self.batch_wise_index_select(
                self.parameter, self._axis, x.type(torch.long)
            )
        else:
            return self.batch_wise_index_select(
                x, self._axis, self.parameter.type(torch.long)
            )


class MatMulSingle(Module):
    def __init__(self, init_params, param_index, constant=False):
        super().__init__()
        self.param_index = param_index
        self.parameter = Parameter(
            torch.from_numpy(init_params), requires_grad=not constant
        )

    def forward(self, input_tensor: Tensor) -> Tensor:
        if self.param_index == 0:
            return self.activation_func(
                torch.matmul(self.y, torch.transpose(input_tensor, 1, 2))
            )
        else:
            return self.activation_func(
                torch.matmul(input_tensor, torch.transpose(self.y, 1, 2))
            )


class MatMulTwoInputs(Module):
    def forward(self, input_1: Tensor, input_2: Tensor) -> Tensor:
        return torch.matmul(input_1, torch.transpose(input_2, 1, 2))


class Pack(Module):
    def forward(self, *inputs):
        return inputs


