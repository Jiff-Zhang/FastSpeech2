import os
import json
import logging
from enum import Enum
from tqdm import tqdm

import numpy as np
import torch

from nn_compiler.compiler.frontend.frontend_mfg import FrontendMFG
from nn_optimizer.reconstructor.torch_reconstructor import TorchReconstructor, DataParallel
import argparse
import torchvision

import torch

# logger = logging.getLogger(__name__)


class ReConstructor:
    def __init__(self, ir_name):
        self.ir_name = ir_name
        # self.device = device if len(device) > 0 else ["cpu"]

    def load_train_info(self, train_info_path):
        with open(train_info_path, "r") as f:
            train_info = json.load(f)
        return train_info

    def _load_moffett_graph(self, train_graph, moffett_ir_dir: str, train_params):
        if train_graph is None:
            student_moffett_graph = FrontendMFG()
            ir_prefix = os.path.join(moffett_ir_dir, "ir_training")
            student_moffett_graph.load(ir_prefix)
            student_moffett_graph._train_infos = train_params
        else:
            student_moffett_graph = train_graph
        teacher_moffett_graph = None
        if train_params["kd"]:
            teacher_moffett_graph = FrontendMFG()
            # always no quantization for teacher
            teacher_moffett_graph.load(os.path.join(moffett_ir_dir, "ir_training"))
        return student_moffett_graph, teacher_moffett_graph

    def reconstruct_model(self, moffett_ir_dir, train_graph=None):
        if train_graph is None:
            train_params = self.load_train_info(
                os.path.join(moffett_ir_dir, "train_infos.json")
            )
        else:
            train_params = train_graph._train_infos
        student_moffett_graph, teacher_moffett_graph = self._load_moffett_graph(
            train_graph, moffett_ir_dir, train_params
        )
        student_model = TorchReconstructor(
            mf_graph=student_moffett_graph,
            output_node_ids=[
                train_params["feature_map_tensor_name"],
                train_params["output_tensor_name"],
            ],
            ir_name = self.ir_name
        )

        # student_model.load()
        # logger.info(f"move model to device {self.device[0]}")
        # student_model.to(self.device[0])
        # student_model.eval()

        if train_params["re_init"]:

            def init_weights(m):
                if isinstance(m, torch.nn.Conv2d):
                    torch.nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                elif isinstance(m, torch.nn.Linear):
                    torch.nn.init.kaiming_normal_(m.weight, nonlinearity="relu")

            student_model.apply(init_weights)

        if teacher_moffett_graph is None:
            teacher_model = None
        else:
            teacher_model = TorchReconstructor(
                mf_graph=teacher_moffett_graph,
                output_node_ids=[
                    train_params["feature_map_tensor_name"],
                    train_params["output_tensor_name"],
                ],
                ir_name = self.ir_name
            )

            # teacher_model.load()
            # teacher_model.to(self.device[0])
            # teacher_model.eval()

        # if len(self.device) > 1:
        #     pass
            # logger.info(
            #     f"number of cuda device count is {len(self.device)}, parallelize it"
            # )
            # TODO
            # parallel model
        return teacher_model, student_model, student_moffett_graph


# def parse_args():
#     parser = argparse.ArgumentParser(description="")
#     parser.add_argument("--ir_path", type=str, default=r'/mnt/dataset/imagenet/resnet18/')
#     parser.add_argument("--use_quantization", type=bool, default=True)
#     parser.add_argument("--kd", type=bool, default=True)
#     parser.add_argument("--re_init", type=bool, default=True)
#     parser.add_argument("--cudastr", type=str, default='')

#     return parser.parse_args()

if __name__ == "__main__":

    # ------------------------------>
    # opt = parse_args()
    # recon = ReConstructor(moffett_ir_dir=opt.ir_path, use_kd=opt.kd, re_init=opt.re_init, cudastr=opt.cudastr)
    # tea, stu = recon.reconstruct_model()

    aaaaaaa = 0
