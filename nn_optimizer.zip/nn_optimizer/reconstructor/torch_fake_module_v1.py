from functools import partial

import torch
import numpy as np
import torch.nn.quantized
from torch import nn
from .torch_base_module import *


ACTIVATION_QCONFIG = torch.quantization.FakeQuantize.with_args(
    observer=partial(
        torch.quantization.MovingAverageMinMaxObserver, quant_min=-127, quant_max=127
    ),
    qscheme=torch.per_tensor_symmetric,
    quant_min=-127,
    quant_max=127,
    dtype=torch.qint8,
    reduce_range=False,
)


CONV_QCONFIG = torch.quantization.FakeQuantize.with_args(
    observer=partial(
        torch.quantization.MovingAveragePerChannelMinMaxObserver,
        quant_min=-127,
        quant_max=127,
    ),
    quant_min=-127,
    quant_max=127,
    dtype=torch.qint8,
    qscheme=torch.per_channel_symmetric,
    reduce_range=False,
    ch_axis=0,
)  # OIHW layout


MATMUL_QCONFIG = torch.quantization.FakeQuantize.with_args(
    observer=partial(
        torch.quantization.MovingAveragePerChannelMinMaxObserver,
        quant_min=-127,
        quant_max=127,
    ),
    quant_min=-127,
    quant_max=127,
    dtype=torch.qint8,
    qscheme=torch.per_channel_symmetric,
    reduce_range=False,
    ch_axis=2,
)  # for nlp model


BIAS_QCONFIG = torch.quantization.FakeQuantize.with_args(
    observer=partial(
        torch.quantization.MovingAveragePerChannelMinMaxObserver,
        quant_min=-127,
        quant_max=127,
    ),
    qscheme=torch.per_channel_symmetric,
    quant_min=-127,
    quant_max=127,
    dtype=torch.qint8,
    reduce_range=False,
    ch_axis=0,
)


class FakeBaseModule(nn.Module):
    def __init__(self, gnode, params, quantization_info):
        super().__init__()
        attrs = gnode.attrs.__dict__
        if attrs is None:
            attrs = {}
        inputs = gnode.inputs
        if inputs is None:
            inputs = []
        self.inputs = inputs
        self.attrs = attrs
        self.name = gnode.name
        self.quant_attrs = gnode.quant_attrs
        # no preprocess
        self.preprocess = [
            -1
            for val, name in zip(self.quant_attrs["preprocess"], self.inputs)
            if not name.startswith("params")
        ]
        self.weight_process = [
            -1
            for val, name in zip(self.quant_attrs["preprocess"], self.inputs)
            if name.startswith("params")
        ]

        if self.attrs["dtype"] == "int8":
            # self.postprocess = self.quant_attrs['postprocess']
            self.postprocess = 1
            self.weight_process = [1] * len(self.weight_process)
        else:
            self.postprocess = 0

        self.params = params
        self.quantization_info = quantization_info

        self._preprocessing_list = nn.ModuleList(
            [
                self._get_activation_fake_quant_module(fake_quant_type=preprocess_type)
                for preprocess_type in self.preprocess
            ]
        )

        self._core = None
        self._init_core_module()
        self._activation = self._get_activation_module()
        self._postprocessing = self._get_activation_fake_quant_module(
            fake_quant_type=self.postprocess
        )

    def _init_core_module(self):
        raise NotImplementedError(
            "all concrete fake module should implement this function"
        )

    def _core_forward(self, *inputs):
        """
        override this function if you are not using sub module but call torch function directly
        """
        return self._core(*inputs)

    def _get_activation_module(self):
        activation_type = self.attrs.get("activation", "")
        if activation_type is None or activation_type == "":
            return nn.Identity()
        elif activation_type == "nn.relu":
            return nn.ReLU(inplace=True)
        elif activation_type == "nn.relu6":
            return nn.ReLU6(inplace=True)
        else:
            raise ValueError("unknown activation type: {}".format(activation_type))

    @staticmethod
    def _get_activation_fake_quant_module(fake_quant_type):
        if fake_quant_type != 1:
            return nn.Identity()
        else:
            return ACTIVATION_QCONFIG()

    def forward(self, *inputs):
        inputs = [
            preprocessing(x)
            for preprocessing, x in zip(self._preprocessing_list, inputs)
        ]
        output = self._postprocessing(self._activation(self._core_forward(*inputs)))
        return output

    def load_quantization_info(self):
        # pre-process
        for index, preprocess in enumerate(self.preprocess):
            if preprocess == 1:
                observer = self._preprocessing_list[index].activation_post_process
                self.load_max_vals_to_observer(
                    observer=observer,
                    max_vals=self.quantization_info[self.real_inputs[index]].get(
                        "output_max"
                    ),
                )
                self.update_observer_to_fakequant(
                    observer=observer, fakequant=self._preprocessing_list[index]
                )
        # post-process
        if self.postprocess == 1:
            observer = self._postprocessing.activation_post_process
            self.load_max_vals_to_observer(
                observer=observer,
                max_vals=self.quantization_info[self.name].get("output_max"),
            )
            self.update_observer_to_fakequant(
                observer=observer, fakequant=self._postprocessing
            )

        # weight
        if any([process == 1 for process in self.weight_process]):
            self._core.load_quantization_info()

    @staticmethod
    def load_max_vals_to_observer(observer: torch.quantization.ObserverBase, max_vals):
        # FIXME: schema of max_vals should be fixed
        if isinstance(observer, torch.quantization.PerChannelMinMaxObserver):
            raise NotImplementedError
        elif isinstance(observer, torch.quantization.MinMaxObserver):
            if max_vals is None:
                max_vals = float("inf")
            observer.max_val = torch.tensor(max_vals)
            observer.min_val = torch.tensor(-max_vals)
        else:
            raise TypeError("unknown observer: {}".format(type(observer)))

    @staticmethod
    def get_max_vals_from_observer(observer: torch.quantization.ObserverBase):
        if isinstance(observer, torch.quantization.PerChannelMinMaxObserver):
            max_vals = observer.max_vals.cpu().numpy().flatten()
            min_vals = observer.min_vals.cpu().numpy().flatten()
            return list(
                map(float, np.max(np.abs(np.vstack([max_vals, min_vals])), axis=0))
            )
        elif isinstance(observer, torch.quantization.MinMaxObserver):
            return float(
                max(
                    abs(observer.max_val.cpu().numpy()),
                    abs(observer.min_val.cpu().numpy()),
                )
            )
        else:
            raise TypeError("unknown observer: {}".format(type(observer)))

    @staticmethod
    def update_observer_to_fakequant(observer, fakequant):
        _scale, _zero_point = observer.calculate_qparams()
        _scale, _zero_point = _scale.to(fakequant.scale.device), _zero_point.to(
            fakequant.zero_point.device
        )
        fakequant.scale.resize_(_scale.shape)
        fakequant.scale.copy_(_scale)
        fakequant.zero_point.resize_(_zero_point.shape)
        fakequant.zero_point.copy_(_zero_point)

    def export_quantization_info(self):
        # pre-process
        for index, preprocess in enumerate(self.preprocess):
            if preprocess == 1:
                observer = self._preprocessing_list[index].activation_post_process
                output_max = self.get_max_vals_from_observer(observer)
                self.quantization_info[self.real_inputs[index]][
                    "output_max"
                ] = output_max
        # post-process
        if self.postprocess == 1:
            observer = self._postprocessing.activation_post_process
            output_max = self.get_max_vals_from_observer(observer)
            self.quantization_info[self.name]["output_max"] = output_max

        # weight
        # quantization is calculated from weight when loading, so we dont have to dump it

    def load_weights(self):
        pass

    def export_weights(self):
        pass

    @property
    def nnz(self):
        return 0

    @property
    def sparsity(self):
        return 0.0

    @property
    def real_inputs(self):
        return [name for name in self.inputs if not name.startswith("params")]

    @staticmethod
    def get_max_values_from_observer(observer: torch.quantization.ObserverBase):
        if isinstance(observer, torch.quantization.PerChannelMinMaxObserver):
            max_vals = observer.max_vals.cpu().numpy().flatten()
            min_vals = observer.min_vals.cpu().numpy().flatten()
            return list(
                map(float, np.max(np.abs(np.vstack([max_vals, min_vals])), axis=0))
            )
        elif isinstance(observer, torch.quantization.MinMaxObserver):
            return float(
                max(
                    abs(observer.max_val.cpu().numpy()),
                    abs(observer.min_val.cpu().numpy()),
                )
            )
        else:
            raise TypeError("unknown observer: {}".format(type(observer)))


class FakePlaceholder(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.preprocess = [-1]
        self._preprocessing_list = nn.ModuleList([nn.Identity()])

    def _init_core_module(self):
        self._core = nn.Identity()

    @property
    def real_inputs(self):
        return [self.name + "_raw"]


class FakeConv2d(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.kernel_layout = self.attrs["kernel_layout"]

    @property
    def in_channel(self):
        if self.attrs["data_layout"] == "NCHW":
            return self.attrs["A_shape"][0][1]
        elif self.attrs["data_layout"] == "NHWC":
            return self.attrs["A_shape"][0][3]
        else:
            raise ValueError(
                "unknown data_layout: {}".format(self.attrs["data_layout"])
            )

    @property
    def out_channel(self):
        if self.attrs["data_layout"] == "NCHW":
            return self.attrs["O_shape"][0][1]
        elif self.attrs["data_layout"] == "NHWC":
            return self.attrs["O_shape"][0][3]
        else:
            raise ValueError(
                "unknown data_layout: {}".format(self.attrs["data_layout"])
            )

    def _init_core_module(self):
        strides = self.attrs["strides"]
        padding = self.attrs["padding"]
        groups = self.attrs["groups"]
        dilation = tuple(self.attrs["dilation"])
        if len(padding) == 4:
            padding = padding[:2][::-1]
        kernel_size = self.attrs["kernel_size"]
        use_bias = self.attrs.get("bias_term")
        if any([process == 1 for process in self.weight_process]):
            self._core = QConv2d(
                self.in_channel,
                self.out_channel,
                kernel_size,
                stride=strides,
                padding=padding,
                bias=use_bias,
                groups=groups,
                dilation=dilation,
                weight_qconfig=CONV_QCONFIG if self.weight_process[0] == 1 else None,
                bias_qconfig=BIAS_QCONFIG
                if use_bias and self.weight_process[1] == 1
                else None,
            )
        else:
            self._core = nn.Conv2d(
                self.in_channel,
                self.out_channel,
                kernel_size,
                stride=strides,
                padding=padding,
                bias=use_bias,
                groups=groups,
                dilation=dilation,
            )

    def is_normal_conv(self):
        return self.groups == 1

    def is_se_conv(self):
        return self.attrs["A_shape"][0][2] == 1 and self.attrs["A_shape"][0][3] == 1

    def load_weights(self):
        # original HWIO, expected OIHW
        if self.kernel_layout == "HWIO":
            weight = np.transpose(self.params[self.inputs[1]], [3, 2, 0, 1])
        elif self.kernel_layout == "HWOI":
            weight = np.transpose(self.params[self.inputs[1]], [2, 3, 0, 1])
        else:
            weight = self.params[self.inputs[1]]

        self._core.weight.data.copy_(torch.from_numpy(weight))

        if self.attrs.get("bias_term"):
            bias = self.params[self.inputs[2]]
            self._core.bias.data.copy_(torch.from_numpy(bias))

    def export_weights(self):

        weight = self._core.weight.data.detach().cpu().numpy()  # OIHW

        if self.kernel_layout == "HWIO":
            weight = np.transpose(weight, [2, 3, 1, 0])
        elif self.kernel_layout == "HWOI":
            weight = np.transpose(weight, [2, 3, 0, 1])
        else:
            pass
        self.params[self.inputs[1]] = weight
        if self.attrs.get("bias_term"):
            self.params[self.inputs[2]] = self._core.bias.data.detach().cpu().numpy()

    @property
    def nnz(self):
        return torch.count_nonzero(self._core.weight.data).cpu().numpy()

    @property
    def sparsity(self):
        nnz = torch.count_nonzero(self._core.weight.data)
        size = self._core.weight.data.nelement()
        return 1.0 - (nnz / size).cpu().numpy()


class FakeBatchNorm(FakeBaseModule):
    def _init_core_module(self):
        eps = self.attrs["epsilon"]
        in_channel = self.attrs["A_shape"][1][0]
        self._core = nn.BatchNorm2d(in_channel, eps=1e-5, momentum=0.1)

    def load_weights(self):

        gamma = self.params[self.inputs[1]]
        beta = self.params[self.inputs[2]]
        running_mean = self.params[self.inputs[3]]
        running_var = self.params[self.inputs[4]]
        self._core.weight.data.copy_(torch.from_numpy(gamma))
        self._core.bias.data.copy_(torch.from_numpy(beta))
        self._core.running_mean.data.copy_(torch.from_numpy(running_mean))
        self._core.running_var.data.copy_(torch.from_numpy(running_var))

    def export_weights(self):

        self.params[self.inputs[1]] = self._core.weight.data.detach().cpu().numpy()
        self.params[self.inputs[2]] = self._core.bias.data.detach().cpu().numpy()
        self.params[self.inputs[3]] = (
            self._core.running_mean.data.detach().cpu().numpy()
        )
        self.params[self.inputs[4]] = self._core.running_var.data.detach().cpu().numpy()


class FakeLayerNorm(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.LayerNorm(
            self.attrs["A_shape"][1][0], eps=self.attrs["epsilon"]
        )

    def load_weights(self):
        gamma = self.params[self.inputs[1]]
        beta = self.params[self.inputs[2]]
        self._core.weight.data.copy_(torch.from_numpy(gamma))
        self._core.bias.data.copy_(torch.from_numpy(beta))

    def export_weights(self):
        self.params[self.inputs[1]] = self._core.weight.data.detach().cpu().numpy()
        self.params[self.inputs[2]] = self._core.bias.data.detach().cpu().numpy()


class FakeMaxPool2d(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(FakeMaxPool2d, self).__init__(gnode, params, quantization_info)

    def _init_core_module(self):
        self._core = nn.MaxPool2d(
            kernel_size=self.attrs.get("pool_size", (1, 1)),
            stride=self.attrs.get("strides", (1, 1)),
            padding=self.attrs.get("padding", (0, 0))[:2],
            ceil_mode=False,
        )


class FakeAvgPool2d(FakeBaseModule):
    def _init_core_module(self):
        pool_size = self.attrs.get("pool_size", (1, 1))
        strides = self.attrs.get("strides", (1, 1))
        padding = self.attrs.get("padding", (0, 0))
        self._core = nn.AvgPool2d(
            pool_size, stride=strides, padding=padding[:2], ceil_mode=False
        )


class FakeAdd(FakeBaseModule):
    def _init_core_module(self):
        if self.inputs[0].startswith("params") or self.inputs[1].startswith("params"):
            self.param_index = 0 if self.inputs[0].startswith("params") else 1
            param_shape = self.params[self.inputs[self.param_index]].shape
            constant = self.inputs[self.param_index].startswith("params/const")
            self._core = AddSingle(
                shape=param_shape, dtype=self.attrs["dtype"], constant=constant
            )
        else:
            self._core = AddTwoInputs()

    def load_weights(self):
        if isinstance(self._core, AddSingle):
            self._core.parameter.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[self.param_index]].astype(
                        self.attrs["dtype"]
                    )
                )
            )

    def export_weights(self):
        if isinstance(self._core, AddSingle):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeBiasAdd(FakeBaseModule):
    def _init_core_module(self):
        if self.inputs[0].startswith("params") or self.inputs[1].startswith("params"):
            self.param_index = 0 if self.inputs[0].startswith("params") else 1
            param_shape = self.params[self.inputs[self.param_index]].shape
            constant = self.inputs[self.param_index].startswith("params/const")
            self._core = AddBiasSingle(
                shape=param_shape,
                dtype=self.attrs["dtype"],
                axis=self.attrs["axis"],
                constant=constant,
            )
        else:
            self._core = AddBiasTwoInputs(axis=self.attrs["axis"])

    def load_weights(self):
        if isinstance(self._core, AddBiasSingle):
            self._core.parameter.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[self.param_index]].astype(
                        self.attrs["dtype"]
                    )
                )
            )

    def export_weights(self):
        if isinstance(self._core, AddBiasSingle):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeSubtract(FakeBaseModule):
    def _init_core_module(self):
        if self.inputs[0].startswith("params") or self.inputs[1].startswith("params"):
            self.param_index = 0 if self.inputs[0].startswith("params") else 1
            param_shape = self.params[self.inputs[self.param_index]].shape
            constant = self.inputs[self.param_index].startswith("params/const")
            self._core = SubtractSingle(
                shape=param_shape,
                dtype=self.attrs["dtype"],
                param_index=self.param_index,
                constant=constant,
            )
        else:
            self._core = SubtractTwoInputs()

    def load_weights(self):
        if isinstance(self._core, SubtractSingle):
            self._core.parameter.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[self.param_index]].astype(
                        self.attrs["dtype"]
                    )
                )
            )

    def export_weights(self):
        if isinstance(self._core, SubtractSingle):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeGlobalAvgPooling(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.AdaptiveAvgPool2d(1)


class FakeFlatten(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.Flatten()


class FakeDense(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _init_core_module(self):
        out_channel = self.attrs["A_shape"][1][0]
        in_channel = self.attrs["A_shape"][1][1]
        use_bias = self.attrs.get("bias_term")
        if any([process == 1 for process in self.weight_process]):
            self._core = QLinear(
                in_channel,
                out_channel,
                bias=use_bias,
                weight_qconfig=CONV_QCONFIG if self.weight_process[0] == 1 else None,
                bias_qconfig=BIAS_QCONFIG
                if use_bias and self.weight_process[1] == 1
                else None,
            )
        else:
            self._core = nn.Linear(in_channel, out_channel, bias=use_bias)

    def load_weights(self):
        weight = self.params[self.inputs[1]]
        self._core.weight.data.copy_(torch.from_numpy(weight))
        if self.attrs.get("bias_term"):
            bias = self.params[self.inputs[2]]
            self._core.bias.data.copy_(torch.from_numpy(bias))

    def export_weights(self):
        self.params[self.inputs[1]] = self._core.weight.data.detach().cpu().numpy()
        if self.attrs.get("bias_term"):
            self.params[self.inputs[2]] = self._core.bias.data.detach().cpu().numpy()

    @property
    def nnz(self):
        return torch.count_nonzero(self._core.weight.data).cpu().numpy()

    @property
    def sparsity(self):
        nnz = torch.count_nonzero(self._core.weight.data)
        size = self._core.weight.data.nelement()
        return 1.0 - (nnz / size).cpu().numpy()


class FakeReLU(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.ReLU(inplace=True)


class FakeLeakyReLU(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.LeakyReLU(negative_slope=self.attrs["alpha"], inplace=True)


class FakeReLU6(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.ReLU6(inplace=True)


class FakeSwish(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.SiLU(inplace=True)


class FakeSigmoid(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.Sigmoid()


class FakeGeLU(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.GELU()


class FakeErf(FakeBaseModule):
    def _init_core_module(self):
        pass

    def forward(self, *inputs):
        inputs = [
            preprocessing(x)
            for preprocessing, x in zip(self._preprocessing_list, inputs)
        ]
        output = self._postprocessing(torch.erf(*inputs))
        return output


class FakeReciprocal(FakeBaseModule):
    def _init_core_module(self):
        self._core = Reciprocal()


class FakeTanh(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.Tanh()


class FakeExp(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _init_core_module(self):
        self._core = Exp()


class FakeAdaptiveAvgPool2d(FakeBaseModule):
    def _init_core_module(self):
        output_size = self.attrs["output_size"]
        if len(output_size) == 1:
            output_size = output_size[0]
        self._core = nn.AdaptiveMaxPool2d(output_size)


class FakeSoftmax(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.Softmax(dim=self.attrs["axis"])


class FakeConcatenate(FakeBaseModule):
    def _init_core_module(self):
        axis = self.attrs["axis"]
        # FIXME: torch is NCHW format only
        if axis == 3:
            axis = 1
        self._core = Concatenate(axis=axis)


class FakeSum(FakeBaseModule):
    def _init_core_module(self):
        self._core = Sum(
            axis=self.attrs["axis"], keepdim=self.attrs.get("keepdims", False)
        )


class FakeUpsample(FakeBaseModule):
    def _init_core_module(self):
        scale_h = self.attrs["scale_h"]
        scale_w = self.attrs["scale_w"]
        self._core = nn.Upsample(scale_factor=(scale_h, scale_w))


class FakeEqual(FakeBaseModule):
    def _init_core_module(self):
        self._core = Equal()


class FakeNotEqual(FakeBaseModule):
    def _init_core_module(self):
        self._core = NotEqual()


class FakeMultiply(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _init_core_module(self):
        if self.inputs[0].startswith("params") and self.inputs[1].startswith("params"):
            self._core = MulNoInput(
                shape_1=self.params[self.inputs[0]].shape,
                constant_1=self.inputs[0].startswith("params/const"),
                shape_2=self.params[self.inputs[1]].shape,
                constant_2=self.inputs[1].startswith("params/const"),
                dtype=self.attrs["dtype"],
            )
        elif self.inputs[0].startswith("params") or self.inputs[1].startswith("params"):
            self.param_index = 0 if self.inputs[0].startswith("params") else 1
            param_shape = self.params[self.inputs[self.param_index]].shape
            constant = self.inputs[self.param_index].startswith("params/const")
            self._core = MulSingle(
                shape=param_shape, dtype=self.attrs["dtype"], constant=constant
            )
        else:
            self._core = MulTwoInputs()

    def load_weights(self):
        if isinstance(self._core, MulNoInput):
            self._core.parameter_1.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[0]].astype(self.attrs["dtype"])
                )
            )
            self._core.parameter_2.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[1]].astype(self.attrs["dtype"])
                )
            )
        elif isinstance(self._core, MulSingle):
            self._core.parameter.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[self.param_index]].astype(
                        self.attrs["dtype"]
                    )
                )
            )

    def export_weights(self):
        if isinstance(self._core, MulNoInput):
            self.params[self.inputs[0]] = (
                self._core.parameter_1.data.detach().cpu().numpy()
            )
            self.params[self.inputs[1]] = (
                self._core.parameter_2.data.detach().cpu().numpy()
            )
        elif isinstance(self._core, MulSingle):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeDivide(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _init_core_module(self):
        if self.inputs[0].startswith("params") and self.inputs[1].startswith("params"):
            self._core = DivNoInput(
                shape_1=self.params[self.inputs[0]].shape,
                constant_1=self.inputs[0].startswith("params/const"),
                shape_2=self.params[self.inputs[1]].shape,
                constant_2=self.inputs[1].startswith("params/const"),
                dtype=self.attrs["dtype"],
            )
        elif self.inputs[0].startswith("params"):
            self.param_index = 0
            param_shape = self.params[self.inputs[self.param_index]].shape
            constant = self.inputs[self.param_index].startswith("params/const")
            self._core = DivLeft(
                shape=param_shape, dtype=self.attrs["dtype"], constant=constant
            )
        elif self.inputs[1].startswith("params"):
            self.param_index = 1
            param_shape = self.params[self.inputs[self.param_index]].shape
            constant = self.inputs[self.param_index].startswith("params/const")
            self._core = DivRight(
                shape=param_shape, dtype=self.attrs["dtype"], constant=constant
            )
        else:
            self._core = DivTwoInputs()

    def load_weights(self):
        if isinstance(self._core, DivNoInput):
            self._core.parameter_1.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[0]].astype(self.attrs["dtype"])
                )
            )
            self._core.parameter_2.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[1]].astype(self.attrs["dtype"])
                )
            )
        elif isinstance(self._core, (DivLeft, DivRight)):
            self._core.parameter.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[self.param_index]].astype(
                        self.attrs["dtype"]
                    )
                )
            )

    def export_weights(self):
        if isinstance(self._core, DivNoInput):
            self.params[self.inputs[0]] = (
                self._core.parameter_1.data.detach().cpu().numpy()
            )
            self.params[self.inputs[1]] = (
                self._core.parameter_2.data.detach().cpu().numpy()
            )
        elif isinstance(self._core, (DivLeft, DivRight)):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeCast(FakeBaseModule):
    def _init_core_module(self):
        self._core = Cast(dtype=self.attrs["dtype"])


class FakePad(FakeBaseModule):
    def _init_core_module(self):
        pad_top, pad_bottom = self.attrs["pad_width"][2]
        pad_left, pad_right = self.attrs["pad_width"][3]
        self._core = Pad(
            pad_top=pad_top,
            pad_bottom=pad_bottom,
            pad_left=pad_left,
            pad_right=pad_right,
        )


class FakeReshape(FakeBaseModule):
    def _init_core_module(self):
        self._core = Reshape(newshape=self.attrs["newshape"])


class FakeMean(FakeBaseModule):
    def _init_core_module(self):
        axis = self.attrs["axis"]
        # FIXME: we need layout parameter here, torch is NCHW layout
        if axis == [1, 2]:
            axis = [2, 3]
        self._core = Mean(axis=axis, keepdims=bool(self.attrs["keepdims"]))


class FakeSqueeze(FakeBaseModule):
    def _init_core_module(self):
        self._core = Squeeze(axis=self.attrs["axis"][0])


class FakeIdentity(FakeBaseModule):
    def __init__(self, node, params, quantization_info):
        super().__init__(node, params, quantization_info)

    def _init_core_module(self):
        self._core = nn.Identity()


class FakeBroadcastToLike(FakeBaseModule):
    def _init_core_module(self):
        if self.inputs[0].startswith("params") or self.inputs[1].startswith("params"):
            self.param_index = 0 if self.inputs[0].startswith("params") else 1
            self._core = BroadcastToLikeSingle(
                init_params=np.atleast_1d(self.params[self.inputs[self.param_index]]),
                param_index=self.param_index,
                constant=self.inputs[self.param_index].startswith("params/const"),
            )
        else:
            self._core = BroadcastToLikeTwoInputs()

    def load_weights(self):
        if isinstance(self._core, BroadcastToLikeSingle):
            self._core.parameter.data.copy_(
                torch.from_numpy(
                    self.params[self.inputs[self.param_index]].astype(
                        self.attrs["dtype"]
                    )
                )
            )

    def export_weights(self):
        if isinstance(self._core, BroadcastToLikeSingle):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeTake(FakeBaseModule):
    def _init_core_module(self):
        self.param_index = 0 if self.inputs[0].startswith("params") else 1
        self._core = Take(
            init_params=np.atleast_1d(self.params[self.inputs[self.param_index]]),
            param_index=self.param_index,
            axis=self.attrs["axis"],
            constant=self.inputs[self.param_index].startswith("params/const"),
        )

    def load_weights(self):
        self._core.parameter.data.copy_(
            torch.from_numpy(self.params[self.inputs[self.param_index]])
        )

    def export_weights(self):
        self.params[self.inputs[self.param_index]] = (
            self._core.parameter.data.detach().cpu().numpy()
        )


class FakeMatMul(FakeBaseModule):
    def _init_core_module(self):
        if self.inputs[0].startswith("params") or self.inputs[1].startswith("params"):
            self.param_index = 0 if self.inputs[0].startswith("params") else 1
            self._core = MatMulSingle(
                init_params=np.atleast_1d(self.params[self.inputs[self.param_index]]),
                param_index=self.param_index,
                constant=self.inputs[self.param_index].startswith("params/const"),
            )
        else:
            self._core = MatMulTwoInputs()

    def load_weights(self):
        if isinstance(self._core, MatMulSingle):
            self._core.parameter.data.copy_(
                torch.from_numpy(self.params[self.inputs[self.param_index]])
            )

    def export_weights(self):
        if isinstance(self._core, MatMulSingle):
            self.params[self.inputs[self.param_index]] = (
                self._core.parameter.data.detach().cpu().numpy()
            )


class FakeTranspose(FakeBaseModule):
    def _init_core_module(self):
        self._core = Transpose(axes=self.attrs["axes"])


class FakeExpandDims(FakeBaseModule):
    def _init_core_module(self):
        self._core = ExpandDims(axis=self.attrs["axis"])


class FakeStridedSlice(FakeBaseModule):
    def _init_core_module(self):
        begin = self.attrs["begin"]
        end = self.attrs["end"]
        strides = self.attrs["strides"]
        input_dims = len(self.attrs["A_shape"][0])
        if len(begin) < input_dims:
            begin = begin + [0] * (input_dims - len(begin))
        if len(end) < input_dims:
            end = end + [
                x + 1 for x in self.attrs["A_shape"][0][(input_dims - len(end)) :]
            ]
        if len(strides) < len(begin):
            strides = strides + [1] * (len(begin) - len(strides))

        self._core = StridedSlice(begin=begin, end=end, strides=strides)


class FakeIdentify(FakeBaseModule):
    def _init_core_module(self):
        self._core = Identify(index=self.attrs["index"])


class FakeCopy(FakeBaseModule):
    def _init_core_module(self):
        self._core = Identify(index=0)


class FakeWhere(FakeBaseModule):
    def _init_core_module(self):
        self._core = Where()


class FakeSplit(FakeBaseModule):
    def _init_core_module(self):
        if type(self.attrs["indices_or_sections"]) == list:
            indices_or_sections = self.attrs["indices_or_sections"][0]
        else:
            indices_or_sections = self.attrs["indices_or_sections"]
        self._core = Split(
            indices_or_sections=indices_or_sections, axis=self.attrs["axis"]
        )

    # FIXME, cant handle multi output currently
    def forward(self, *inputs):
        inputs = [
            preprocessing(x)
            for preprocessing, x in zip(self._preprocessing_list, inputs)
        ]
        return self._core_forward(*inputs)


class FakePack(FakeBaseModule):
    def _init_core_module(self):
        self._core = Pack()


class FakeDropout(FakeBaseModule):
    def _init_core_module(self):
        self._core = nn.Dropout(inplace=True)


module_factory = {
    "Placeholder": FakePlaceholder,
    "nn.conv2d": FakeConv2d,
    "nn.relu": FakeReLU,
    "nn.leaky_relu": FakeLeakyReLU,
    "nn.relu6": FakeReLU6,
    "swish": FakeSwish,
    "exp": FakeExp,
    "clip": FakeReLU6,
    "nn.batch_norm": FakeBatchNorm,
    "nn.max_pool2d": FakeMaxPool2d,
    "add": FakeAdd,
    "nn.global_avg_pool2d": FakeGlobalAvgPooling,
    "nn.batch_flatten": FakeFlatten,
    "nn.dense": FakeDense,
    "nn.adaptive_avg_pool2d": FakeAdaptiveAvgPool2d,
    "sigmoid": FakeSigmoid,
    "multiply": FakeMultiply,
    "divide": FakeDivide,
    "nn.upsampling": FakeUpsample,
    "equal": FakeEqual,
    "cast": FakeCast,
    "nn.pad": FakePad,
    "reshape": FakeReshape,
    "mean": FakeMean,
    "squeeze": FakeSqueeze,
    "Identity": FakeIdentity,
    "nn.layer_norm": FakeLayerNorm,
    "take": FakeTake,
    "nn.batch_matmul": FakeMatMul,
    "transpose": FakeTranspose,
    "expand_dims": FakeExpandDims,
    "subtract": FakeSubtract,
    "nn.softmax": FakeSoftmax,
    "gelu": FakeGeLU,
    "tanh": FakeTanh,
    "nn.avg_pool2d": FakeAvgPool2d,
    "concatenate": FakeConcatenate,
    "sum": FakeSum,
    "strided_slice": FakeStridedSlice,
    "split": FakeSplit,
    "Identify": FakeIdentify,
    "not_equal": FakeNotEqual,
    "broadcast_to_like": FakeBroadcastToLike,
    "where": FakeWhere,
    "reciprocal": FakeReciprocal,
    "nn.bias_add": FakeBiasAdd,
    "Pack": FakePack,
    "nn.dropout": FakeDropout,
    "copy": FakeCopy,
    "erf": FakeErf,
}
