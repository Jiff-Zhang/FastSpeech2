import copy
from nn_compiler.compiler.frontend.frontend_mfg import FrontendMFG


def get_input_node(node):
    inputs = node.inputs
    if inputs is None:
        inputs = []
    res = []
    for id_ in inputs:
        if "#" in id_:
            id_ = id_.split("#")[0]
        if not (id_.startswith("params/") or id_ == ""):
            res.append(id_)
    return res


def find_node(nodes, idx):
    for node in nodes:
        if node.name == idx:
            return node
    return None


def find_unused_node(node_list, in_ids, out_ids, strip_inputs=True):
    all_ids = [node.name for node in node_list]
    flags = dict((id_, False) for id_ in all_ids)
    # left_ids = set(out_ids)
    left_ids = set(out_ids[0] + out_ids[1])
    while left_ids:
        for id_ in left_ids:
            flags[id_] = True
        needed_ids = []
        for id_ in left_ids:
            node = find_node(node_list, id_)
            needed_ids += get_input_node(node)
        needed_ids = [id_ for id_ in needed_ids if id_ not in in_ids]
        left_ids = set(needed_ids)

    if not strip_inputs:
        for id_ in in_ids:
            flags[id_] = True
    return [id_ for id_ in all_ids if not flags[id_]]


def update_cfg(nodes, node_cfg):
    node = find_node(nodes, node_cfg["name"])
    node.update(node_cfg)

class BaseReconstructor:
    def __init__(
        self,
        mf_graph: FrontendMFG,
        input_node_ids,
        output_node_ids,
        update_node_cfg,
        strip_inputs=False,
    ):
        super(BaseReconstructor, self).__init__()
        if update_node_cfg:
            for node_cfg in update_node_cfg:
                update_cfg(mf_graph._node_list, node_cfg)

        self.input_node_ids = (
            copy.deepcopy(input_node_ids) if input_node_ids else list()
        )
        self.input_node_shapes = []
        self.input_node_dtypes = []
        self.output_node_ids = (
            copy.deepcopy(output_node_ids) if output_node_ids else list()
        )
        self.strip_inputs = strip_inputs
        self.node_list = (
            self._find_input_output_nodes(mf_graph._node_list)
            if mf_graph._node_list
            else list()
        )
        if mf_graph._params is not None:
            self.params = self._strip_unused_params(mf_graph._params)
        else:
            self.params = {}
        if mf_graph._quantized_args is not None:
            self.quantization_info = mf_graph._quantized_args
        else:
            self.quantization_info = dict()
        self.table = mf_graph.table
        self.max_data = mf_graph.max_data

        self.input_node_ids = list(set(self.input_node_ids))
        # self.output_node_ids = list(set(self.output_node_ids))
        self.output_node_ids = list(set(self.output_node_ids[0] + self.output_node_ids[1]))
        self.input_node_ids.sort()
        split_str = lambda s: int(s.split('@')[0])
        # self.output_node_ids.sort(key=int)
        self.output_node_ids.sort(key=split_str)

    def get_node_inputs(self, name):
        node = find_node(self.node_list, name)
        if node is None:
            return []
        inputs = node.inputs
        if inputs is None:
            inputs = []
        res = []
        for id_ in inputs:
            if "#" in id_:
                id_ = id_.split("#")[0]
            if not (id_.startswith("params/") or id_ == ""):
                res.append(id_)
        return res

    def _strip_unused_params(self, params):
        used_params = []
        for node in self.node_list:
            inputs = node.inputs
            if inputs is None:
                inputs = []
            if node.op_type == "strided_slice":
                inputs = node.inputs[:1]
            used_params.extend(inputs)

        del_keys = []
        for kk in params:
            if kk not in used_params:
                del_keys.append(kk)
        for key in del_keys:
            del params[key]
        return params

    def _find_input_output_nodes(self, node_list):
        all_node_ids = [node.name for node in node_list]
        all_needed_ids = []
        for node in node_list:
            all_needed_ids += get_input_node(node)

        if not self.input_node_ids:
            for id_ in all_needed_ids:
                if not find_node(node_list, id_).inputs:
                    self.input_node_ids.append(id_)
        assert self.input_node_ids
        if not self.output_node_ids:
            for id_ in all_node_ids:
                if id_ not in all_needed_ids:
                    self.output_node_ids.append(id_)

        for node_name in self.input_node_ids:
            node = find_node(node_list, node_name)
            if node.op_type in ["Placeholder", "QuantPlaceholder"]:
                self.input_node_shapes.append(node.attrs.shape)
                self.input_node_dtypes.append(node.attrs.dtype)

        unused_node_ids = find_unused_node(
            node_list, self.input_node_ids, self.output_node_ids, self.strip_inputs
        )
        node_infos = [node for node in node_list if node.name not in unused_node_ids]
        return node_infos
