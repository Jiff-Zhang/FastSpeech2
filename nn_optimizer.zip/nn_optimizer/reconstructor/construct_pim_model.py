
from nn_optimizer.trainer.pim_moffett_train.timm.models import create_model




def create_torch_model(args):
    model = create_model(
        args.model,
        pretrained=args.pretrained and not args.from_scratch,
        num_classes=args.num_classes,
        drop_rate=args.drop,
        drop_connect_rate=args.drop_connect,  # DEPRECATED, use drop_path
        drop_path_rate=args.drop_path,
        drop_block_rate=args.drop_block,
        global_pool=args.gp,
        bn_tf=args.bn_tf,
        bn_momentum=args.bn_momentum,
        bn_eps=args.bn_eps,
        scriptable=args.torchscript,
        checkpoint_path=args.initial_checkpoint,
        use_kd=args.kd,
        # checkpoint_path = '/home/zhiqiang/models/gluon_resnet50_v1d-818a1b1b.pth'
    )
    if args.kd:
        """
        teacher_model = create_model(
            args.model,
            pretrained=args.pretrained,
            num_classes=args.num_classes,
            drop_rate=args.drop,
            drop_connect_rate=args.drop_connect,  # DEPRECATED, use drop_path
            drop_path_rate=args.drop_path,
            drop_block_rate=args.drop_block,
            global_pool=args.gp,
            bn_tf=args.bn_tf,
            bn_momentum=args.bn_momentum,
            bn_eps=args.bn_eps,
            scriptable=args.torchscript,
            checkpoint_path=None, # no checkpoint for teacher
            use_kd=args.kd,
        )
        """
        teacher_model = create_model(
            args.model,
            pretrained=args.pretrained,
            num_classes=args.num_classes,
            in_chans=3,
            global_pool=args.gp,
            scriptable=args.torchscript,
            use_kd=args.kd,
            checkpoint_path=args.initial_checkpoint,
            # checkpoint_path = '/home/zhiqiang/models/gluon_resnet50_v1d-818a1b1b.pth'
            )
    else:
        teacher_model = None
    return model, teacher_model
