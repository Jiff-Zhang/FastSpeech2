from functools import partial
import torch
import torch.nn as nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np
from nn_compiler.common.pytorch_quantization.nn.modules import _utils
from nn_compiler.common.pytorch_quantization.tensor_quant import QuantDescriptor
from nn_compiler.common.pytorch_quantization.utils import reduce_amax
from typing import Optional, Any


ACTIVATION_QCONFIG = torch.quantization.FakeQuantize.with_args(
    observer=partial(
        torch.quantization.MovingAverageMinMaxObserver, quant_min=-127, quant_max=127
    ),
    qscheme=torch.per_tensor_symmetric,
    quant_min=-127,
    quant_max=127,
    dtype=torch.qint8,
    reduce_range=False,
)


class FakeBaseModule(nn.Module, _utils.QuantInputsMixin):
    def __init__(self, gnode, params, quantization_info):
        super().__init__()
        attrs = gnode.attrs.__dict__
        if attrs is None:
            attrs = {}
        inputs = gnode.inputs
        if inputs is None:
            inputs = []
        self.op_type = gnode.op_type
        self.inputs = inputs
        self.attrs = attrs
        self.name = gnode.name
        self.quant_attrs = gnode.quant_attrs

        self.params = params
        self.quantization_info = quantization_info
        self.module_node = gnode
        self.preprocess = []
        if len(self.inputs) == 0:
            if self.quant_attrs['postprocess'] == 1:
                self.preprocess.append(1)
            else:
                self.preprocess.append(-1)
        else:
            for val, name in zip(self.quant_attrs["preprocess"], self.inputs):
                if name == '':
                    preprocess = -1
                else:
                    preprocess = 1 if attrs['dtype'] == 'int8' else -1
                self.preprocess.append(preprocess)
        self.init_quantizer(self._get_new_fake_quant_module())
        self._core = None

    def _get_new_fake_quant_module(self):
        quant_module_list = []
        for idx, preprocess in enumerate(self.preprocess):
            if preprocess == -1:
                quant_module = None
            else:
                amax = self.quantization_info[self.name]['input_max'][idx]
                if self.op_type == 'nn.batch_matmul' and idx == 1 and 'params' in self.inputs[idx]:
                    if amax is None:
                        amax = reduce_amax(self.params[self.inputs[idx].replace('.', '_')], axis=-1, keepdims=True).numpy()
                    quant_module = QuantDescriptor(num_bits=8, axis=(1), amax=amax)
                elif self.op_type == 'nn.dense' and idx == 1:
                    if amax is None:
                        amax = reduce_amax(self.params[self.inputs[idx].replace('.', '_')], axis=-1, keepdims=True).numpy()
                    quant_module = QuantDescriptor(num_bits=8, axis=(0), amax=amax)
                elif self.op_type in ['nn.conv2d', 'nn.conv2d_transpose'] and idx == 1:
                    if amax is None:
                        amax = reduce_amax(self.params[self.inputs[idx].replace('.', '_')], axis=0, keepdims=True).numpy()
                    quant_module = QuantDescriptor(num_bits=8, axis=(0), amax=amax)
                elif self.op_type in ['nn.conv2d', 'nn.conv2d_transpose', 'nn.batch_matmul', 'nn.dense'] and idx == 2:
                    if amax is None:
                        amax = reduce_amax(self.params[self.inputs[idx].replace('.', '_')], keepdims=True).numpy()
                    quant_module = QuantDescriptor(num_bits=8, axis=(0), amax=amax)
                else:
                    quant_module = QuantDescriptor(num_bits=8, amax=amax)
            quant_module_list.append(quant_module)
        return quant_module_list

    def _check_input_dim(self, input):
        raise NotImplementedError

    def _quant(self, inputs):
        res = []
        for idx, quant_module in enumerate(self._input_quantizer):
            if quant_module is None:
                res.append(inputs[idx])
                continue
            res.append(quant_module(inputs[idx]))
        return res
    
    @staticmethod
    def _get_fake_quant_module(fake_quant_type):
        if fake_quant_type != 1:
            return nn.Identity()
        else:
            return ACTIVATION_QCONFIG()

    def _get_activation_module(self):
        activation_type = self.attrs.get("activation", "")
        if activation_type is None or activation_type == "":
            return nn.Identity()
        elif activation_type == "nn.relu":
            return nn.ReLU(inplace=True)
        elif activation_type == "nn.relu6":
            return nn.ReLU6(inplace=True)
        else:
            raise ValueError("unknown activation type: {}".format(activation_type))

    def _core_forward(self, *inputs):
        """
        override this function if you are not using sub module but call torch function directly
        """
        raise NotImplementedError(
            "all concrete fake module should implement this function"
        )

    def forward(self, *inputs):
        # inputs = [
        #     preprocessing(x)
        #     for preprocessing, x in zip(self._preprocessing_list, inputs)
        # ]
        inputs = self._quant(inputs)
        output = self._core_forward(*inputs)
        return output

    # def load_quantization_info(self):
    #     # pre-process
    #     for index, preprocess in enumerate(self.preprocess):
    #         if preprocess == 1:
    #             observer = self._preprocessing_list[index].activation_post_process
    #             self.load_max_vals_to_observer(
    #                 observer=observer,
    #                 max_vals=self.quantization_info[self.real_inputs[index]].get(
    #                     "output_max"
    #                 ),
    #             )
    #             self.update_observer_to_fakequant(
    #                 observer=observer, fakequant=self._preprocessing_list[index]
    #             )

    @staticmethod
    def load_max_vals_to_observer(observer: torch.quantization.ObserverBase, max_vals):
        # FIXME: schema of max_vals should be fixed
        if isinstance(observer, torch.quantization.PerChannelMinMaxObserver):
            raise NotImplementedError
        elif isinstance(observer, torch.quantization.MinMaxObserver):
            if max_vals is None:
                max_vals = float("inf")
            observer.max_val = torch.tensor(max_vals)
            observer.min_val = torch.tensor(-max_vals)
        else:
            raise TypeError("unknown observer: {}".format(type(observer)))

    @staticmethod
    def get_max_vals_from_observer(observer: torch.quantization.ObserverBase):
        if isinstance(observer, torch.quantization.PerChannelMinMaxObserver):
            max_vals = observer.max_vals.cpu().numpy().flatten()
            min_vals = observer.min_vals.cpu().numpy().flatten()
            return list(
                map(float, np.max(np.abs(np.vstack([max_vals, min_vals])), axis=0))
            )
        elif isinstance(observer, torch.quantization.MinMaxObserver):
            return float(
                max(
                    abs(observer.max_val.cpu().numpy()),
                    abs(observer.min_val.cpu().numpy()),
                )
            )
        else:
            raise TypeError("unknown observer: {}".format(type(observer)))

    @staticmethod
    def update_observer_to_fakequant(observer, fakequant):
        _scale, _zero_point = observer.calculate_qparams()
        _scale, _zero_point = _scale.to(fakequant.scale.device), _zero_point.to(
            fakequant.zero_point.device
        )
        fakequant.scale.resize_(_scale.shape)
        fakequant.scale.copy_(_scale)
        fakequant.zero_point.resize_(_zero_point.shape)
        fakequant.zero_point.copy_(_zero_point)

    # def export_quantization_info(self):
    #     # pre-process
    #     for index, preprocess in enumerate(self.preprocess):
    #         if preprocess == 1:
    #             observer = self._preprocessing_list[index].activation_post_process
    #             output_max = self.get_max_vals_from_observer(observer)
    #             self.quantization_info[self.real_inputs[index]][
    #                 "output_max"
    #             ] = output_max
    #     # post-process
    #     if self.postprocess == 1:
    #         observer = self._postprocessing.activation_post_process
    #         output_max = self.get_max_vals_from_observer(observer)
    #         self.quantization_info[self.name]["output_max"] = output_max

    #     # weight
    #     # quantization is calculated from weight when loading, so we dont have to dump it

    def load_weights(self):
        pass

    def export_weights(self):
        pass

    @property
    def nnz(self):
        return 0

    @property
    def sparsity(self):
        return 0.0

    @property
    def real_inputs(self):
        return self.inputs

    @staticmethod
    def get_max_values_from_observer(observer: torch.quantization.ObserverBase):
        if isinstance(observer, torch.quantization.PerChannelMinMaxObserver):
            max_vals = observer.max_vals.cpu().numpy().flatten()
            min_vals = observer.min_vals.cpu().numpy().flatten()
            return list(
                map(float, np.max(np.abs(np.vstack([max_vals, min_vals])), axis=0))
            )
        elif isinstance(observer, torch.quantization.MinMaxObserver):
            return float(
                max(
                    abs(observer.max_val.cpu().numpy()),
                    abs(observer.min_val.cpu().numpy()),
                )
            )
        else:
            raise TypeError("unknown observer: {}".format(type(observer)))


class FakeConv2d(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.kernel_layout = self.attrs["kernel_layout"]
        l, u, r, b = self.attrs["padding"]
        self.padding = [l, r]
        self.strides = self.attrs["strides"]
        self.groups = self.attrs["groups"]
        self.dilation = tuple(self.attrs["dilation"])
        self.bias_term = self.attrs["bias_term"]
        self.relu_term = self.attrs["relu_term"]
        self.add_term = self.attrs["add_term"]
        self.activation = self.attrs["activation"]
        self.actlut = self.attrs["actlut"]

    def _core_forward(self, *inputs):
        if len(inputs) == 4:
            x, weight, bias, add_tensor = inputs
        else:
            if self.bias_term:
                x, weight, bias = inputs
            else:
                x, weight = inputs
                bias = None
        x = F.conv2d(
            x,
            weight,
            bias,
            self.strides,
            self.padding,
            self.dilation,
            self.groups,
        )
        if self.add_term:
            x = torch.add(x, add_tensor)
        if self.relu_term or self.activation == "nn.relu":
            x = F.relu(x)
        if self.actlut:
            print("ACTLUT Not Implement Yet !!!!")
            raise
        return x

    @property
    def in_channel(self):
        if self.attrs["data_layout"] == "NCHW":
            return self.attrs["A_shape"][0][1]
        elif self.attrs["data_layout"] == "NHWC":
            return self.attrs["A_shape"][0][3]
        else:
            raise ValueError(
                "unknown data_layout: {}".format(self.attrs["data_layout"])
            )

    @property
    def out_channel(self):
        if self.attrs["data_layout"] == "NCHW":
            return self.attrs["O_shape"][0][1]
        elif self.attrs["data_layout"] == "NHWC":
            return self.attrs["O_shape"][0][3]
        else:
            raise ValueError(
                "unknown data_layout: {}".format(self.attrs["data_layout"])
            )

    def is_normal_conv(self):
        return self.groups == 1

    def is_se_conv(self):
        return self.attrs["A_shape"][0][2] == 1 and self.attrs["A_shape"][0][3] == 1

    @property
    def nnz(self):
        return torch.count_nonzero(self._core.weight.data).cpu().numpy()

    @property
    def sparsity(self):
        nnz = torch.count_nonzero(self._core.weight.data)
        size = self._core.weight.data.nelement()
        return 1.0 - (nnz / size).cpu().numpy()


class FakePlaceholder(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.preprocess = [-1]
        # self._preprocessing_list = nn.ModuleList([nn.Identity()])
        self._core = nn.Identity()

    @property
    def real_inputs(self):
        return []

    def _core_forward(self, *inputs):
        return self._core(inputs[0])


class FakeDense(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.bias_term = self.attrs["bias_term"]
        self.relu_term = self.attrs["relu_term"]
        self.add_term = self.attrs["add_term"]
        self.activation = self.attrs["activation"]
        self.actlut = self.attrs["actlut"]

    def _core_forward(self, *inputs):
        if len(inputs) == 4:
            x, weight, bias, add_tensor = inputs
        else:
            if self.attrs["bias_term"]:
                x, weight, bias = inputs
            else:
                x, weight = inputs
                bias = None
        x = F.linear(x, weight, bias)
        if self.add_term:
            x = torch.add(x, add_tensor)
        if self.relu_term or self.activation == "nn.relu":
            x = F.relu(x)
        if self.actlut:
            print("ACTLUT Not Implement Yet !!!!")
            raise
        return x

    @property
    def nnz(self):
        return torch.count_nonzero(self._core.weight.data).cpu().numpy()

    @property
    def sparsity(self):
        nnz = torch.count_nonzero(self._core.weight.data)
        size = self._core.weight.data.nelement()
        return 1.0 - (nnz / size).cpu().numpy()


class FakeCast(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._dtype = self.attrs["dtype"]

    def _core_forward(self, *inputs):
        x = inputs[0]
        if self._dtype == "float32":
            return x.float()
        elif self._dtype == "float64":
            return x.double()
        elif self._dtype == "int32":
            return x.int()
        elif self._dtype == "int64":
            return x.long()
        else:
            raise TypeError(f"unknown type to cast {self._dtype}")


class FakeAdd(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _core_forward(self, *inputs):
        l, r = inputs
        return torch.add(l, r)


class FakeMultiply(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _core_forward(self, *inputs):
        l, r = inputs
        return torch.multiply(l, r)


class FakeReLU(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _core_forward(self, *inputs):
        return F.relu(inputs[0])


class FakeBiasAdd(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.axis = self.attrs["axis"]

    def _core_forward(self, *inputs):
        input_1, input_2 = inputs
        last_axis = input_1.dim() - 1
        if last_axis != self.axis:
            input_1 = torch.transpose(input_1, self.axis, last_axis)
            return torch.transpose(torch.add(input_1, input_2), self.axis, last_axis)
        else:
            return torch.add(input_1, input_2)


class FakeMaxPool2d(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.kernel_size = self.attrs["pool_size"]
        self.strides = self.attrs.get("strides", (1, 1))
        l, u, r, b = self.attrs["padding"]
        self.padding = [l, r]
        self.ceil_mode = bool(self.attrs["ceil_mode"])

    def _core_forward(self, *inputs):
        output = F.max_pool2d(
            inputs[0],
            self.kernel_size,
            stride=self.strides,
            padding=self.padding,
            dilation=1,
            ceil_mode=self.ceil_mode,
            return_indices=False,
        )
        return output


class FakeGlobalAvgPool2d(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)

    def _core_forward(self, *inputs):
        output = F.adaptive_avg_pool2d(inputs[0], 1)
        return output


class FakeBatchFlatten(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._core = nn.Flatten()

    def _core_forward(self, *inputs):
        output = self._core(inputs[0])
        return output


class FakePack(FakeBaseModule):
    def _core_forward(self, *inputs):
        return inputs


class FakeCopy(FakeBaseModule):
    def _core_forward(self, *inputs):
        return inputs[0]


class FakeDivide(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.divide(inputs[0], inputs[1])


class FakeErf(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.erf(inputs[0])


class FakeExpandDims(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.dim = self.attrs["axis"]

    def _core_forward(self, *inputs):
        return torch.unsqueeze(inputs[0], dim=self.dim)


class FakeIdentify(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.index = self.attrs["index"]

    def _core_forward(self, *inputs):
        return inputs[self.index]


class FakeBatchMatMul(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.bias_term = self.attrs["bias_term"]
        self.relu_term = self.attrs["relu_term"]
        self.add_term = self.attrs["add_term"]
        self.activation = self.attrs["activation"]
        self.actlut = self.attrs["actlut"]

    def _core_forward(self, *inputs):
        if len(inputs) == 4:
            x, weight, bias, add_tensor = inputs
        else:
            if self.attrs["bias_term"]:
                x, weight, bias = inputs
            else:
                x, weight = inputs
                bias = None
        x = torch.matmul(x, torch.transpose(weight, -1, -2))
        if self.bias_term:
            x = torch.add(x, bias)
        if self.add_term:
            x = torch.add(x, add_tensor)
        if self.relu_term or self.activation == "nn.relu":
            x = F.relu(x)
        if self.actlut:
            print("ACTLUT Not Implement Yet !!!!")
            raise
        return x


class FakeDropout(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._core = nn.Dropout(0.0, inplace=False)

    def _core_forward(self, *inputs):
        return self._core(inputs[0])


class FakeLayerNorm(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.normalized_shape = self.attrs["A_shape"][1]
        self.eps = self.attrs["epsilon"]
        self.axis = self.attrs["axis"]

    def _core_forward(self, *inputs):
        bias = None
        if len(inputs) > 2:
            bias = inputs[2]
        output = F.layer_norm(
            inputs[0], self.normalized_shape, inputs[1], bias, eps=self.eps
        )
        return output


class FakeSoftmax(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._core = nn.Softmax(dim=self.attrs["axis"])

    def _core_forward(self, *inputs):
        return self._core(inputs[0])


class FakeReshape(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.newshape = self.attrs["newshape"]

    def _core_forward(self, *inputs):
        return torch.reshape(inputs[0], self.newshape)


class FakeStridedSlice(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.slices = [
            slice(b, e, s)
            for b, e, s in zip(
                self.attrs["begin"], self.attrs["end"], self.attrs["strides"]
            )
        ]

    def _core_forward(self, *inputs):
        return inputs[0][self.slices]


class FakeSubtract(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.subtract(inputs[0], inputs[1])


class FakeTake(FakeBaseModule):
    def _core_forward(self, *inputs):
        left, right = inputs
        if len(right.shape) == 0:
            output = torch.select(left, self.attrs["axis"], right)
        else:
            output = left[right.long()]
        return output


class FakeTanh(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.tanh(inputs[0])


class FakeSqrt(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.sqrt(inputs[0])


class FakeRsqrt(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.rsqrt(inputs[0])


class FakeExp(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.exp(inputs[0])


class FakeClip(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._min = self.attrs["a_min"]
        self._max = self.attrs["a_max"]

    def _core_forward(self, *inputs):
        x = inputs[0]
        x = torch.clamp(x, min=self._min, max=self._max)
        return x


class FakeTranspose(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self.axes = self.attrs["axes"]

    def _core_forward(self, *inputs):
        return inputs[0].permute(*self.axes)


class FakeMean(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._axis = self.attrs["axis"]
        self._keepdims = self.attrs["keepdims"]

    def _core_forward(self, *inputs):
        return torch.mean(inputs[0], self._axis, self._keepdims)


class FakeGelu(FakeBaseModule):
    def _core_forward(self, *inputs):
        return F.gelu(inputs[0])


class FakeReciprocal(FakeBaseModule):
    def _core_forward(self, *inputs):
        return torch.reciprocal(inputs[0])


class FakeSum(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super().__init__(gnode, params, quantization_info)
        self._axis = self.attrs["axis"]
        self._keepdims = self.attrs["keepdims"]

    def _core_forward(self, *inputs):
        return torch.sum(inputs[0], self._axis, self._keepdims)

class FakeBatchNorm(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(FakeBatchNorm, self).__init__(gnode, params, quantization_info)
        in_channel = self.attrs["A_shape"][1][0]
        self.num_features = self.attrs["A_shape"][1][0]
        self.eps = self.attrs["epsilon"]
        self.momentum = 0.1
        # self.affine = affine
        self.dtype =self.attrs['dtype']
        self.track_running_stats = True
        # self.register_buffer('running_mean', torch.zeros(self.num_features))
        # self.register_buffer('running_var', torch.ones(self.num_features))
    #     self.running_mean: Optional[torch.Tensor]
    #     self.running_var: Optional[torch.Tensor]
    # def reset_running_stats(self) -> None:
    #     if self.track_running_stats:
    #         # running_mean/running_var/num_batches... are registered at runtime depending
    #         # if self.track_running_stats is on
    #         self.running_mean.zero_()  # type: ignore[union-attr]
    #         self.running_var.fill_(1)  # type: ignore[union-attr]
    #         self.num_batches_tracked.zero_()  # type: ignore[union-attr,operator]
    def _check_input_dim(self, input):
        if input.dim() != 2 and input.dim() != 3:
            raise ValueError("expected 2D or 3D input (got {}D input)".format(input.dim()))
        return
    def _core_forward(self, *inputs):
        x, weight, bias, running_mean, running_var = inputs
        # self._check_input_dim(input)

        if self.momentum is None:
            exponential_average_factor = 0.0
        else:
            exponential_average_factor = self.momentum
        # if self.training and self.track_running_stats:
        #     if self.num_batches_tracked is not None:  # type: ignore[has-type]
        #         self.num_batches_tracked = self.num_batches_tracked + 1  # type: ignore[has-type]
        #         if self.momentum is None:  # use cumulative moving average
        #             exponential_average_factor = 1.0 / float(self.num_batches_tracked)
        #         else:  # use exponential moving average
        #             exponential_average_factor = self.momentum
        
        if self.training:
            bn_training = True
        else:
            bn_training = False #(self.running_mean is None) and (self.running_var is None)

        x = F.batch_norm(
            x,
            running_mean,
            running_var,
            weight,
            bias,
            bn_training,
            exponential_average_factor,
            self.eps
        )
        return x

class Fakeavg_pool2d(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(Fakeavg_pool2d, self).__init__(gnode, params, quantization_info)
        self.kernel_size = tuple(self.attrs['pool_size'])
        self.stride = tuple(self.attrs['strides'])
        self.padding = tuple([self.attrs['padding'][0], self.attrs['padding'][2]])
        self.ceil_mode = self.attrs['ceil_mode'] == 1
        self.count_include_pad = self.attrs['count_include_pad'] == 1
        self.divisor_override = None
    
    def _core_forward(self, *inputs) -> Tensor:
        return F.avg_pool2d(inputs[0], self.kernel_size, self.stride,
                            self.padding, self.ceil_mode, self.count_include_pad, self.divisor_override)

class FakeSigmoid(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(FakeSigmoid, self).__init__(gnode, params, quantization_info)
    
    def forward(self, *input) -> Tensor:
        # "nn.functional.sigmoid is deprecated. Use torch.sigmoid instead."
        return torch.sigmoid(input[0])

class Fakeleaky_relu(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(Fakeleaky_relu, self).__init__(gnode, params, quantization_info)
        negative_slope: float = 1e-2
        inplace: bool = True
        self.negative_slope = 0.1 # self.attrs['alpha']
        self.inplace = inplace

    def forward(self, *input: Tensor) -> Tensor:
        return F.leaky_relu(input[0], self.negative_slope, self.inplace)

class Fakeimage_resize(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(Fakeimage_resize, self).__init__(gnode, params, quantization_info)
        self.A_shape = self.attrs['A_shape']
        self.O_shape = self.attrs['O_shape']
        self.size = self.attrs['size']
        self.method = 'nearest' if self.attrs['method'] == 'nearest_neighbor' else self.attrs['method']
    def forward(self, *input) -> Tensor:
        scale = self.O_shape[0][-1]/self.A_shape[0][-1]
        assert int(scale*1000)%10 == 0, 'wrong scale for image.resize'
        scale = int(scale)
        # return F.interpolate(input[0], size=self.attrs['O_shape'][0][2:], mode='nearest')
        return F.interpolate(input[0], size=[input[0].shape[2]*2, input[0].shape[3]*2], mode='nearest')
        

class Fakeconcatenate(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(Fakeconcatenate, self).__init__(gnode, params, quantization_info)
        self.A_shape = self.attrs['A_shape']
        self.O_shaple = self.attrs['O_shape']
        self.dim = self.attrs['axis']
    def forward(self, *input) -> Tensor:
        return torch.cat(input[0], self.dim)

class Fakepower(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(Fakepower, self).__init__(gnode, params, quantization_info)
        self.A_shape = self.attrs['A_shape']
        self.O_shaple = self.attrs['O_shape']
    def forward(self, *input) -> Tensor:
        x, n = input
        return torch.pow(x, n)

class Fakepad(FakeBaseModule):
    def __init__(self, gnode, params, quantization_info):
        super(Fakepad, self).__init__(gnode, params, quantization_info)
        self.pad_mode =self.attrs['pad_mode']
        self.pad = tuple([y for x in self.attrs['pad_width'] for y in x])
        # self.pad = tuple(self.attrs['pad_width'])
    def forward(self, *input) -> Tensor:
        x, pad_val = input
        # return torch.nn.functional.pad(x, self.pad, self.pad_mode, pad_val)
        return x # at present, nn.pad is useless. once we really need nn.pad, the above line should be uncommented out

module_factory = {
    "add": FakeAdd,
    "cast": FakeCast,
    "clip": FakeClip,
    "copy": FakeCopy,
    "divide": FakeDivide,
    "erf": FakeErf,
    "exp": FakeExp,
    "expand_dims": FakeExpandDims,
    "gelu": FakeGelu,
    "Identify": FakeIdentify,
    "mean": FakeMean,
    "multiply": FakeMultiply,
    "nn.batch_flatten": FakeBatchFlatten,
    "nn.batch_matmul": FakeBatchMatMul,
    "nn.bias_add": FakeBiasAdd,
    "nn.conv2d": FakeConv2d,
    "nn.dense": FakeDense,
    "nn.dropout": FakeDropout,
    "nn.global_avg_pool2d": FakeGlobalAvgPool2d,
    "nn.layer_norm": FakeLayerNorm,
    "nn.max_pool2d": FakeMaxPool2d,
    "nn.relu": FakeReLU,
    "nn.softmax": FakeSoftmax,
    "Pack": FakePack,
    "Placeholder": FakePlaceholder,
    "reciprocal": FakeReciprocal,
    "reshape": FakeReshape,
    "sqrt": FakeSqrt,
    "sqrt_recip": FakeRsqrt,
    "strided_slice": FakeStridedSlice,
    "subtract": FakeSubtract,
    "sum": FakeSum,
    "take": FakeTake,
    "tanh": FakeTanh,
    "transpose": FakeTranspose,
    "nn.batch_norm": FakeBatchNorm,
    "nn.avg_pool2d": Fakeavg_pool2d,
    "sigmoid": FakeSigmoid,
    "nn.leaky_relu": Fakeleaky_relu,
    "image.resize": Fakeimage_resize,
    "concatenate": Fakeconcatenate,
    "power": Fakepower,
    "nn.pad": Fakepad,
}
