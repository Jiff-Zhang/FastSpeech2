# --------------------------------------------------------
# [NLP Training Pipeline]
# Copyright (c) 2022 Moffett.AI
# Licensed under Moffett.AI
# Written by CW
# --------------------------------------------------------

"""
    Finetuning a model for nlp task(GLUE, SQUAD, etc.).
    Run tips:
    i.   Run: accelerate config
    ii.  Reply the questions in order to setup your configuration
    iii. Run this script like:

    OMP_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false MPLBACKEND='Agg' \
        accelerate launch run_qa.py --config [CONFIG_FILE]
"""

import os
import math
import argparse

from datetime import timedelta
from typing import Dict, List, Tuple, Union

from torch.optim import optimizer
from torch.utils.data.dataloader import DataLoader

from accelerate import Accelerator, DistributedType, InitProcessGroupKwargs
from transformers.utils.versions import require_version

require_version("datasets>=1.8.0", 
                "To fix: pip install -r examples/pytorch/text-classification/requirements.txt")

# Add root directory of project to the system path
import sys

BASE_DIR = os.path.dirname(__file__)
ROOT = os.path.join(BASE_DIR, '..')
sys.path.append(ROOT)

from utils.seed import setup_seed
from utils.logger import build_logger
from utils.misc import Timer, cmp_models
from utils.pruning import test_model_sparsity
from utils.dist import init_accelerator, kill_all_process
from utils.deepspeed_helpers import init_ds_engine, init_hf_dscfg

from data.builder import build_data_container
from models.builder import build_model, build_model_config

from engine.pruner import build_pruner
from engine.trainer import build_trainer

from engine.optim.optimizer import build_optimizer
from engine.optim.lr_scheduler import build_lr_scheduler

from engine.ckpt import load_checkpoint, build_resume_loader, is_torch_fp32_ckpt, is_deepspeed_styled_ckpt

from config.cfg import get_config_from_args


def parse_args():
    parser = argparse.ArgumentParser(description="Finetune a model on a nlp task")

    parser.add_argument('--config', type=str, default=None, help='path to config file(yaml or py)')
    parser.add_argument('--epochs', type=int, help='training epochs')
    parser.add_argument('--prune', action='store_true', help='do pruning')
    parser.add_argument('--kd', action='store_true', help='do knowledge distillation')
    parser.add_argument('--debug', action='store_true', help='turn on debug mode')
    parser.add_argument('--num_debug_samples', type=int, default=-1, help='Num samples will be selected when in debug mode')
    parser.add_argument('--local_rank', type=int, default=0, help='process local rank(will set by environment by default)')

    return parser.parse_args()


def _build_model(cfg, model_config, logger):
    """Build model(w teacher if kd)."""

    model = build_model(
        cfg.model,
        default_args=dict(model_config=model_config, logger=logger)
    )
    # Load checkpoint if needed
    model_ckpt_cfg = cfg.model.get('checkpoint')
    if model_ckpt_cfg:
        if is_torch_fp32_ckpt(model_ckpt_cfg):
            load_checkpoint(model_ckpt_cfg, model, logger)

    teacher = teacher_ckpt_cfg = None
    if cfg.kd_cfg.enable:
        teacher = build_model(
            cfg.teacher,
            default_args=dict(model_config=model_config, logger=logger, obj='teacher')
        )
        teacher.eval()

        # Load checkpoint if needed
        teacher_ckpt_cfg = cfg.teacher.get('checkpoint')
        if teacher_ckpt_cfg and is_torch_fp32_ckpt(teacher_ckpt_cfg):
            load_checkpoint(teacher_ckpt_cfg, teacher, logger, obj='teacher')
    
    return model, model_ckpt_cfg, teacher, teacher_ckpt_cfg


def get_batch_size_of_data_split(dataloaders: Dict[str, Union[None, DataLoader]]) -> Dict[str, Union[int, None]]:
    batch_sizes = {}.fromkeys(dataloaders.keys())
    for dataloader_key, dataloader in dataloaders.items():
        if dataloader is not None:
            batch_sizes[dataloader_key] = dataloader.batch_size

    return batch_sizes


def _prepare_dataloaders(dataloaders: dict, accelerator: Accelerator):
    """Wrap dataloaders by Accelerator."""

    for dataloader_key, dataloader in dataloaders.items():
        if dataloader is not None:
            # Note: only PyTorch `DataLoader` will be prepared.
            # So, if u use other types of DataLoader, please handle this by yourself.
            dataloaders[dataloader_key] = accelerator.prepare(dataloader)


def _prepare_modules(modules: Union[List, Tuple], accelerator: Accelerator):
    """Wrap modules by Accelerator."""

    prepared_modules = list(modules)
    for i, m in enumerate(modules):
        if m is not None:
            prepared_modules[i] = accelerator.prepare(m)

    return prepared_modules


def _linear_scale_lr(cfg):
    """Linear scaling lr strategy, according the total batch size."""

    cfg.defrost()

    total_batch_size = cfg.train.batch_size * accelerator.num_processes * cfg.trainer.grad_accumulation_steps
    scaled = total_batch_size / cfg.train.base_batch_size
    
    cfg.train.lr *= scaled
    cfg.train.min_lr *= scaled
    cfg.train.warmup_lr *= scaled

    cfg.freeze()


def _do_resume(cfg, model, optimizer, lr_scheduler, logger):
    """Resuming historical states."""

    resume_cfg = cfg.get('auto_resume')
    if not resume_cfg or not resume_cfg.enabled:
        return False, None

    resume_loader = build_resume_loader(
        resume_cfg.checkpoint,
        default_args=dict(model=model)
    )
    resumed_states = resume_loader.resume(optimizer=optimizer, lr_scheduler=lr_scheduler)

    logger.info(f"Note: resume states from '{resume_loader.path}'.")
    del resume_loader

    lr = resumed_states.pop('lr')
    metric = resumed_states.get('metric')
    epoch = resumed_states.pop('epoch', 0)

    cfg.defrost()
    cfg.trainer.start_epoch = epoch + 1
    cfg.freeze()

    logger.info(
        f"\n[Resume Info]\n"
        f"Epoch: {epoch}(next: {cfg.trainer.start_epoch})\nLr: {lr:.10f}\nMetric: {metric}\n"
    )

    return True, resume_cfg.get('pruner_resume_dict', {})


if __name__ == '__main__':
    '''i. Arguments & Configs'''
    args = parse_args()
    cfg = get_config_from_args(args)

    '''ii. Logger'''
    logger = build_logger(cfg)

    '''iii. Distributed wrappers(e.g. Accelerator, DeepSpeedEngine)'''
    init_pg_handler = InitProcessGroupKwargs()
    init_pg_handler.timeout = timedelta(seconds=7200)
    # Accelerator
    # We will let the accelerator handle device placement for us.
    accelerator = Accelerator(kwargs_handlers=[init_pg_handler])
    # We only want one process per machine to log things on the screen.
    init_accelerator(accelerator)

    # DeepSpeed
    # HuggingFace style DeepSpeed global config, which can detect/retrieve all deepspeed related status
    hfds_cfg = None
    enable_deepspeed = False
    if cfg.get('deepspeed'):
        enable_deepspeed = cfg.deepspeed.enabled
    if enable_deepspeed:
        # An instance of HfDeepSpeedConfig class
        # Note: we must instantiate this object before instantiating the model,
        # and it’s important that this object remains alive while the program is still running.
        # This object is used for quering for things about DeepSpeed status(e.g ZeRO stage)
        hfds_cfg = init_hf_dscfg(cfg.deepspeed, cfg.model.pretrained_id, logger)

    '''iv. Random Seed'''
    setup_seed(cfg.seed)

    # Log some basic info
    logger.info(f"\n[Process Id]: {os.getpid()}\n[Random seed]: {cfg.seed}\n{accelerator.state}")
    # Sync all processes
    accelerator.wait_for_everyone()

    '''v. Dataset'''
    with Timer(logger, job='Load data'):
        # Some arguments required by DataContainer's 'gen_features()' method
        # We pop it & use it later, cuz DataContainer's initialization don't need them.
        gen_features_args = cfg.data.pop('gen_features_args', {})
        data_container = build_data_container(
            cfg.data,
            default_args=dict(
                train_batch_size=cfg.train.batch_size,
                val_batch_size=cfg.val.batch_size,
                test_batch_size=cfg.test.batch_size,
                use_fp16=accelerator.use_fp16,
                seed=cfg.seed,
                rank=cfg.local_rank,  # this will set by environment if u didn't pass this argument through cmd
                logger=logger,
                debug=cfg.debug  # we will random select few samples if in debug mode
            )
        )

    '''vi. Model(w Tokenizer)'''
    # In distributed training, the 'from_pretrained' methods guarantee that 
    # only one local process can concurrently download model & vocab.
    tokenizer = build_model(cfg.tokenizer, default_args=dict(logger=logger))
    model_config = build_model_config(cfg.model_config, default_args=dict(logger=logger))
    # model_config.label2id, model_config.id2label may modified according to dataset fields.
    data_container.gen_features(tokenizer, model_config=model_config, accelerator=accelerator, **gen_features_args)
    # Note: if not in kd mode, teacher & teacher_ckpt_cfg will be None.
    model, model_ckpt_cfg, teacher, teacher_ckpt_cfg = _build_model(cfg, model_config, logger)

    '''vii. Dataloader'''
    with Timer(logger, job='Build dataloaders'):
        # A dict: {'train': DataLoader(), 'validation': DataLoader(), 'test': DataLoader()}
        dataloaders = data_container.get_dataloaders(tokenizer=tokenizer, model=model, accelerator=accelerator)
        
        # Note: better to get batch size here cuz it may be lost when the dataloader wrapped by accelerator
        batch_sizes = get_batch_size_of_data_split(dataloaders)
        train_batch_size = batch_sizes[data_container.train_data_key]
        val_batch_size = batch_sizes[data_container.val_data_key]
        test_batch_size = batch_sizes[data_container.test_data_key]

        # In multi-process, each will get its own individual data
        # (cuz the length of dataloader would be shorter than the original)
        _prepare_dataloaders(dataloaders, accelerator)
        train_dataloader, val_dataloader, test_dataloader = dataloaders[data_container.train_data_key], \
            dataloaders[data_container.val_data_key], dataloaders[data_container.test_data_key]

    '''viii. Optimizer & Lr Scheduler'''
    # Linear scale the learning rate according to total batch size
    if cfg.train.linear_scaled_lr:
        _linear_scale_lr(cfg)

    optimizer = build_optimizer(model, cfg)
    logger.info(f"Build optimizer: {str(optimizer)}\n")
    if cfg.optimizer.type == 'child_tuning_adamw' and cfg.optimizer.mode == 'D':
        optimizer.set_grad_mask(model=model, dataloader=train_dataloader, max_grad_norm=1.)

    # Note: num_update_steps considers gradient accumulation,
    # this is the frequency that lr scheduler updates.
    lr_scheduler, num_update_steps = build_lr_scheduler(optimizer, cfg, len(train_dataloader))

    '''ix. Wrapped Model'''
    model_unwrapped = model

    # By DeepSpeed
    if enable_deepspeed:
        # Note: we don't feed lr scheduler into DeepSpeedEngine
        # cuz our pruner need to control the lr scheduling.
        model, optimizer, teacher, _ = init_ds_engine(
            model, hfds_cfg.config,
            optimizer=optimizer,
            teacher=teacher
        )
        model_unwrapped = model.module

        # Load checkpoint if needed
        if model_ckpt_cfg and is_deepspeed_styled_ckpt(model_ckpt_cfg):
            load_checkpoint(model_ckpt_cfg, model, logger)
        if teacher is not None and teacher_ckpt_cfg and is_deepspeed_styled_ckpt(teacher_ckpt_cfg):
            load_checkpoint(teacher_ckpt_cfg, teacher, logger, obj='teacher')
    # By Accelerate
    else:
        model, optimizer, teacher = _prepare_modules((model, optimizer, teacher), accelerator)

    '''x. Auto Resume(if needed)'''
    resume, pruner_resume_dict = _do_resume(cfg, model, optimizer, lr_scheduler, logger)
    if resume:
        # If resumed from previous state, we shourld re-compute the update steps.
        num_update_steps = (cfg.trainer.epochs - cfg.trainer.start_epoch) * \
            math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps)

    if cfg.test_sparsity:
        test_model_sparsity(model_unwrapped, cfg.model.pretrained_id, logger)

    '''xi. Pruner'''
    num_update_steps_total = cfg.trainer.epochs * \
        (math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps))
    pruner = build_pruner(
        cfg.pruner,
        default_args=dict(
            prune=cfg.train.prune,
            model=model_unwrapped,
            model_name=cfg.model.name,
            optimizer=(optimizer.optimizer if enable_deepspeed and not model.amp_enabled() else optimizer),
            num_steps=num_update_steps_total,
            steps_per_epoch=len(train_dataloader),
            pruner_resume_dict=pruner_resume_dict,
            logger=logger,
            log_path=logger.log_dir,
            rank=cfg.local_rank,
            model_config=model_config
        )
    )

    if pruner is not None:
        # Make sure that model in pruner is the same object as the global
        # and check their parameters one-by-one
        cmp_models(pruner.model, model_unwrapped)

        # Make sure that pruner's start step equals the global's,
        # especially in resuming case.
        start_step = cfg.trainer.start_epoch * (math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps))
        if pruner.step != start_step:
            raise RuntimeError(f"pruner start step:{pruner.step} != global start step:{start_step}.")

    # Log config
    logger.info(f"\n[Config]\n{cfg.dump()}\n")
    # Sync all processes
    accelerator.wait_for_everyone()

    num_train_samples = len(data_container.features[data_container.train_data_key]) if train_dataloader is not None else 0
    num_val_samples = len(data_container.features[data_container.val_data_key]) if val_dataloader is not None else 0
    num_test_samples = len(data_container.features[data_container.test_data_key]) if test_dataloader is not None else 0
    
    num_epochs = cfg.trainer.epochs - cfg.trainer.start_epoch
    num_train_steps = num_epochs * len(train_dataloader)
    
    total_train_batch_size = train_batch_size * accelerator.num_processes * cfg.trainer.grad_accumulation_steps

    # Log Training info
    logger.info("\n***** Start Training *****")

    logger.info(f"  Num epochs = {num_epochs}")

    logger.info(f"  Train batch size(per dev) = {train_batch_size}")
    # batch size per device x num devices x gradient accumulation steps
    logger.info(f"  Total train batch size = {total_train_batch_size}")
    if val_batch_size is not None:
        logger.info(f"  Val batch size(per dev) = {val_batch_size}")
    if test_batch_size is not None:
        logger.info(f"  Test batch size(per dev) = {test_batch_size}")

    logger.info(f"  Num train samples(all devs) = {num_train_samples}")
    logger.info(f"  Num val samples(all devs) = {num_val_samples}")
    logger.info(f"  Num test samples(all devs) = {num_test_samples}")

    logger.info(f"  Num train steps(per dev) = {num_train_steps}")
    logger.info(f"  Num update steps(per dev) = {num_update_steps}")
    logger.info(f"  Num gradient Accumulation steps = {cfg.trainer.grad_accumulation_steps}\n")

    '''xii. Trainer'''
    # Trainer is an object which will do all of training jobs, e.g. gets batched data, model forwarding, 
    # computes loss, optimizes parameters, updates lr, saving checkpoints, etc.
    trainer = build_trainer(
        cfg.trainer,
        default_args=dict(
            model=model,
            teacher=teacher,
            optimizer=optimizer,
            lr_scheduler=lr_scheduler, tokenizer=tokenizer,
            logger=logger, output_dir=logger.log_dir, rank=cfg.local_rank, pruner=pruner, kd_cfg=cfg.kd_cfg
        )
    )
    # Hooks behaviors decide what will trainer do during each stage.
    trainer.register_training_hooks(cfg.hooks)

    # Training loop
    accelerator.wait_for_everyone()
    trainer.run(data_container, pruner=pruner, accelerator=accelerator, **cfg.trainer_run_args)

    '''xiii. Dealloc'''
    accelerator.wait_for_everyone()
    
    if hfds_cfg is not None:
        del hfds_cfg

    # Release all references to the internal objects stored and call the garbage collector
    accelerator.free_memory()
    if accelerator.distributed_type == DistributedType.MULTI_GPU:
        # Destroy all processes, and de-initialize the distributed package
        kill_all_process()
