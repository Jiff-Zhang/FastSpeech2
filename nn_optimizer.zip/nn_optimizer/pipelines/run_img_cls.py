# --------------------------------------------------------
# [Image Classification Training Pipeline]
# Copyright (c) 2022 Moffett.AI
# Licensed under Moffett.AI
# Written by CW
# --------------------------------------------------------

"""
    Training a model for image classification task(ImageNet, CIFAR, etc.).
    Run tips:
    MPLBACKEND='Agg' CUDA_VISIBLE_DEVICES=0,1,2,.. \
        torchrun --standalone --nnodes=1 --nproc_per_node=$NUM_TRAINERS run_img_cls.py --config [PATH_TO_CONFIG_FILE]
"""

import os
import math
import torch
import argparse

from torch.nn.parallel import DistributedDataParallel as DDP

import sys

BASE_DIR = os.path.dirname(__file__)
sys.path.append(os.path.join(BASE_DIR, '..'))

from utils.seed import setup_seed
from utils.logger import build_logger
from utils.misc import Timer, cmp_models
from utils.dist import init_process_group, get_world_size, kill_all_process
from engine.ckpt.ckpt_loader import is_torch_fp32_ckpt, build_resume_loader, load_checkpoint

from models.builder import build_model
from data.builder import build_data_container

from engine.pruner import build_pruner
from engine.trainer import build_trainer

from engine.optim.optimizer import build_optimizer
from engine.optim.lr_scheduler import build_lr_scheduler

from config.cfg import get_config_from_args


def parse_args():
    parser = argparse.ArgumentParser(
        description="Finetune a model on a nlp task"
    )

    # Note: if u don't specify a config file, we will instead use a defualt file which may not satisfy your demand.
    parser.add_argument('--config', type=str, default=None, help='path to config file(yaml or py)')
    parser.add_argument('--epochs', type=int, help='training epochs')
    parser.add_argument('--prune', action='store_true', help='do pruning')
    parser.add_argument('--kd', action='store_true', help='do knowledge distillation')
    # When turning on the debug switch, we will only load a subset of data, for quick verification.
    parser.add_argument('--debug', action='store_true', help='turn on debug mode')

    return parser.parse_args()


def _build_model(cfg, logger):
    """Build model(w teacher if kd)."""
    model = build_model(
        cfg.model,
        default_args=dict(
            logger=logger,
            rank=cfg.local_rank,
            num_classes=cfg.data.num_classes
        )
    )
    # Load checkpoint if needed
    model_ckpt_cfg = cfg.model.get('checkpoint')
    if model_ckpt_cfg:
        if is_torch_fp32_ckpt(model_ckpt_cfg):
            load_checkpoint(model_ckpt_cfg, model, logger)

    teacher = teacher_ckpt_cfg = None
    if cfg.trainer.kd:
        teacher = build_model(
            cfg.teacher,
            default_args=dict(
                logger=logger,
                rank=cfg.local_rank,
                num_classes=cfg.data.num_classes
            )
        )

        # Load checkpoint if needed
        teacher_ckpt_cfg = cfg.teacher.get('checkpoint')
        if teacher_ckpt_cfg and is_torch_fp32_ckpt(teacher_ckpt_cfg):
            load_checkpoint(teacher_ckpt_cfg, teacher, logger, obj='teacher')
        
        teacher.eval()
    
    # device_ids=[torch.cuda.current_device()]
    return model, model_ckpt_cfg, teacher, teacher_ckpt_cfg


def _distributed_wrap_model(model, device_ids=None):
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())

    with torch.cuda.stream(stream):
        model = DDP(model, device_ids=device_ids)
    torch.cuda.current_stream().wait_stream(stream)

    return model


def _linear_scale_lr(cfg):
    """Linear scaling lr strategy, according the total batch size."""

    cfg.defrost()

    scaled = cfg.train.batch_size * get_world_size() * \
        cfg.trainer.grad_accumulation_steps / cfg.train.base_batch_size
    cfg.train.lr *= scaled
    cfg.train.min_lr *= scaled
    cfg.train.warmup_lr *= scaled

    cfg.freeze()


def _do_resume(cfg, model, optimizer, lr_scheduler, logger):
    """Resuming historical states."""

    resume_cfg = cfg.get('auto_resume')
    if not resume_cfg or not resume_cfg.enabled:
        return False, None

    resume_loader = build_resume_loader(
        resume_cfg.checkpoint,
        default_args=dict(model=model)
    )
    resumed_states = resume_loader.resume(optimizer=optimizer, lr_scheduler=lr_scheduler)
    logger.info(f"Note: resume states from '{resume_loader.path}'.")
    del resume_loader

    lr = resumed_states.pop('lr')
    metric = resumed_states.get('metric')
    epoch = resumed_states.pop('epoch', 0)
    cfg.defrost()
    cfg.trainer.start_epoch = epoch + 1
    cfg.freeze()
    logger.info(
        f"[Resume Info]"
        f"Epoch:{epoch}(next:{cfg.trainer.start_epoch}); Lr:{lr}; Metric:{metric}\n"
    )

    pruner_ckpt_path = None
    if resume_cfg.get('pruner_checkpoint'):
        pruner_ckpt_path = resume_cfg.pruner_checkpoint.path

    return True, pruner_ckpt_path


if __name__ == '__main__':
    '''i. Parse arguments & Update configs'''
    args = parse_args()
    cfg = get_config_from_args(args)

    '''ii. Set logger'''
    # This logger will print info to console(only the main process) and log them to file at the same time.
    logger = build_logger(cfg)

    '''iii. Distribution process Initialization'''
    distributed = int(os.environ['WORLD_SIZE']) > 1
    logger.info(f"Distributed Traning: {distributed}")
    if distributed:
        logger.info(f"[Local Rank] {cfg.local_rank}")
        # Let process & gpu one-to-one.
        torch.cuda.set_device(cfg.local_rank)
        init_process_group()
    logger.info("Current device: " + f"gpu[{torch.cuda.current_device()}/{get_world_size()}]" if torch.cuda.is_available() else "cpu")

    '''iv. Fix random seed'''
    # seed = cfg.seed + cfg.local_rank
    seed = setup_seed(cfg.seed, use_rank_shift=True)
    logger.info(f"\nProcess id: {os.getpid()}\nRandom seed: {seed}\n")

    '''v. Load dataset'''
    # Timer is a context manager, it can calculate the execution time of codes within the context.
    with Timer(logger, job='Load data'):
        # Data container is an object which is responsible for data loading & processing.
        data_container = build_data_container(
            cfg.data,
            default_args=dict(
                train_batch_size=cfg.train.batch_size,
                val_batch_size=cfg.val.batch_size,
                seed=cfg.seed,
                rank=cfg.local_rank,
                world_size=get_world_size(),
                device_id=torch.cuda.current_device(),
                debug=cfg.debug,
                logger=logger
            )
        )

    '''vii. Pre-process dataset then feed in dataloaders'''
    with Timer(logger, job='Build dataloaders'):
        dataloaders = data_container.get_dataloaders()
        train_dataloader, val_dataloader, test_dataloader = dataloaders['train'], \
            dataloaders['validation'], dataloaders['test']

    '''vi. Build model'''
    model, model_ckpt_cfg, teacher, teacher_ckpt_cfg = _build_model(cfg, logger)

    '''viii. Build optimizer & lr_scheduler'''
    # Linear scale the learning rate according to total batch size.
    if cfg.train.linear_scaled_lr:
        _linear_scale_lr(cfg)

    optimizer = build_optimizer(model, cfg)
    logger.info(f"=> Build optimizer:\n{str(optimizer)}\n")
    # Note: 'num_train_steps' considers gradient accumulation, this is the counts of lr changes.
    lr_scheduler, num_update_steps = build_lr_scheduler(optimizer, cfg, len(train_dataloader))

    # '''ix. Auto resume'''
    # if cfg.train.auto_resume:
    #     if cfg.resume_path is not None:
    #         logger.info(f"Note: Auto resuming from '{cfg.resume_path}'..")
    #         unwrapped_model = model.module if distributed else model
    #         # Returns a dict: metric type -> metric value
    #         metrics = load_checkpoint(
    #             unwrapped_model, optimizer, 
    #             lr_scheduler, cfg, logger
    #         )
    #         # Re-compute the number of update steps due to our start epoch changes.
    #         num_update_steps = (cfg.trainer.epochs - cfg.trainer.start_epoch) * \
    #             math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps)
    #         logger.info(
    #             f"\n[Resume Info]\n"
    #             f"-Start Epoch: {cfg.trainer.start_epoch}\n"
    #             f"-Learning rate: {optimizer.param_groups[0]['lr']}\n"
    #             f"-Metrics: {metrics}\n"
    #             f"=> Resume done!\n"
    #         )
    #     else:
    #         logger.warning(f"Note: NO CHECKPOINT FOUND in '{cfg.output}', SKIP auto resume\n")

    '''ix. Auto Resume(if needed)'''
    resume, pruner_ckpt_path = _do_resume(cfg, model, optimizer, lr_scheduler, logger)
    if resume:
        # If resumed from previous state, we shourld re-compute the update steps.
        num_update_steps = (cfg.trainer.epochs - cfg.trainer.start_epoch) * \
            math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps)
    
    '''x. Wrapped Model'''
    model_unwrapped = model
    if distributed:
        # model = _distributed_wrap_model(model, device_ids=[torch.cuda.current_device()])
        model_unwrapped = model.module

    '''xi. Pruner'''
    # If we set sparse step to 0(or didn't set) when pruning, it will use 'num_update_steps' instead.
    # if cfg.train.prune and not cfg.pruner.sparse_step:
    #     cfg.defrost()
    #     cfg.pruner.sparse_step = num_update_steps
    #     cfg.freeze()
    # pruner = build_pruner(
    #     cfg.pruner,
    #     default_args=dict(
    #         prune=cfg.train.prune,
    #         model=model,
    #         model_name=cfg.model.name,
    #         optimizer=optimizer,
    #         num_steps = cfg.trainer.epochs * len(train_dataloader),
    #         steps_per_epoch=len(train_dataloader),
    #         logger=logger,
    #         log_path=logger.log_dir,
    #         rank=cfg.local_rank
    #     )
    # )

    num_update_steps_total = cfg.trainer.epochs * \
        (math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps))
    pruner = build_pruner(
        cfg.pruner,
        default_args=dict(
            prune=cfg.train.prune,
            model=model_unwrapped,
            model_name=cfg.model.name,
            optimizer=optimizer,
            num_steps=num_update_steps_total,
            steps_per_epoch=len(train_dataloader),
            checkpoint=pruner_ckpt_path,
            logger=logger,
            log_path=logger.log_dir,
            rank=cfg.local_rank
        )
    )

    if pruner is not None:
        # Make sure that model in pruner is the same object as the global
        # and check their parameters one-by-one
        cmp_models(pruner.model, model_unwrapped)

        # Make sure that pruner's start step equals the global's,
        # especially in resuming case.
        start_step = cfg.trainer.start_epoch * (math.ceil(len(train_dataloader) / cfg.trainer.grad_accumulation_steps))
        if pruner.step != start_step:
            raise RuntimeError(f"pruner start step:{pruner.step} != global start step:{start_step}.")

    # Log config
    logger.info(f"\n[Config]\n{cfg.dump()}\n")

    # Log Training info(this can help u to check whether your setting is correct before training)
    num_train_samples = train_dataloader.data_size 
    num_val_samples = val_dataloader.data_size
    num_test_samples = test_dataloader.data_size if test_dataloader is not None else 0
    num_epochs = cfg.trainer.epochs - cfg.trainer.start_epoch
    num_train_steps = num_epochs * len(train_dataloader)
    total_train_batch_size = cfg.train.batch_size * get_world_size() * cfg.trainer.grad_accumulation_steps
    
    logger.info("***** Start Training *****")
    logger.info(f"  Num epochs = {num_epochs}")
    logger.info(f"  Num train samples(per dev) = {num_train_samples}")
    logger.info(f"  Num val samples(per dev) = {num_val_samples}")
    logger.info(f"  Num test samples(per dev) = {num_test_samples}")
    logger.info(f"  Num train steps(per dev) = {num_train_steps}")
    logger.info(f"  Num update steps(per dev) = {num_update_steps}")
    logger.info(f"  Train batch size(per dev) = {cfg.train.batch_size}")
    logger.info(f"  Num gradient Accumulation steps = {cfg.trainer.grad_accumulation_steps}")
    logger.info(f"  Total train batch size (batch size per device x num devices x gradient accumulation steps) = {total_train_batch_size}\n")

    '''xii. Training'''
    # Trainer is an object which will do all of training jobs, e.g. gets batched data, model forwarding, 
    # computes loss, optimizes parameters, updates lr, saving checkpoints, etc.
    trainer = build_trainer(
        cfg.trainer, 
        default_args=dict(
            rank=cfg.local_rank,
            model=model, optimizer=optimizer, lr_scheduler=lr_scheduler,
            teacher=teacher, logger=logger, output_dir=logger.log_dir
        )
    )
    # Hooks behaviors decide what will trainer do during each stage.
    trainer.register_training_hooks(cfg.hooks)
    # Data container may feed some parameters to trainer
    # if cfg.get('data_container_to_trainer'):
    #     args_key = cfg.data_container_to_trainer
    #     if isinstance(args_key, str):
    #         args_key = [args_key]
    #     assert is_seq_of(args_key, str)

    #     cfg.trainer_fit_args.update({
    #         key: getattr(data_container, key) for key in args_key if hasattr(data_container, key)
    #     })
    # Train, eval & test(optional)
    # trainer.fit(data_container, pruner=pruner, **cfg.trainer_fit_args)
    trainer.run(data_container, pruner=pruner, **cfg.trainer_run_args)

    '''xiii. Dealloc'''
    # Release all references to the internal objects stored and call the garbage collector
    # torch.cuda.empty_cache()
    if distributed:
        # Destroy all processes, and de-initialize the distributed package
        kill_all_process()
