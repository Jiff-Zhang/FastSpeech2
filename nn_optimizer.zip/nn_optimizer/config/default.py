from yacs.config import CfgNode as CN


_C = CN()


def get_default_config():
    return _C.clone()
