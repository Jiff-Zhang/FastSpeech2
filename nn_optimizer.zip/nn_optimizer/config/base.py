import os

from yacs.config import CfgNode as CN

import logging
# Global
_C = CN()
_C.seed = 42
_C.debug = False
_C.output = 'test/output'
_C.local_rank = int(os.environ.get('LOCAL_RANK', 0))
_C.test_sparsity = False  # whether to test model sparsity at the begining

# Logger
_C.logger = CN()
_C.logger.type = 'base'
_C.logger.name = 'BaseLogger'
_C.logger.level = 10  # DEBUG, refer to see logging module.

# Train
_C.train = CN()
_C.train.batch_size = 4

# Eval
_C.val = CN()
_C.val.batch_size = 4

# Test
_C.test = CN()
_C.test.batch_size = 1

# Trainer
_C.trainer = CN()
_C.trainer.save_freq = 1
_C.trainer.log_freq = 10
_C.trainer.do_eval = True
_C.trainer.do_train = True
_C.trainer.do_test = False
_C.trainer.num_steps_for_compute_metrics = 1
_C.trainer.compute_metrics_in_last_step = False

# Quantization config
_C.trainer.quant_cfg = CN()
_C.trainer.quant_cfg.enable = False
_C.trainer.quant_cfg.qr_loss_weight = 0.1

# Deepcopy
cfg = _C.clone()
