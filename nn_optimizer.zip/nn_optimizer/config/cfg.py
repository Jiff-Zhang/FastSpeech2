from typing import List, Tuple
from yacs.config import CfgNode as CN

import os


# Use to inherit parent configs
BASE_KEY = '_base_'
BASE_DIR = os.path.dirname(__file__)
BASE_FILE = os.path.join(BASE_DIR, 'base.py')


def load_config(path_or_raw_str: str):
    """
    Load config from a file or a string that can be parsed as valid YAML.
    Args:
        path_or_raw_str (str):
            Path to config file or a string.
            Currently supports:
            - YAML file
            - Python source file that exports an attribute "cfg" that is either a dict or a CfgNode
            - A string that can be parsed as valid YAML
    """

    if isinstance(path_or_raw_str, str):
        if path_or_raw_str.split('.')[-1] in ('py', 'yml', 'yaml'):
            # Assume path is under the config root directory
            with open(os.path.join(BASE_DIR, path_or_raw_str), 'r', encoding='utf-8') as f:
                cfg = CN.load_cfg(f)
        else:
            cfg = CN.load_cfg(path_or_raw_str)
    else:
        raise TypeError(f"'path_or_str' must be a str, but got: {type(path_or_raw_str)}")
    
    # To allow merging new keys from other configs, recursively apply to sub configs.
    cfg.set_new_allowed(True)
    
    # Inherit from base configs
    if BASE_KEY in cfg:
        base_files = cfg.pop(BASE_KEY)
        if not isinstance(base_files, (List, Tuple)):
            base_files = [base_files]
        
        for base_file in base_files:
            base_cfg = load_config(os.path.join(BASE_DIR, base_file))
            # Make current config override base config
            base_cfg.set_new_allowed(True)
            # Current config will overwrite those in base if their keys are matched
            base_cfg.merge_from_other_cfg(cfg)

            cfg = base_cfg.clone()
    
    return cfg


def get_config_from_args(args):
    """
    Load config from a file that its path is specified by command line arguments.
    If the path is not specified, a base file will be used.
    Furthermore, items specified by command line arguments will be used.
    """

    cfg_file = args.config or BASE_FILE
    cfg = load_config(cfg_file)

    cfg_from_args = vars(args)
    cfg_from_args.pop('config', None)
    # Note: we set the local rank from the os environment
    cfg_from_args.pop('local_rank', 0)

    # Allow to modify
    cfg.defrost()

    # Running epochs
    epochs = cfg_from_args.pop('epochs', 0)
    # > 0
    if epochs:
        cfg.trainer.epochs = epochs
    if not cfg.trainer.do_train:
        # If only do eval or predict, we will run only 1 epoch.
        cfg.trainer.epochs = cfg.trainer.start_epoch + 1

    # Pruning
    prune = cfg_from_args.pop('prune', False)
    if prune:
        cfg.train.prune = prune
    
    # Knowledge Distillation
    kd = cfg_from_args.pop('kd', False)
    if kd:
        cfg.trainer.kd = kd

    # Debug mode
    if cfg_from_args.get('debug'):
        # Default is train_batch_size x num_process x 3(set by DataContainer)
        num_debug_samples = cfg_from_args.pop('num_debug_samples', 0)
        cfg.data.num_debug_samples = num_debug_samples

    # Others
    for k, v in cfg_from_args.items():
        cfg[k] = v
    
    # Fix the config(thus make it not allow to modify)
    cfg.freeze()
    
    return cfg


def convert_to_dict(cfg_node):
    """
    Recursively convert CfgNode instances to Dict type.
    """

    if not isinstance(cfg_node, CN):
        return cfg_node
    else:
        cfg_dict = dict(cfg_node)
        # Recursively convert sub CfgNodes to Dict type.
        for k, v in cfg_dict.items():
            cfg_dict[k] = convert_to_dict(v)

        return cfg_dict
