from yacs.config import CfgNode as CN


_C = CN()

_C.type = 'text_classification'
_C.pretrained_path = 'microsoft/deberta-base-mnli'
_C.name = 'deberta-base-mnli'
_C.cls_dropout = 0.2
_C.num_labels = 2

# Note: deepcopy object in case of alter the original
cfg = _C.clone()
