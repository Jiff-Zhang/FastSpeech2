import torch.nn.functional as F


def ce_loss(model_outputs, batched_data, **loss_args):
    targets = batched_data[1].to(model_outputs.device)
    return F.cross_entropy(model_outputs, targets, **loss_args)


def soft_ce_loss(predicts, targets, temperature=1., reduction='mean', **kwargs):
    likelihood = F.log_softmax(predicts / temperature, dim=-1)
    soft_targets = F.softmax(targets / temperature, dim=-1)
    
    loss = soft_targets * -likelihood
    if reduction == 'mean':
        return loss.mean()
    elif reduction == 'sum':
        return loss.sum()
    elif reduction == 'none':
        return loss
    else:
        raise NotImplementedError(f"'reduction':{reduction} not implemented")
