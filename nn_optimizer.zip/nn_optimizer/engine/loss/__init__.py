import torch.nn.functional as F

from .hf_api import hf_api_loss
from .ce_loss import ce_loss, soft_ce_loss
from .dkd_loss import dkd_loss


loss_dict = {
    'ce': ce_loss,
    'soft_ce': soft_ce_loss,
    'dkd': dkd_loss,
    'mse': F.mse_loss,
    'hf_api': hf_api_loss
}

__all__ = ('loss_dict',)
