def hf_api_loss(*args, **kwargs):
    outputs, _ = args
    return outputs.loss
