import torch
import torch.nn as nn
import torch.nn.functional as F

from typing import List


scale_dict = {}

mark_key = ""
mark_value = 0.0
all_M1 = {}


def quant_reg_loss(
    x: torch.FloatTensor, 
    module: nn.Module, 
    add_term: torch.FloatTensor = None,
    output_y: bool = False):

    A_max = get_input_scale(x)
    A_max.detach()
    A_max.log2_()

    W_max = get_weight_scale(module.weight)
    W_max[W_max == 0] = 1
    W_max.log2_()

    y = module(x) # 
    if add_term is not None:
        C = y + add_term
    else:
        C = y 

    C_max = get_input_scale(C)
    C_max.log2_() 

    m1_loss = C_max - A_max - W_max - 8 
    m1_loss[m1_loss < 0] = 0
    m1_loss.square_()
    m1_loss = m1_loss.mean() 

    if output_y:
        return m1_loss, y
    else:
        return m1_loss


def quant_reg_loss_for_matmal(
    x1: torch.FloatTensor, 
    x2: torch.FloatTensor, 
):

    A_max = get_input_scale(x1)
    A_max.detach()
    A_max.log2_()

    W_max = x2.abs().max(-2)[0]/127
    W_max[W_max == 0] = 1
    W_max.log2_()

    C = torch.matmul(x1, x2)
    C_max = get_input_scale(C)
    C_max.log2_() 

    m1_loss = C_max - A_max - W_max - 8 
    m1_loss[m1_loss < 0] = 0
    m1_loss.square_()
    m1_loss = m1_loss.mean() 

    return m1_loss


def qr_loss_log(quant_reg_losses: List[torch.Tensor]):
    log = ""
    for loss in quant_reg_losses:
        log += f", {'{:.2f}'.format(loss.item())}"
    log += f", total_loss: {sum(quant_reg_losses)}"
    return log


def true_softmax(quant_reg_losses: List[torch.Tensor], prevent_overflow=False):
    if prevent_overflow:
        max_quant_reg_losses = max(quant_reg_losses).item()
    else:
        max_quant_reg_losses = 0 
    for loss in quant_reg_losses:
        loss.sub_(max_quant_reg_losses)
        loss.exp_()
    quant_reg_loss = sum(quant_reg_losses) 
    quant_reg_loss.log_()
    return quant_reg_loss


def get_weight_scale(weight, num_bits=8):
    if len(weight.shape) == 2:
        max_value = weight.abs().max(-1)[0]
    else:
        print("Error: Invalid input shape {}".format(weight.shape))
        raise
    scale = max_value/(2**(num_bits-1)-1)
    # print("max weight:", max_value.detach().cpu().numpy().tolist())
    return scale


def get_input_scale(input_tensor, key=None, num_bits=8):
    if key:
        global scale_dict
        if key in scale_dict:
            scale = scale_dict[key]
        else:
            scale = input_tensor.abs().max()/(2**(num_bits-1)-1)
            scale_dict[key] = scale 
            print(key, scale, input_tensor.max().item())
    else:
        scale = input_tensor.abs().max()/(2**(num_bits-1)-1) 
    return scale


def quant_data(x, scale):
    int32_x = (x / scale).clip(-128, 127).round().int()
    return int32_x


def dequant_data(x, scale):
    return x.float() * scale


def quant_dequant_output(
    x: torch.FloatTensor, 
    y: torch.FloatTensor, 
    module: nn.Module = None, 
    weight: torch.FloatTensor = None,
    bias: torch.FloatTensor = None,
    add_term: torch.FloatTensor = None):

    # global mark_key, mark_value
    # if not mark_key:
    #     mark_key = id(module)
    #     mark_value = module.weight.sum().item() 
    
    # if id(module) == mark_key: 
    #     if module.weight.sum().item() != mark_value:
    #         global scale_dict
    #         scale_dict = {} 
    #         mark_value = module.weight.sum().item() 

    if not weight and module:
        weight = module.weight

    if not bias and module:
        bias = module.bias

    scales_x = get_input_scale(x, key=f"{id(module)}_x").to(x.device)
    # scales_x = get_input_scale(x)
    scales_weight = get_weight_scale(weight).to(weight.device)
    int32_x = quant_data(x, scales_x)

    if bias is not None:
        int32_bias = bias / (scales_x * scales_weight)
    else:
        int32_bias = torch.tensor(0, dtype=torch.float32)

    int32_bias = int32_bias.int()
    int32_weight = quant_data(weight, scales_weight.unsqueeze(-1))

    if add_term is not None:
        scales_add_term = get_input_scale(add_term, key=f"{id(module)}_add").to(add_term.device)
        # scales_add_term = get_input_scale(add_term)
        int32_add_term = quant_data(add_term, scales_add_term)
        M2 = (scales_add_term / scales_x / scales_weight).to(torch.float32)
    else:
        int32_add_term = torch.tensor(0, dtype=torch.int32)
        M2 = torch.tensor(1, dtype=torch.float32).to(x.device)
    
    assert torch.all(M2 >= 1), f"M2 not satisfy the hardware requirement"
    scales_y = get_input_scale(y, key=f"{id(module)}_y").to(y.device)
    # scales_y = get_input_scale(y)

    M1 = (scales_x * scales_weight / scales_y).to(torch.float32)
    assert torch.all(M1 <= 1), "M1 not satisfy the hardware requirement"
    # M1 close to 1

    # global all_M1 
    # if f"module_{id(module)}" not in all_M1: 
    #     M1 = M1.detach()
    #     all_M1[f"module_{id(module)}"] = M1.cpu().numpy().tolist()
    # else:
    #     import json
    #     with open("./M2.json", "w") as f:
    #         json.dump(all_M1, f)
    #     assert False

    quant_y = F.linear(int32_x.float(), int32_weight.float(), int32_bias.float())
    quant_y = M1 * (quant_y + M2 * int32_add_term.float())
    quant_y = torch.clip(quant_y.round(), -128, 127).to(torch.int8)

    dequant_y = dequant_data(quant_y, scales_y)
    # if id(module) == mark_key: 
    #     import pdb
    #     pdb.set_trace()

    return dequant_y


def quant_dequant_output_matmal(
    x1: torch.FloatTensor, 
    x2: torch.FloatTensor, 
    y: torch.FloatTensor,
    module: nn.Module
):
    scales_x1 = get_input_scale(x1, key=f"{id(module)}_x1").to(x1.device)
    scales_x2 = get_input_scale(x2, key=f"{id(module)}_x2").to(x2.device)
    # scales_x1 = get_input_scale(x1)
    # scales_x2 = get_input_scale(x2)

    int32_x1 = quant_data(x1, scales_x1)
    int32_x2 = quant_data(x2, scales_x2)

    scales_y = get_input_scale(y, key=f"{id(module)}_y").to(y.device)
    # scales_y = get_input_scale(y) 
    
    M1 = (scales_x1 * scales_x2 / scales_y).to(torch.float32)
    quant_y = M1 * torch.matmul(int32_x1.float(), int32_x2.float())
    quant_y = torch.clip(quant_y.round(), -128, 127).to(torch.int8)
    dequant_y = dequant_data(quant_y, scales_y)

    return dequant_y
