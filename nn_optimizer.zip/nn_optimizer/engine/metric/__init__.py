from .accuracy import accuracy

metric_func_dict = {
    'accuracy': accuracy
}

__all__ = ('metric_func_dict')
