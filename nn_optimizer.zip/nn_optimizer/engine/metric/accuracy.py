import torch

def accuracy(output, target, topk=(1,)):
    """
    Computes the accuracy over the k top predictions for the specified values of k(default is 1).
    """

    metric_dict = {f'top{k}-accuracy': 0. for k in topk}

    with torch.no_grad():
        max_k = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(max_k, dim=1, largest=True, sorted=True)
        # Note: when we use mixup, the target's shape is the same as model output's
        if target.shape == output.shape:
            target = target.max(dim=-1).indices
        # (b, max_k)
        correct = pred.eq(target.unsqueeze(-1).expand_as(pred))

        for k in topk:
            # (1,)
            correct_k = correct[:, :k].reshape(-1).float().sum(0, keepdim=True)
            topk_metric = correct_k.div_(batch_size).item()
            metric_dict[f'top{k}-accuracy'] = topk_metric

    return metric_dict
