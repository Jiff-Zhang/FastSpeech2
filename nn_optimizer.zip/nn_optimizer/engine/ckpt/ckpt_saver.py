import os
import glob
import shutil

import torch

from torch.nn.parallel import DataParallel as DP
from torch.nn.parallel import DistributedDataParallel as DDP

from deepspeed import DeepSpeedEngine

from utils.dist import is_master
from utils.registry import Registry


CKPT_SAVER = Registry('ckpt_saver')


class CkptSaver:
    """
    Base class for saving checkpoints.
    """
    
    @staticmethod
    def unwrap_model(model):
        """
        Extract a model from its distributed containers.

        Args:
            model (:obj:`torch.nn.Module`): The model to extract.

        Returns:
            :obj:`torch.nn.Module`: The extracted model.
        """

        DIST_CONTAINERS = (DP, DDP, DeepSpeedEngine,)

        while isinstance(model, DIST_CONTAINERS):
            model = model.module

        return model


@CKPT_SAVER.register_module(name='torch')
class TorchCkptSaver(CkptSaver):
    """
    Saving Pytorch checkpoints.
    """
    
    def __init__(self, ext: str = 'pth'):
        self.ext = ext

    def save_latest(self, trainer):
        """
        Save the latest state dict.
        """

        # Only main process need to save checkpoint
        if not is_master():
            return

        # Loss(latest)
        train_loss = trainer.meta['train_epoch_loss'][-1]
        eval_loss = trainer.meta['eval_epoch_loss'][-1]

        # Metrics(latest)
        train_metric_dict = trainer.meta['train_epoch_metric'][-1]
        eval_metric_dict = trainer.meta['eval_epoch_metric'][-1]

        # Output path
        output_file = f'latest-epoch{trainer.epoch}.{self.ext}'
        output_path = os.path.join(trainer.output_dir, output_file)

        # Build state dict
        state_dict = {
            'epoch': trainer.epoch,
            'model': trainer.model_unwrapped.state_dict(),
            'optimizer': self.unwrap_model(trainer.optimizer).state_dict(),
            'lr_scheduler': self.unwrap_model(trainer.lr_scheduler).state_dict(),
            'loss': {'train': train_loss, 'eval': eval_loss},
            'metric': {'train': train_metric_dict, 'eval': eval_metric_dict}
        }
        # Compatible with NLP models
        if hasattr(trainer.model_unwrapped, 'config'):
            model_config_cls = trainer.model_unwrapped.config.__class__
            model_config_dict = trainer.model_unwrapped.config.to_dict()            
            state_dict.update(model_config_dict=model_config_dict, model_config_cls=model_config_cls)

        # Delete previous
        for prev in glob.glob(os.path.join(trainer.output_dir, f'latest-epoch*.{self.ext}')):
            os.remove(prev)

        torch.save(state_dict, output_path)
        trainer.logger.info(f"\nlatest checkpoint has been saved to: {output_path}\n")

    def save(self, trainer):
        """
        Save state dict.
        """

        # Only main process need to save checkpoint
        if not is_master():
            return

        # Loss(latest)
        train_loss = trainer.meta['train_epoch_loss'][-1]
        eval_loss = trainer.meta['eval_epoch_loss'][-1]

        # Metrics(latest)
        train_metric_dict = trainer.meta['train_epoch_metric'][-1]
        eval_metric_dict = trainer.meta['eval_epoch_metric'][-1]

        # Metric tag
        avg_tag = f'-avg{(sum(eval_metric_dict[metric_name] for metric_name in trainer.metric_identifier) / len(trainer.metric_identifier)):.3f}-' \
                if len(eval_metric_dict) > 1 else '-'
        metric_tag = '-'.join(
            [f"{metric_name}{eval_metric_dict[metric_name]:.3f}" 
            for metric_name in trainer.metric_identifier]
        )

        # Lr tag
        lr_tag = f'-lr{trainer.optimizer.param_groups[0].get("initial_lr", trainer.optimizer.param_groups[0]["lr"])}'

        # Batch size tag
        # Note: this will be eval batch size
        bs = trainer.batch_size
        bs_tag = f'-bs{bs}' if bs else ''

        # Current epoch tag
        ep_tag = f'ep{trainer.epoch + 1}'

        # Indicate now it is eval or test or others..
        mode_tag = f'{trainer.mode}-' if getattr(trainer, 'mode', '') else ''

        # Output path
        output_file = f'{mode_tag}{ep_tag}{bs_tag}{lr_tag}{avg_tag}{metric_tag}.pth'
        # output_path = os.path.join(trainer.output_dir, output_file)

        # Build state dict
        state_dict = {
            'epoch': trainer.epoch,
            'model': trainer.model_unwrapped.state_dict(),
            'optimizer': self.unwrap_model(trainer.optimizer).state_dict(),
            'lr_scheduler': self.unwrap_model(trainer.lr_scheduler).state_dict(),
            'loss': {'train': train_loss, 'eval': eval_loss},
            'metric': {'train': train_metric_dict, 'eval': eval_metric_dict}
        }
        # Compatible with NLP models
        if hasattr(trainer.model_unwrapped, 'config'):
            model_config_cls = trainer.model_unwrapped.config.__class__
            model_config_dict = trainer.model_unwrapped.config.to_dict()
            if getattr(trainer.model_unwrapped.config, 'num_labels', None) is not None:
                model_config_dict.update(num_labels=trainer.model_unwrapped.config.num_labels)
            
            state_dict.update(model_config_dict=model_config_dict, model_config_cls=model_config_cls)

        # TODO: do not delete history when getting best ckpt.
        # Delete previous if acheive better performance
        if getattr(trainer, 'get_best', False):
            output_file = 'best-' + output_file
            for prev in glob.glob(os.path.join(trainer.output_dir, f'best-*.{self.ext}')):
                os.remove(prev)
            for prev in glob.glob(os.path.join(trainer.output_dir, f'normal-*.{self.ext}')):
                os.remove(prev)
        if getattr(trainer, 'get_pruning_best', False):
            sparsity = trainer.pruner.sparsities[trainer.pruner.index]
            output_file = f'sparsity_{sparsity}_best-' + output_file
            for prev in glob.glob(os.path.join(trainer.output_dir, f'sparsity_{sparsity}_best-*.{self.ext}')):
                os.remove(prev)
        if not (getattr(trainer, 'get_best', False) or getattr(trainer, 'get_pruning_best', False)):
            output_file = 'normal-' + output_file

        output_path = os.path.join(trainer.output_dir, output_file)
        torch.save(state_dict, output_path)

        if getattr(trainer, 'get_best', False):
            ckpt_type = 'best '
        elif getattr(trainer, 'get_pruning_best', False):
            ckpt_type = f'best sparse({sparsity}) '
        else:
            ckpt_type = ''
        trainer.logger.info(f"\n{ckpt_type}checkpoint of epoch{trainer.epoch} has been saved({output_path}).\n")


@CKPT_SAVER.register_module(name='deepspeed')
class DeepspeedCkptSaver(CkptSaver):
    """
    Saving DeepSpeed checkpoints.
    Note: all processes should save their checkpoints, it is because 
          each process needs to save its master weights and scheduler + optimizer states.
    """
    
    def save_latest(self, trainer):
        # Loss(latest)
        train_loss = trainer.meta['train_epoch_loss'][-1]
        eval_loss = trainer.meta['eval_epoch_loss'][-1]

        # Metrics(latest)
        train_metric_dict = trainer.meta['train_epoch_metric'][-1]
        eval_metric_dict = trainer.meta['eval_epoch_metric'][-1]

        tag = f'ds-latest-epoch{trainer.epoch}'

        # Build state dict
        # Note: state dicts of model & optimizer will be saved by DeepSpeed
        state_dict = {
            'epoch': trainer.epoch,
            'lr_scheduler': self.unwrap_model(trainer.lr_scheduler).state_dict(),
            'loss': {'train': train_loss, 'eval': eval_loss},
            'metric': {'train': train_metric_dict, 'eval': eval_metric_dict}
        }
        # Compatible with NLP models
        if hasattr(trainer.model_unwrapped, 'config'):
            model_config_cls = trainer.model_unwrapped.config.__class__
            model_config_dict = trainer.model_unwrapped.config.to_dict()            
            state_dict.update(model_config_dict=model_config_dict, model_config_cls=model_config_cls)
        
        # Delete previous
        for prev in glob.glob(os.path.join(trainer.output_dir, f'latest-epoch*')):
            if os.path.isdir(prev):
                shutil.rmtree(prev, ignore_errors=True)
            elif os.path.isfile(prev):
                os.remove(prev)
            # Leave for future
            else:
                pass

        # Invoke DeepSpeedEngine().save_checkpoint()
        trainer.deepspeed.save_checkpoint(trainer.output_dir, tag=tag, client_state=state_dict)
        trainer.logger.info(f"\nlatest checkpoint has been saved to: {os.path.join(trainer.output_dir, tag)}\n")

    def save(self, trainer):
        # Loss(latest)
        train_loss = trainer.meta['train_epoch_loss'][-1]
        eval_loss = trainer.meta['eval_epoch_loss'][-1]

        # Metrics(latest)
        train_metric_dict = trainer.meta['train_epoch_metric'][-1]
        eval_metric_dict = trainer.meta['eval_epoch_metric'][-1]

        # Metric tag
        avg_tag = f'-avg{(sum(eval_metric_dict[metric_name] for metric_name in trainer.metric_identifier) / len(trainer.metric_identifier)):.3f}-' \
                if len(eval_metric_dict) > 1 else '-'
        metric_tag = '-'.join( 
            [f"{metric_name}{eval_metric_dict[metric_name]:.3f}" 
            for metric_name in trainer.metric_identifier]
        )

        # Lr tag
        lr_tag = f'-lr{trainer.optimizer.param_groups[0].get("initial_lr", trainer.optimizer.param_groups[0]["lr"])}'

        # Batch size tag
        # Note: this will be eval batch size
        bs = trainer.batch_size
        bs_tag = f'-bs{bs}' if bs else ''

        # Current epoch tag
        ep_tag = f'ep{trainer.epoch + 1}'

        # Indicate now it is eval or test or others..
        mode_tag = f'{trainer.mode}-' if getattr(trainer, 'mode', '') else ''

        # Checkpoint identifier
        tag = f'ds-{mode_tag}{ep_tag}{bs_tag}{lr_tag}{avg_tag}{metric_tag}'

        # Build state dict
        # Note: state dicts of model & optimizer will be saved by DeepSpeed
        state_dict = {
            'epoch': trainer.epoch,
            'lr_scheduler': self.unwrap_model(trainer.lr_scheduler).state_dict(),
            'loss': {'train': train_loss, 'eval': eval_loss},
            'metric': {'train': train_metric_dict, 'eval': eval_metric_dict}
        }
        # Compatible with NLP models
        if hasattr(trainer.model_unwrapped, 'config'):
            model_config_cls = trainer.model_unwrapped.config.__class__
            model_config_dict = trainer.model_unwrapped.config.to_dict()
            if getattr(trainer.model_unwrapped.config, 'num_labels', None) is not None:
                model_config_dict.update(num_labels=trainer.model_unwrapped.config.num_labels)
            
            state_dict.update(model_config_dict=model_config_dict, model_config_cls=model_config_cls)
        
        # Delete previous if acheive better performance
        if getattr(trainer, 'get_best', False):
            tag = 'best-' + tag
            for prev in glob.glob(os.path.join(trainer.output_dir, f'best-ds-*')):
                if os.path.isdir(prev):
                    shutil.rmtree(prev, ignore_errors=True)
                elif os.path.isfile(prev):
                    os.remove(prev)
                # Leave for future
                else:
                    pass
            for prev in glob.glob(os.path.join(trainer.output_dir, f'normal-ds-*')):
                if os.path.isdir(prev):
                    shutil.rmtree(prev, ignore_errors=True)
                elif os.path.isfile(prev):
                    os.remove(prev)
                # Leave for future
                else:
                    pass
        if getattr(trainer, 'get_pruning_best', False):
            sparsity = trainer.pruner.sparsities[trainer.pruner.index]
            tag = f'sparsity_{sparsity}_best-' + tag
            for prev in glob.glob(os.path.join(trainer.output_dir, f'sparsity_{sparsity}_best-ds-*')):
                if os.path.isdir(prev):
                    shutil.rmtree(prev, ignore_errors=True)
                elif os.path.isfile(prev):
                    os.remove(prev)
                # Leave for future
                else:
                    pass
        if not (getattr(trainer, 'get_best', False) or getattr(trainer, 'get_pruning_best', False)):
            tag = 'normal-' + tag

        # Invoke DeepSpeedEngine().save_checkpoint()
        trainer.deepspeed.save_checkpoint(trainer.output_dir, tag=tag, client_state=state_dict)

        if trainer.get_best:
            ckpt_type = 'best '
        elif getattr(trainer, 'get_pruning_best', False):
            ckpt_type = 'best pruning '
        else:
            ckpt_type = ''
        trainer.logger.info(f"\n{ckpt_type}checkpoint of epoch{trainer.epoch} has been saved to: ({trainer.output_dir}).\n")
