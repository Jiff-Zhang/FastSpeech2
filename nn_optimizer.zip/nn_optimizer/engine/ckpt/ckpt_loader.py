import torch

from typing import List
from logging import Logger

from torch.nn import Module
from torch.optim import Optimizer
from torch.optim.lr_scheduler import _LRScheduler

from torch.nn.parallel import DataParallel as DP
from torch.nn.parallel import DistributedDataParallel as DDP

from deepspeed import DeepSpeedEngine, InferenceEngine
from deepspeed.utils.zero_to_fp32 import get_fp32_state_dict_from_zero_checkpoint

import os

ROOT = os.path.join(os.path.dirname(__file__), '../..')

from utils.dist import get_rank
from utils.registry import Registry


MODEL_WRAPPERS = (DP, DDP, DeepSpeedEngine, InferenceEngine,)


def _unwrap_model(model):
    while isinstance(model, MODEL_WRAPPERS):
        model = model.module
    return model


CKPT_LOADER = Registry('checkpoint_loader')


@CKPT_LOADER.register_module(name='torch')
class TorchCheckpointLoader:
    """Pytorch styled checkpoint loader, usually useful with 'torch.load()' & 'model.load_state_dict()'."""

    def __init__(
        self, path: str,
        model: Module = None,
        load_optimizer_states: bool = False, load_lr_scheduler_states: bool = False,
        optimizer_key: str = 'optimizer', lr_scheduler_key: str = 'lr_scheduler',
        return_state_dict: bool = False, strict: bool = True, ignore_keys: List[str] = None
    ):
        if not (path.startswith('https') or os.path.exists(path)):
            path = os.path.join(ROOT, path)
            assert os.path.exists(path), f"Checkpoint path:{path} not existed."

        self.path = path
        self.model = model

        # Whether to load optimizer & lr scheduler states
        self.load_optimizer_states = load_optimizer_states
        self.load_lr_scheduler_states = load_lr_scheduler_states

        # Optimizer & lr scheduler state keys in state dict
        self.optimizer_key = optimizer_key
        self.lr_scheduler_key = lr_scheduler_key

        self.strict = strict
        # Weights indicated by these keys will not be loaded into model
        self.ignore_keys = ignore_keys

        # Whether to return state dict when checkpoint loading is finished
        self.return_state_dict = return_state_dict
    
    def load(self, optimizer: Optimizer = None, lr_scheduler: _LRScheduler = None):
        if self.path.startswith('https'):
            state_dict = torch.hub.load_state_dict_from_url(self.path, map_location='cpu', check_hash=True)
        else:
            state_dict = torch.load(self.path, map_location='cpu')

        model_state_dict = state_dict.get('model')
        if model_state_dict is None:
            model_state_dict = state_dict
        if self.ignore_keys:
            model_state_dict = {k: v for k, v in model_state_dict.items() if k not in self.ignore_keys}
        _unwrap_model(self.model).load_state_dict(model_state_dict, strict=self.strict)

        if optimizer is not None and self.load_optimizer_states:
            _unwrap_model(optimizer).load_state_dict(state_dict[self.optimizer_key])
        if lr_scheduler is not None and self.load_lr_scheduler_states:
            _unwrap_model(lr_scheduler).load_state_dict(state_dict[self.lr_scheduler_key])
        
        if self.return_state_dict:
            return state_dict
        else:
            del state_dict

    def resume(self, optimizer: Optimizer = None, lr_scheduler: _LRScheduler = None):
        self.return_state_dict = True
        state_dict = self.load(optimizer=optimizer, lr_scheduler=lr_scheduler)

        resumed_states = {
            'epoch': state_dict.get('epoch'),
            'metric': state_dict.get('metric'),
            'lr': state_dict.get('lr')
        }
        resumed_states.update(lr=_unwrap_model(optimizer).param_groups[0]['lr'])
        
        return resumed_states


@CKPT_LOADER.register_module(name='deepspeed')
class DeepSpeedCheckpointLoader:
    """DeepSpeed styled checkpoint loader."""

    def __init__(
        self, ckpt_dir: str, tag: str = None,
        model: DeepSpeedEngine = None,
        convert_to_fp32_state_dict: bool = False, load_module_only: bool = True,
        load_optimizer_states: bool = False, load_lr_scheduler_states: bool = False,
        optimizer_key: str = 'optimizer', lr_scheduler_key: str = 'lr_scheduler',
        return_client_state_dict: bool = False
    ):
        if not os.path.exists(ckpt_dir):
            ckpt_dir = os.path.join(ROOT, ckpt_dir)
            assert os.path.exists(ckpt_dir), f"Checkpoint path:{ckpt_dir} not existed."
        self.ckpt_dir = ckpt_dir
        self.tag = tag
        
        path = os.path.join(ckpt_dir, tag)
        if not os.path.exists(path):
            raise ValueError(f"Checkpoint tag:{tag} cannot be found in directory:{ckpt_dir}.")
        self.path = path

        self.model = model

        # Whether to load model states only
        self.load_module_only = load_module_only
        # Whether to load optimizer & lr scheduler states with deepspeed interface.
        # Note: if they are set to False, we can still load optimizer & lr scheduler states through
        # the clients states, which is returned by deepspeed interface.
        self.load_optimizer_states = load_optimizer_states
        self.load_lr_scheduler_states = load_lr_scheduler_states

        # Optimizer & lr scheduler state keys in state dict
        self.optimizer_key = optimizer_key
        self.lr_scheduler_key = lr_scheduler_key

        # Whether to return client state dict when checkpoint loading is finished.
        self.return_client_state_dict = return_client_state_dict
        # Whether to convert the deepspeed styled checkoint to a fp32 state dict,
        # which can be load by: 'model.load_state_dict()'.
        self.convert_to_fp32_state_dict = convert_to_fp32_state_dict
    
    def load(self, optimizer: Optimizer = None, lr_scheduler: _LRScheduler = None):
        # Note that once this(convert_to_fp32_state_dict) was run, the model will no longer be usable 
        # in the deepspeed context of the same application. i.e. you will need to re-initialize the deepspeed engine, 
        # since model.load_state_dict(state_dict) will remove all the deepspeed magic from it.
        if self.convert_to_fp32_state_dict:
            state_dict = get_fp32_state_dict_from_zero_checkpoint(self.ckpt_dir, tag=self.tag)

            raw_model = _unwrap_model(self.model)
            device = raw_model.device

            # Note: must place model to cpu before loading fp32 weight
            missing_keys, unexpected_keys = raw_model.to('cpu', non_blocking=True).load_state_dict(state_dict, strict=False)
            if len(missing_keys) and get_rank() == 0:
                print(f"missing keys:\n{missing_keys}\n")
            if len(unexpected_keys) and get_rank == 0:
                print(f"unexpected keys:\n{unexpected_keys}")

            del state_dict
            raw_model.to(device)

            return

        ckpt_path, client_sd = self.model.load_checkpoint(
            self.ckpt_dir, tag=self.tag,
            load_module_only=self.load_module_only,
            load_optimizer_states=self.load_optimizer_states,
            load_lr_scheduler_states=self.load_lr_scheduler_states
        )
        if not ckpt_path:
            raise RuntimeError(f"Failed with loading checkpoint dir:{self.ckpt_dir} tag:{self.tag}.")
        
        if not self.load_module_only:
            if not self.load_optimizer_states and optimizer is not None:
                optimizer_unwrapped = optimizer if isinstance(optimizer, Optimizer) else optimizer.optimizer
                if self.optimizer_key in client_sd:
                    optimizer_unwrapped.load_state_dict(client_sd[self.optimizer_key])

            if not self.load_lr_scheduler_states and lr_scheduler is not None:
                if self.lr_scheduler_key in client_sd:
                    _unwrap_model(lr_scheduler).load_state_dict(client_sd[self.lr_scheduler_key])

        if self.return_client_state_dict:
            return client_sd
        else:
            del client_sd

    def resume(self, optimizer: Optimizer = None, lr_scheduler: _LRScheduler = None):
        self.return_client_state_dict = True
        client_sd = self.load(optimizer=optimizer, lr_scheduler=lr_scheduler)

        resumed_states = {
            'epoch': client_sd.get('epoch'),
            'metric': client_sd.get('metric')
        }

        optimizer_unwrapped = optimizer if isinstance(optimizer, Optimizer) else optimizer.optimizer
        resumed_states.update(lr=optimizer_unwrapped.param_groups[0]['lr'])
        
        return resumed_states


def build_checkpoint_loader(cfg, default_args: dict = None):
    return CKPT_LOADER.build(cfg, default_args=default_args)


def build_resume_loader(cfg, default_args: dict = None):
    return build_checkpoint_loader(cfg, default_args=default_args)


def load_checkpoint(checkpoint_cfg, model, logger: Logger, obj: str = 'model'):
    ckpt_loader = build_checkpoint_loader(checkpoint_cfg, default_args=dict(model=model))
    
    ckpt_loader.load()
    ckpt_path = ckpt_loader.path
    logger.info(f"{obj.title()} checkpoint from '{ckpt_path}' loaded.")

    del ckpt_loader
    return ckpt_path


def is_torch_fp32_ckpt(cfg) -> bool:
    return cfg.type == 'torch' or (cfg.type == 'deepspeed' and cfg.get('convert_to_fp32_state_dict'))


def is_deepspeed_styled_ckpt(cfg) -> bool:
    return cfg.type == 'deepspeed' and not cfg.get('convert_to_fp32_state_dict')
