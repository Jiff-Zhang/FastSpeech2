__all__ = ['PrunerScheduler']

from cProfile import label
import os
import numpy as np
import matplotlib.pyplot as plt
import torch
from torch.optim import Optimizer
import deepspeed

from nn_optimizer.engine.optim.lr_scheduler.scheduler import get_constant_linear_schedule_with_warmup
from nn_optimizer.engine.pruner.bbcs import Prune as PruneBBCS
from nn_optimizer.engine.pruner.misc import generate_prune_dict

from .build import PRUNER
from nn_optimizer.utils.logger import LOGGER




@PRUNER.register_module(name='stage_wise_pruner_bbcs')
class PrunerScheduler:
    TYPE = 'bbcs'
    def __init__(self,
            model,
            model_name: str,
            steps_per_epoch: int,
            num_steps: int,
            bank_size: int,
            sparsities: list,
            log_path: str, 
            rank: int,
            optimizer: Optimizer,
            prune_dict: dict=None, 
            ckpt_sparsities: list=None,
            pruner_resume_dict: dict=None,
            log_freq: int=100,
            is_zero3: bool=False,
            **kwargs):  
        """
        Args:
            model (unwarped_model) : model reference 
            model_name (str) : model type name , this name will be used to generate specifi prune dict
            steps_per_epoch (int): number of steps per epoch
            num_steps (int) : total steps of the training phase
            bank_size (int) : number of weight used for pruning per group
            sparsities (list) : list of sparsities used during pruning
            log_path (str) : the saving path for log file
            rank (int) : gpu rank number
            optimizer (torch.nn.optim.Optimizer) : 
            prune_dict (dict) : prune dict, the key is the layer name, the value is the specific sparisity
            ckpt_sparsities (list) : each sparsities is the target sparisity 
                for model which need to be saved during pruning. When this parameter is setting, the sparisities 
                parameter need to only contain single sparsity value.
            pruner_resume_dict: key in dict [path,load_model_states,load_optimizer_states] 
            log_freq (int) : logging frequency,
            is_zero3 (bool) : use deepspeed ZeRO 3, default: false
        """
        self.model = model
        self.steps_per_epoch = steps_per_epoch
        self.num_steps = num_steps
        self.bank_size = bank_size
        self.sparsities = sparsities
        self.log_path = os.path.join(log_path,'prune')
        self.rank = rank
        self.optimizer = optimizer
        self.pruners = [] 
        self.optim_schedulers = []
        self.stage_wise_steps = []
        self.prune_dicts = []
        self.prune_steps = []
        self.topks = []
        self.step = 0
        self.best_metric = 0
        self.index = -1
        self.kwargs = kwargs
        self.resume_tag = False
        self.finetune = False
        self.log_freq = log_freq
        self.is_zero3 = is_zero3
        # decrease the sparsity with some buffer
        self.ckpt_sparsities = []
        if ckpt_sparsities:
            self.ckpt_sparsities = [x-0.015 for x in ckpt_sparsities]


        os.makedirs(self.log_path,exist_ok=True)
        #split steps into multi stage 
        self.stage_wise_steps = list(get_stage_steps(sparsities=sparsities,
                                                    num_steps=num_steps,
                                                    save_path=os.path.join(self.log_path,'sparsity_step.jpg'),
                                                    type='exp'))

        # build logger
        logger_args = {
            'type': 'base',
            'log_dir':self.log_path,
            'rank': self.rank,
            'name': 'pruner'
        }  
        self.logger = LOGGER.build(logger_args)
        self.logger.info(f"Model Sparsity: {sparsities}")

        # generate pruner parameters / stage wise steps / schedulers
        for i,sparsity in enumerate(sparsities):
            prune_dict = generate_prune_dict(model, model_name, sparsity, kwargs.get('model_config'))
            self.sparsity2topk(prune_dict)
            topk = int((1-sparsity)*bank_size)
            prune_step = int(0.9*(self.stage_wise_steps[i][1]-self.stage_wise_steps[i][0]))
            if self.finetune:
                prune_step = 0
            self.stage_wise_steps[i].insert(1,self.stage_wise_steps[i][0]+prune_step) 
            self.prune_steps.append(prune_step)
            self.prune_dicts.append(prune_dict)
            self.topks.append(topk)
            
            self.logger.info(f"stage wise steps: {self.stage_wise_steps[i]}")
            self.logger.info(f"Prune dict: {prune_dict}")
            self.logger.info(f"topk: {topk}")

            scheduler = get_constant_linear_schedule_with_warmup(optimizer,
                                    prune_step,
                                    self.stage_wise_steps[i][2]-self.stage_wise_steps[i][0])
            #if i==(len(sparsities)-1):
            scheduler.base_lrs = [group['initial_lr'] for group in optimizer.param_groups]
            self.optim_schedulers.append(scheduler)

        # resume from ckpt
        if pruner_resume_dict:
            state_dict = torch.load(pruner_resume_dict['path'])
            self.step = state_dict['step']
            self.index = state_dict['index']
            self.optim_schedulers[self.index].load_state_dict(state_dict['lr_scheduler'])
            if pruner_resume_dict['load_model_states']:
                self.model.load_state_dict(state_dict['model'])
            if pruner_resume_dict['load_optimizer_states']:
                self.optimizer.load_state_dict(state_dict['optimizer'])

            self.resume_tag = True
            self.init_pruner()
            self.logger.info(f"resume from {pruner_resume_dict['path']}")
            self.logger.info(f"initial step {self.step}")
            self.logger.info(f"initial model sparsity {self.init_sparsity(self.prune_dicts[self.index])[1]}")
        else:
            self.init_pruner()

    
    def sparsity2topk(self,prune_dict):
        for key,item in prune_dict.items():
            topk = int((1-item)*self.bank_size) 
            prune_dict[key] = topk


    def init_pruner(self):
       if (self.index+1 < len(self.stage_wise_steps) and self.step == self.stage_wise_steps[self.index+1][0]) or self.resume_tag:
            self.best_metric = 0.
            if not self.resume_tag:
                self.index += 1
            # check which phase is the resume ckpt in,prune phase or finetune phase 
            if self.resume_tag:
                resume_pruner_step = self.prune_steps[self.index] if self.step>=self.stage_wise_steps[self.index][1] \
                        else self.step-self.stage_wise_steps[self.index][0]
                self.logger.info(f"index: {self.index} | prune_steps:{self.prune_steps[self.index]} | step {self.step} | stage_wise_steps 1: \
                        {self.stage_wise_steps[self.index][1]} | stage_wise_steps 0: {self.stage_wise_steps[self.index][0]}")
                self.logger.info(f"resume_pruner_step: {resume_pruner_step} | sparse step: {self.prune_steps[self.index]}")
            self.pruner = PruneBBCS(
                model=self.model,
                bank_size=self.bank_size,
                topk = self.topks[self.index],
                pvalue_initial=self.kwargs.get('pvalue_initial',1),
                pvalue_final=self.kwargs.get('pvalue_final',20),
                pvalue_update_freq=self.kwargs.get('pvalue_update_freq',5),
                budget_initial=self.kwargs.get('budget_initial',1),
                budget_final=self.kwargs.get('budget_final',1),
                budget_update_freq=self.kwargs.get('budget_update_freq',self.steps_per_epoch),
                num_steps=self.prune_steps[self.index],
                pvalue_warmup_steps=self.kwargs.get('pvalue_warmup_epochs',1)*self.steps_per_epoch,
                bankwise_budget_update_steps=50*self.steps_per_epoch,
                budget_multiplier=self.kwargs.get('budget_multiplier',1),
                warmup_budget_update_freq=self.steps_per_epoch,
                mask_update_freq=self.kwargs.get('mask_update_freq',5),
                log_path=self.log_path,
                log_freq=self.log_freq,
                rank=self.rank,
                prune_dict=self.prune_dicts[self.index]
            )
            self.logger.info(f"Done of initial pruner. Model sparsity is {self.pruner.sparsity()[1]}")
            

            if self.resume_tag:
                self.resume_tag=False

        
    def prune(self):
        self.optim_schedulers[self.index].step()
        if self.step<self.stage_wise_steps[self.index][1]:
            self.pvalue = self.pruner.prune()
        if self.step==self.stage_wise_steps[self.index][1]:
            self.logger.info("Start finetune !")
            self.pruner.finetune(adaptive_mask=True)
            self.finetune=True

        if self.step == self.stage_wise_steps[self.index][2] - 1:
            self.logger.info(f"Finished pruning model with sparsity {self.sparsities[self.index]}")

        #if self.rank in [-1,0]:
        if self.step%self.log_freq==0: 
            self.logger.info(f"model sparsity{self.sparsity()[1]}")
            self.logger.info(f"step:{self.step},pvalue:{self.pvalue}")
        if self.step>0 and (self.step+1)%self.kwargs.get('frequency',100)==0:
            curr_sparsity = self.pruner.sparsity()[1]
            
            if self.ckpt_sparsities and curr_sparsity>=self.ckpt_sparsities[0]:
                ckpt_path = os.path.join(
                    self.log_path,
                    'sparsity{:.4f}.pth'.format(curr_sparsity)
                )
                torch.save(self.model.state_dict(),ckpt_path)
                self.ckpt_sparsities.pop(0)

                self.logger.info(f"Get model with sparsity{curr_sparsity}")

        self.step += 1
        self.init_pruner() 


    def sparsity(self):
        self.sparse_model(adaptive_mask=True)
        total_param = 0
        total_zero = 0
        layer_sparse_rate = {}
        total_sparse_rate = -1
        with torch.no_grad():
            for name,parameter in self.model.named_parameters():
                if self.prune_dicts[self.index].get(name):
                    num_param = torch.numel(parameter) 
                    zero_param = num_param-torch.nonzero(parameter).shape[0]
                    layer_sparse_rate[name] = zero_param/num_param
                    total_param += num_param
                    total_zero += zero_param
            total_sparse_rate = total_zero / total_param
        self.recover()
        return  layer_sparse_rate,total_sparse_rate

    
    def sparse_model(self,adaptive_mask=True):
        self.pruner.sparse_model(adaptive_mask)
    

    def recover(self):
        self.pruner.recover()
    

    def init_sparsity(self,prune_dict):
        total_param = 0
        total_nonezero = 0
        layer_sparse_rate = {}
        for name, parameter in self.model.named_parameters():
            if any(name == one for one in prune_dict):
                temp = parameter.data.cpu().numpy()
                total_param = total_param + temp.size
                total_nonezero = total_nonezero + np.flatnonzero(temp).size
                layer_sparse_rate[name] = 1 - np.flatnonzero(temp).size / temp.size
        total_sparse_rate = 1 - total_nonezero / total_param
        return layer_sparse_rate, total_sparse_rate


    def update_metrics(self, metric):
        if self.rank in [-1,0]:
            if metric > self.best_metric and self.step >= self.stage_wise_steps[self.index][1]:
                self.best_metric = metric
                ckpt_path = os.path.join(
                    self.log_path,
                    f'sparsity{str(self.sparsities[self.index])}_best.pth'
                )
                self.pruner.sparse_model(adaptive_mask=False)
                torch.save(self.model.state_dict(), ckpt_path)
                self.pruner.recover()
                self.logger.info(f"Found the best model! Metric is {metric}, checkpoint saved..")


    def save(self,**kwargs):
        if self.rank in [-1,0] and self.step%self.steps_per_epoch==0:
            # save latest ckpt
            state_dict = {
                "step": self.step,
                "index": self.index,
                "lr_scheduler": self.optim_schedulers[self.index].state_dict(),
                
            }
            if not self.is_zero3:
                state_dict.update({
                    "model":self.model.state_dict(),
                    "optimizer": self.optimizer.state_dict()
                })
            # WARNING !!!: the key in the kwargs should not contain the key of the state dict
            state_dict.update(kwargs)

            ps_ckpt_path = os.path.join(self.log_path,'pruner_scheduler.pth')
            torch.save(state_dict,ps_ckpt_path)
            self.logger.info(f"Saved pruner ckpt with step={self.step},index={self.index}")



def even_split(a, n):
    k, m = divmod(a, n)
    return ([i*k+min(i, m),(i+1)*k+min(i+1, m)] for i in range(n))


def get_stage_steps(sparsities: list,num_steps: int,save_path:str,type: str='linear'):
    reverted_sparsities = [1/(1-x) for x in sparsities]
    if type=='linear':
        ratio = [x/sum(reverted_sparsities) for x in reverted_sparsities]
    elif type=='exp':
        scale = 0.3
        bias = 0.5
        ratio  = [2**(scale*x+bias) for x in reverted_sparsities]
        ratio = [x/sum(ratio) for x in ratio]
    else:
        raise NotImplementedError("only support linear and exp stategy")

    #save sparsity-num_step plot 
    step_per_sparsity = [int(x*num_steps+0.5) for x in ratio]
    plt.plot(reverted_sparsities,step_per_sparsity,label=type)
    plt.legend(loc='upper left')
    plt.savefig(save_path)

    stage_wise_step = []
    start_step,end_step = 0,0
    for i,r in enumerate(ratio):
       end_step = start_step+int(ratio[i]*num_steps+0.5)
       stage_wise_step.append([start_step,min(end_step,num_steps)]) 
       start_step = end_step
    return stage_wise_step


