from transformers import PretrainedConfig


def get_max_prune_rate(in_channel):
    if in_channel <= 8:
        return 0.0
    elif in_channel <= 16:
        return 1 / 2
    elif in_channel <= 32:
        return 3 / 4
    elif in_channel <= 64:
        return 7 / 8
    else:
        return 1.0


def generate_prune_dict(model, model_name, sparsity, model_config: PretrainedConfig = None):
    prune_dict = {}
    set_up_info = {'cgb':{},'dtype':{}}
    for name, parameter in model.named_parameters():
        # DeBERTa
        if 'deberta' in model_name.lower():
            # FFN
            if ('intermediate.dense.weight' in name or 'output.dense.weight' in name) \
                and ('attention' not in name):
                prune_dict[name] = sparsity
            # Attention
            # Optional: prune all kind of attentions(i.e. pos_proj, pos_q_proj)
            # if 'attention.self.in_proj.weight' in name or 'attention.self.pos_proj.weight' in name \
            #     or 'attention.self.pos_q_proj.weight' in name or 'attention.output.dense.weight' in name:
            if 'attention.self.in_proj.weight' in name or 'attention.output.dense.weight' in name:
                prune_dict[name] = sparsity
        # Bert
        elif 'bert' in model_name.lower():
            # FFN
            # Note: 'output.dense' here includes 'attention.output.dense',
            # but it doesn't matter, cuz we will set the part belong to attention layer below
            for mod in ('output.dense', 'intermediate.dense'):
                    if f'{mod}.weight' in name:
                        prune_dict[name] = sparsity

            # Attention
            # As mentioned above, 'attention.output.dense' will be set here.
            for mod in ('query', 'key', 'value', 'attention.output.dense'):
                if f'{mod}.weight' in name:
                    if 'output.dense' in name and not getattr(model_config, 'quantization', {}):
                        prune_dict[name] = sparsity * 0.5
                    # TODO: verify this strategy
                    else:
                        prune_dict[name] = sparsity * 0.75
        elif 'fastspeech' in model_name.lower():
            if len(parameter.shape) < 2:
                print('skip dim=1', name, parameter.shape)
                continue
            elif 'postnet' in name:
                print('skip postnet linear', name, parameter.shape)
                continue
            elif 'layer' in name and 'weight' in name:
                print('prune en/decoder', name, parameter.shape)
                prune_dict[name] = sparsity
                set_up_info['cgb'][name] = 64
                set_up_info['dtype'][name] = 'int8'
            elif 'adaptor' in name and 'weight' in name and parameter.shape[0]!=1:
                print('prune adaptor', name, parameter.shape)

                prune_dict[name] = min(sparsity, 0.875)
                set_up_info['cgb'][name] = 64
                set_up_info['dtype'][name] = 'int8'
            elif 'postnet' in name and 'weight' in name:
                print('prune postnet', name, parameter.shape)
                prune_dict[name] = sparsity
                set_up_info['cgb'][name] = 64
                set_up_info['dtype'][name] = 'int8'
        # T5
        elif 't5-' in model_name.lower():
            # if model_config:
            #     num_encoder_layers = getattr(model_config, 'num_layers', 0)
            #     num_decoder_layers = getattr(model_config, 'num_decoder_layers', 0)
            
            '''1st & last layer of encoder'''
            # TODO: clarify this strategy
            # if 'encoder.block.0' in name:
            #     continue
            # TODO: clarify this strategy
            # if model_config and f'encoder.block.{num_encoder_layers - 1}' in name:
            #     continue

            '''1st & last layer of decoder'''
            # TODO: clarify this strategy
            # if 'decoder.block.0' in name:
            #     continue
            # TODO: clarify this strategy
            # if model_config and f'decoder.block.{num_decoder_layers - 1}' in name:
            #     continue

            # FFN
            if 'DenseReluDense' in name:
                sub_module = ['wi', 'wo']
                for mod_name in sub_module:
                    if f'DenseReluDense.{mod_name}.weight' in name:
                        prune_dict[name] = sparsity

            # Attention
            if 'SelfAttention' in name or 'EncDecAttention' in name:
                sub_module = ['q', 'k', 'v', 'o']
                for mod_name in sub_module:
                    if f'Attention.{mod_name}.weight' in name:
                        prune_dict[name] = sparsity  #if mod_name != 'o' else 0.5 * sparsity
        # Other cases
        else:   
            if 'weight' in name and len(parameter.shape)>=2:
                if len(parameter.shape)==4:
                    if list(parameter.shape)[2:] == [1, 1]:
                        max_prune_rate = get_max_prune_rate(list(parameter.shape)[1])
                    else:
                        max_prune_rate = 1.0
                    set_up_info['cgb'][name]=64
                    set_up_info['dtype'][name]='int8'
                else:
                    max_prune_rate = 0.75
                    set_up_info['cgb'][name]=512
                    set_up_info['dtype'][name]='int8'
                    
                prune_dict[name] = min(sparsity, max_prune_rate)

    return prune_dict, set_up_info