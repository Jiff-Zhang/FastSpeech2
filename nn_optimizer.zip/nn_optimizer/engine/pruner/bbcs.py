import copy
import os
import numpy as np 
from numpy.core.fromnumeric import reshape
import torch
from torch.nn.parallel import DistributedDataParallel
import torch.nn.functional as F
from collections import OrderedDict

from .build import PRUNER 


def get_hook(mask):
    def hook(grad):
        grad = grad.clone() #Never change the given grad inplace 
        grad *= mask
        return grad 
    return hook


def get_topk(in_channel,bank_size):
    if in_channel <= 8:
        return bank_size
    elif in_channel <= 16:
        return int(bank_size*(1/2))
    elif in_channel <= 32:
        return int(bank_size*(1/4))
    elif in_channel <= 64: 
        return int(bank_size*(1/8))
    else:
        return 0

@PRUNER.register_module(name='bbcs')
class Prune:
    def __init__(self,model,bank_size,topk,pvalue_initial,pvalue_final,pvalue_update_freq,budget_initial,budget_final,
            budget_update_freq,num_steps,pvalue_warmup_steps,bankwise_budget_update_steps,budget_multiplier,warmup_budget_update_freq,mask_update_freq=50,
            power=3,pvalue_power=1,log_path=None,log_freq=100,debug=True,rank=-1,prune_dict:dict={},ckpt_sparsities: list=[0.5,0.75,0.875,0.9375]):
        if isinstance(model,DistributedDataParallel):
            self.model = model.module
        else:
            self.model = model
        self.log_path = log_path
        self.bank_size = bank_size
        self.power = power
        self.pvalue_power = pvalue_power
        self.step = 1
        self.pvalue_step = 1
        self.budget_step = 1
        self.topk_value = topk
        self.debug = debug
        self.log_freq = log_freq
        self.rank = rank
        self.pvalue_initial = pvalue_initial
        self.pvalue_final = pvalue_final
        self.pvalue = pvalue_initial
        self.pvalue_update_freq = pvalue_update_freq
        self.budget_update_freq = budget_update_freq
        self.mask_update_freq = mask_update_freq
        self.num_steps = num_steps
        self.pvalue_warmup_steps = pvalue_warmup_steps
        # bank wise budget update start step
        self.bwb_start_step = num_steps-bankwise_budget_update_steps
        self.budget_multiplier = budget_multiplier
        self.warmup_budget_update_freq = warmup_budget_update_freq
        p_remainder = (num_steps-pvalue_warmup_steps-bankwise_budget_update_steps)%pvalue_update_freq
        #b_remainder = num_steps%budget_update_freq
        pstep_remainder =  pvalue_update_freq if p_remainder==0 else p_remainder
        #bstep_remainder = budget_update_freq if b_remainder==0 else b_remainder 
        # Give pvalue_final #pvalue_update_freq steps to finetune
        pvalue_update_steps = num_steps-pvalue_warmup_steps-bankwise_budget_update_steps
        self.num_of_pvalue_update = int((pvalue_update_steps-pstep_remainder)/pvalue_update_freq)
        # Give budget_final #budget_update_freq steps to finetune
        #self.num_of_budget_update = int((num_steps-pvalue_warmup_steps-bstep_remainder)/budget_update_freq)
        self.max_ic = 512 #max input channel which is decided by compilier
        self._finetune = False
        self.ckpt_sparsities = ckpt_sparsities

        self.modules = OrderedDict()
        self.topk = OrderedDict()
        self.meta_info = OrderedDict()
        self.default_sparsity = topk/bank_size
        for name,module in self.model.named_modules():
            if type(module)==torch.nn.Conv2d:
                if name in prune_dict.keys():
                    self.topk[name] = prune_dict[name]
                elif (module.weight.shape[2]==1):
                    conv1x1_topk = max(get_topk(module.weight.shape[1],bank_size),topk) 
                    if conv1x1_topk==bank_size:
                        continue
                    else:
                        self.topk[name] = conv1x1_topk
                else:
                    _,ic,_,_ = module.weight.shape
                    self.topk[name] = topk if ic>=bank_size else round(ic*self.default_sparsity+0.5)
                 
                self.modules[name] = module

            # if type(module)==torch.nn.Linear:
            #     _,ic = module.weight.shape
            #     if name in prune_dict.keys():
            #         self.topk[name] = prune_dict[name]
            #     else:
            #         self.topk[name] = topk if ic>=bank_size else round(ic*self.default_sparsity+0.5)
            #     self.modules[name] = module

        # init mask,alpha_mask,removed_budget      
        weights = []
        self.topks = []
        for name,module in self.modules.items(): 
            weight = module.weight.clone()
            weight,dim_info,topks = self.frontend_weight_reshape(weight,self.topk[name])
            self.meta_info[name] = dim_info
            self.topks.append(topks)
            weights.append(weight)
        weights = torch.cat(weights)
        self.topks = torch.cat(self.topks)
        self.mask,self.alpha_mask,self.removed_budget= self.compute_mask(weights,self.pvalue)

        # init bank-wise budget
        if pvalue_warmup_steps>0:
            # Stage 1 , budget will be update 
            self.budget_initial=torch.ones((weights.shape[0],1),dtype=weights.dtype,device=weights.device)*self.bank_size
            self.budget_final=torch.ones((weights.shape[0],1),dtype=weights.dtype,device=weights.device)*self.topks*budget_multiplier
            self.budget = self.budget_initial
        else:
            if isinstance(budget_initial,dict) and isinstance(budget_final,dict):
                self.budget_initial = []
                self.budget_final = [] 
                for name,module in self.modules.items():
                    bi_item = torch.from_numpy(budget_initial[name]).to(dtype=module.weight.dtype,device=module.weight.device)
                    bf_item= torch.from_numpy(budget_final[name]).to(dtype=module.weight.dtype,device=module.weight.device)
                    self.budget_initial.append(bi_item)
                    self.budget_final.append(bf_item) 
        
                self.budget_initial = torch.cat(self.budget_initial)
                self.budget_final = torch.cat(self.budget_final)
            else:
                self.budget_initial=torch.ones((weights.shape[0],1),dtype=weights.dtype,device=weights.device)*self.topks*budget_multiplier
                self.budget_final=torch.ones((weights.shape[0],1),dtype=weights.dtype,device=weights.device)*self.topks*budget_multiplier

        self.budget = self.budget_initial
        
        del weights
        

    def frontend_weight_reshape(self,weight,topk=None):
        """
        Note:
            the input channel of conv2d 1x1 kernel should not less than bank size
        """
        if len(weight.shape)==4: # torch.nn.Conv2d
            oc,ic,kz,kz = weight.shape
            if kz==1:
                if ic%self.max_ic==0:
                    num_group = ic//self.max_ic
                else:
                    num_group = ic//self.max_ic + 1
                    weight = F.pad(weight,(0,0,0,0,0,num_group*self.max_ic-ic),'constant',0)
                    
                num_bank = self.max_ic//self.bank_size
                weight = weight.view(oc,num_group,-1,kz,kz).view(oc,num_group,self.bank_size,num_bank,kz,kz)
                weight = weight.transpose(2,3).permute(0,1,2,4,5,3).contiguous().view(-1,self.bank_size)
                dim_info = (weight.shape[0],oc,ic,kz,kz,num_group,num_bank,self.bank_size)

                if topk:
                    topks = torch.ones((oc,num_group,1,num_bank,kz,kz),dtype=weight.dtype,device=weight.device)*topk
                    if ic%self.max_ic!=0:
                        scalar = (ic-(num_group-1)*self.max_ic)/(self.max_ic/self.bank_size)/self.bank_size
                        topks[:,-1,:,:,:,:] = topk*scalar 

                    topks = topks.transpose(2,3).permute(0,1,2,4,5,3).contiguous().view(-1,1)
            else:
                # Hypothesis:  ic%self.bank_size==0
                if ic>= self.bank_size:
                    num_bank = ic//self.bank_size
                    actual_bank_size = self.bank_size
                else:
                    num_bank = 1
                    actual_bank_size = ic
                weight = weight.view(oc,num_bank,actual_bank_size,kz,kz).permute(0,1,3,4,2).contiguous()
                if actual_bank_size<self.bank_size:
                    weight = F.pad(weight,(0,self.bank_size-actual_bank_size),'constant',0)
                weight = weight.view(-1,self.bank_size)
                dim_info = (weight.shape[0],oc,ic,kz,kz,0,num_bank,actual_bank_size)

                if topk:
                    topks = torch.ones((weight.shape[0],1),dtype=weight.dtype,device=weight.device)*topk
        else: # torch.nn.Linear
            oc,ic = weight.shape
            if ic%self.max_ic==0:
                num_group = ic//self.max_ic
            else:
                num_group = ic//self.max_ic + 1
                weight = F.pad(weight,(0,num_group*self.max_ic-ic),'constant',0)
                
            num_bank = self.max_ic//self.bank_size
            weight = weight.view(oc,num_group,-1).view(oc,num_group,self.bank_size,num_bank)
            weight = weight.transpose(2,3).contiguous().view(-1,self.bank_size)
            dim_info = (weight.shape[0],oc,ic,0,0,num_group,num_bank,self.bank_size)

            if topk:
                topks = torch.ones((oc,num_group,1,num_bank),dtype=weight.dtype,device=weight.device)*topk
                if ic%self.max_ic!=0:
                    scalar = (ic-(num_group-1)*self.max_ic)/(self.max_ic/self.bank_size)/self.bank_size
                    topks[:,-1,:,:] = topk*scalar 

                topks = topks.transpose(2,3).contiguous().view(-1,1)

        if topk:
            return weight,dim_info,topks
        else:
            return weight,dim_info 


    def frontend_weight_recover(self,weight,dim_info):
        _,oc,ic,kz,kz,num_group,num_bank,actual_bank_size = dim_info
        if kz!=0:
            if kz==1:
                weight = weight.view(oc,num_group,num_bank,kz,kz,actual_bank_size).permute(0,1,2,5,3,4).contiguous()
                weight = weight.transpose(2,3).contiguous().view(oc,num_group*num_bank*actual_bank_size,kz,kz)
                if ic%self.max_ic!=0:
                    weight = weight[:,:ic,:,:]
            else:
                weight = weight.view(oc,num_bank,kz,kz,self.bank_size).permute(0,1,4,2,3).contiguous()
                if actual_bank_size < self.bank_size:
                    weight = weight[:,:,:actual_bank_size,:,:]
                weight = weight.view(oc,ic,kz,kz)
        else:
            weight = weight.view(oc,num_group,num_bank,actual_bank_size).transpose(2,3).contiguous()
            weight = weight.view(oc,num_group*num_bank*actual_bank_size)
            if ic%self.max_ic!=0:
                weight = weight[:,:ic]

        return weight

    
    def update_pvalue(self):
        """ increase the pvalue
        """
        #self.pvalue = self.pvalue + (self.pvalue_final-self.pvalue_initial)/(self.num_of_pvalue_update)
        self.pvalue = self.pvalue_initial + (self.pvalue_final-self.pvalue_initial)*pow(self.pvalue_step/self.num_of_pvalue_update,self.pvalue_power)
        self.pvalue_step += 1
        

    def update_budget(self,num_steps,update_freq,step):
        """ update the bank-wise budget

        Note: 
            this func should be called in every pruning step if budget need to be changed
            budget will be update in a fix frequency
        """
        if  step%update_freq==0:
            self.budget= self.budget_final+(self.budget_initial-self.budget_final)*pow((1-step/num_steps),self.power)


    def update_bankwise_budget(self):
        # get nnz 
        nnzs = []
        for name,module in self.modules.items():
            nnz = self.appox_nnz(module.weight,0.95).to(torch.float32)
            nnzs.append(nnz)
        nnzs  = torch.cat(nnzs)

        stage3_update_freq = 100
        budget_lr = 0.002
        if self.step%stage3_update_freq==0:
            print("budget_update")
            self.budget = self.budget - budget_lr*(nnzs-self.topks)

    
    def compute_mask(self,weights,p_value):
        """ update the alpha_mask and removed_budget based on new pvalue

        Note:
            the func should be called whenever pvalue changed
        
        Shape:
            weight: (num_banks,bank_size) 
            mask: (num_banks,bank_size)
            alpha_mask: (num_banks,bank_size)
            removed_budget: (num_banks,1)
        """
        with torch.no_grad():
            mask = torch.where(weights.abs()>1e-6,1,0)
            weights = torch.mul(weights,mask)
            alpha_mask = 1/p_value * (torch.pow(weights.abs(),(1-p_value) / p_value))
            alpha_mask = alpha_mask.clamp(max=1e6)
            removed_budget = (1-1/p_value)*torch.pow(weights.abs(),1/p_value)

            # debug
            if self.debug:
                assert_condition = torch.all((torch.pow(weights.abs(),1/p_value)-(alpha_mask*weights.abs()+removed_budget)).abs()<=1e-4)
                assert assert_condition,'removed_budget is too small to be an upper bound' 
                remove_budget_sum = torch.sum(removed_budget,dim=1,keepdim=True)
                assert_condition=torch.sum(alpha_mask*weights.abs(),dim=1,keepdim=True)+remove_budget_sum-torch.sum(torch.pow(weights.abs(),1/p_value),dim=1,keepdim=True)
                assert_condition = assert_condition.abs() <= 1e-4
                assert torch.all(assert_condition),'assert exception for alpha mask'

        return mask,alpha_mask,removed_budget

    
    def project_onto_l1_ball(self,x,alpha_mask,eps):
        """ compute projections on the positive simplex or the L1-ball

        Reference: 
            https://stanford.edu/~jduchi/projects/DuchiShSiCh08.pdf 
        """
        original_shape = x.shape
        x = x.view(x.shape[0], -1)
        mask = (torch.norm(alpha_mask*x, p=1, dim=1,keepdim=True) < eps).float()
        mu, idx = torch.sort(torch.abs(x)/alpha_mask, dim=1, descending=True)
        perm_alpha_mask = alpha_mask.gather(1,idx)
        perm_x = x.abs().gather(1,idx)

        weighted_cumsum = torch.cumsum(perm_alpha_mask*perm_x, dim=1)
        alpha_mask_sq_cumsum = torch.cumsum( perm_alpha_mask*perm_alpha_mask, dim=1 )
        arange = torch.arange(1, x.shape[1] + 1, device=x.device)
        rho, _ = torch.max(( mu*alpha_mask_sq_cumsum > (weighted_cumsum - eps) ) * arange, dim=1)
        alpha_mask_sq_sum = alpha_mask_sq_cumsum[torch.arange(x.shape[0]),rho.cpu()-1]
        theta = (weighted_cumsum[torch.arange(x.shape[0]), rho.cpu() - 1] - eps.squeeze(1)) / alpha_mask_sq_sum
        proj = (torch.abs(x) - alpha_mask*theta.unsqueeze(1)).clamp(min=0) * torch.sign(x)
        x = mask * x + (1 - mask) * proj 
        
        if self.debug:
            norm_debug  = torch.norm(alpha_mask*x,p=1,dim=1,keepdim=True)
            if not torch.all(norm_debug<=eps+1):
                res = torch.max((norm_debug-eps).abs()).detach().cpu().numpy()
            assert torch.all(torch.norm(alpha_mask*x,p=1,dim=1,keepdim=True)<=eps+1),'Not satisfy constraint after projection'
        return x.view(original_shape)


    def project(self,lr=None,orig_modules=None):
        """ project function 

        Args:
            lr: learning rate 
            orig_modules (dict): model modules which is a mirror of model before upgrade 

        Return:
            weights: weight after projection
            
        Shape:
            weights: (num_banks,bank_size)
        """
        if orig_modules:
            orig_weights = []
            for _,module in orig_modules.items():
                weight,_ = self.frontend_weight_reshape(module.weight)
                orig_weights.append(weight)
            orig_weights = torch.cat(orig_weights)

        weights = []
        for _,module in self.modules.items():
            weight,_ = self.frontend_weight_reshape(module.weight)
            weights.append(weight) 
        weights = torch.cat(weights)
        weights =torch.mul(weights,self.mask)
        eps = self.budget-torch.sum(self.removed_budget,dim=1,keepdim=True)
        assert torch.all(eps>0),'eps should be greater than 0'
        weights = self.project_onto_l1_ball(weights,self.alpha_mask,eps)

        return weights

    
    def appox_nnz(self,weight,include_percentage=0.95):
        """
        Args:
            weight (Tensor)
            include_percentage 

        Return:
            nnz (Tensor)
        
        Shape:
            weight: (output_channel,input_channel,kernel_size,kernel_size)
            nnz: (output_channel,input_channel,kernel_size,kernel_size)
        """
        weight = weight.clone()
        weight,_ = self.frontend_weight_reshape(weight)
        mu,_ = torch.sort(weight.abs(),dim=1,descending=True)
        cumsum = torch.cumsum(mu,dim=1)
        ratio = cumsum/torch.sum(mu,dim=1,keepdim=True)
        arange = torch.arange(1,weight.shape[1]+1,device=weight.device)
        arange = torch.reshape(arange,(1,weight.shape[1]))
        rho,_ = torch.max((ratio<include_percentage)*arange,dim=1,keepdim=True)
        nnz = rho+1.0
        return nnz
    

    def budget_uitilized_rate(self,weights,budget):
        """ Caculate the budget utilized rate of weight

        Args:
            weight (Tensor): kernel weight
            budget (Tensor): bank-wise budget
        
        Return:
            mean_bu_rate: (float) mean value of budget uitilized rate
        
        Shape:
            weight: (num_banks,bank_size)
            budget: (num_banks,bank_size)
        """
        weights = weights.clone()
        rate = torch.sum(torch.pow(weights.abs(),1/self.pvalue),dim=1,keepdim=True)/budget 
        mean_bu_rate = torch.mean(rate).item()
        return mean_bu_rate


    @torch.no_grad()
    def prune(self,lr=None,orig_weight=None):
        """ pruning function 
        
        Note: func should be called after each weight update in the train pipe.
            eg,after the optimizer.step()
        """
        weights = self.project(lr,orig_weight)

        # stage 1: pvalue fixed to 1, budget update 
        if self.step<=self.pvalue_warmup_steps:
            self.update_budget(self.pvalue_warmup_steps,self.warmup_budget_update_freq,self.budget_step)
            self.budget_step += 1

        # stage 2: pvalue update, budget fixed 
        if self.step>self.pvalue_warmup_steps  and self.step%self.pvalue_update_freq==0 and self.step<self.bwb_start_step:
            self.budget_step = 1
            self.update_pvalue()
            # self.budget= self.budget_initial*torch.pow(self.budget_final/self.budget_initial,
            #         (self.pvalue-self.pvalue_initial)/(self.pvalue_final-self.pvalue_initial))
            self.mask,self.alpha_mask,self.removed_budget = self.compute_mask(weights,self.pvalue)

        # stage 3:  update bank-wise budget with [target_nnz-current_nnz] as gradient      
        if self.step>self.bwb_start_step and self.step!=self.num_steps:
            self.update_bankwise_budget()


        if self.step>0 and self.step%self.mask_update_freq==0:
            self.mask,self.alpha_mask,self.removed_budget = self.compute_mask(weights,self.pvalue)

            # dump log of NNZ and budget utilization rate 
            if self.debug and self.step%self.log_freq==0 and (self.rank in [-1,0]): 
                nnz_str = ''
                
                with open(os.path.join(self.log_path,'nnz.txt'),'a') as f:
                    for name,module in self.modules.items():
                        nnz = self.appox_nnz(module.weight,0.95).to(torch.float32)
                        num_bank,_= nnz.shape
                        mode = torch.mode(nnz.view(-1))[0].to(torch.int).item()
                        mean = torch.round(torch.mean(nnz)).to(torch.int).item()
                        min = torch.min(nnz).to(torch.int).item()
                        max = torch.max(nnz).to(torch.int).item()
                        num_mode = torch.count_nonzero(nnz==mode).item()
                        num_mean = torch.count_nonzero(nnz==mean).item()
                        num_min = torch.count_nonzero(nnz==min).item()
                        num_max = torch.count_nonzero(nnz==max).item()
                        nnz_str+='mode:'+str(mode)+'['+str(num_mode)+'],'
                        nnz_str+='mean:'+str(mean)+'['+str(num_mean)+'],'
                        nnz_str+='min:'+str(min)+'['+str(num_min)+'],'
                        nnz_str+='max:'+str(max)+'['+str(num_max)+'],'
                        nnz_str=nnz_str+'#bank:'+str(num_bank)+' | '
                    f.write(nnz_str+'\n')

                with open(os.path.join(self.log_path,'budget_utilized_rate.txt'),'a') as f:
                    bu_rate = self.budget_uitilized_rate(weights,self.budget)
                    budget_utilized_rate = str(round(bu_rate,3))
                    f.write(budget_utilized_rate+'\n')

        #  kernel weight shape recover 
        idx_start = 0 
        for name,module in self.modules.items(): 
            info = self.meta_info[name]
            weight = weights[idx_start:idx_start+info[0],:]
            idx_start += info[0]
            weight = self.frontend_weight_recover(weight,info)
            module.weight.data.copy_(weight.data)
        self.step += 1
        return self.pvalue


    def stage_wise_prune(self):
        """ stage wise pruning function 
        
        Note: 

        - prune scheduler : 
            divide total steps into len(sparsities) parts. each part contains a pruning stage and a finetune stage
            after each part , save the sparse model ckpt and remove the weight hook
        """
        finetune_steps = 10
        if not self._finetune:
            self.prune()
            curr_sparsity = self.sparsity(adaptive_mask=True)[1]
            if curr_sparsity>=self.ckpt_sparsities[0]:
                save_path = os.path.join(self.log_path,str(round(self.ckpt_sparsities[0],4))+'_dense.pth')
                torch.save(self.model.state_dict(),save_path)
                self.finetune(adaptive_mask=True)
                self.stage_step = self.step
        else:
            if self.step > self.stage_step+finetune_steps:
                self.hook.remove()
                self._finetune=False
                sparsity = self.ckpt_sparsities.pop(0)
                save_path = os.path.join(self.log_path,str(sparsity)+'_sparse.pth')
                torch.save(self.model.state_dict(),save_path)

        return self.pvalue


    # to be update with frontend compatiable version
    def mask_weight(self,weight,topk):
        reshaped_weight,dim_info,topks = self.frontend_weight_reshape(weight.clone(),topk)

        one_hot = torch.zeros_like(reshaped_weight,dtype=torch.float,device=reshaped_weight.device)
        for item in torch.unique(topks):
            idx = (topks==item).nonzero(as_tuple=True)[0]
            max_idx = torch.topk(reshaped_weight[idx,:].abs(),k=int(item.item()),dim=1).indices
            one_hot[idx,:] = one_hot[idx,:].scatter_(1,max_idx,1)
        one_hot = self.frontend_weight_recover(one_hot,dim_info)

        new_masked_weight = weight.data * one_hot
        weight.data = new_masked_weight

    
    def adaptive_mask_weight(self,weight):
        reshaped_weight,dim_info= self.frontend_weight_reshape(weight.clone())

        one_hot = torch.zeros_like(reshaped_weight,dtype=torch.float,device=reshaped_weight.device)
        nnz = self.appox_nnz(weight)
        nnz_mode = torch.mode(nnz.view(-1))[0].to(torch.int).item()
        max_idx = torch.topk(reshaped_weight.abs(),k=nnz_mode,dim=1).indices
        one_hot.scatter_(1,max_idx,1)
        one_hot = self.frontend_weight_recover(one_hot,dim_info)

        new_masked_weight = weight.data * one_hot
        weight.data = new_masked_weight


    def sparse_model(self,adaptive_mask=True):
        self.state_dict = copy.deepcopy(self.model.state_dict())
        self.model.eval() 

        for name,module in self.modules.items():
            if adaptive_mask:
                self.adaptive_mask_weight(module.weight)
            else:
                self.mask_weight(module.weight,self.topk[name])
         
        return self.model
    
    
    def recover(self):
        self.model.load_state_dict(self.state_dict)


    def finetune(self,adaptive_mask=True):
        self._finetune = True
        for name,module in self.modules.items():
            if adaptive_mask:
                self.adaptive_mask_weight(module.weight)
            else:
                self.mask_weight(module.weight,self.topk[name])
            mask = (np.abs(module.weight.clone().data.cpu().numpy())>0).astype(float)
            mask = torch.as_tensor(mask,dtype=module.weight.dtype,device=module.weight.device)
            self.hook = module.weight.register_hook(get_hook(mask))


    def sparsity(self,adaptive_mask=False):
        self.sparse_model(adaptive_mask)
        total_param = 0
        total_nonezero = 0
        layer_sparse_rate = {}
        for name, module in self.model.named_modules():
            if isinstance(module,(torch.nn.Conv2d,torch.nn.Linear)):
                temp = module.weight.data.cpu().numpy()
                total_param = total_param + temp.size
                total_nonezero = total_nonezero + np.flatnonzero(temp).size
                layer_sparse_rate[name] = 1 - np.flatnonzero(temp).size / temp.size
        total_sparse_rate = 1 - total_nonezero / total_param
        self.recover()
        return layer_sparse_rate, total_sparse_rate

    # def flops_params_sparsity(self):
    #     """
    #     Apply to get the FLOPs and parameters sparsity of all Conv2d layer in model.
    #     Warning: only caculate sparsity on Conv2d layer 

    #     Returns:
    #         flops_sparsity (scalar) 
    #         layer_sparse_rate (dict)
    #         total_sparse_rate (scalar) 
    #     """
    #     input_size = [1] + list(self.input_size)
    #     summary_res = summary(self.model,input_size=input_size,verbose=0,
    #                         depth=100,col_width=16,
    #                         col_names=["kernel_size", "output_size", "num_params", "mult_adds"],
    #                         row_settings=["var_names"])
    #     print(summary_res)
    #     layer_macs = []
    #     for module in summary_res.summary_list:
    #         #if isinstance(module.module,torch.nn.Conv2d):
    #         if isinstance(module.module,torch.nn.Conv2d):
    #             layer_macs.append(module.macs)
        
    #     layer_sparsity = []
    #     total_param = 0
    #     total_nonezero = 0
    #     layer_sparse_rate = {}
    #     for name,module in self.model.named_modules():
    #         if isinstance(module,torch.nn.Conv2d):
    #             temp = module.weight.data.cpu().numpy()
    #             sparsity = 1- np.flatnonzero(temp).size / temp.size
    #             total_param = total_param + temp.size
    #             total_nonezero = total_nonezero + np.flatnonzero(temp).size
    #             layer_sparse_rate[name] = sparsity
    #             layer_sparsity.append(sparsity)
    #     total_sparse_rate = 1 - total_nonezero / total_param
        
    #     total_macs = 0
    #     total_macs_remain = 0
    #     for ma,sp in zip(layer_macs,layer_sparsity):
    #         total_macs_remain = total_macs_remain + ma*(1-sp)
    #         total_macs += ma
    #     flop_sparsity = 1 - total_macs_remain/total_macs
    #     return flop_sparsity,layer_sparse_rate, total_sparse_rate

    

