__all__ = ["Prune"]

import os
import torch
import numpy
import torchvision
import numpy as np
import deepspeed

from .compiler_frontend_prune_unit import (
    update_mask,
    prune_dim_2,
    prune_dim_4,
    prune_dim_3
)
from .build import PRUNER

def gather_params(func):
    def inner(*args):
        if args[0].is_zero3:
            with deepspeed.zero.GatheredParameters(list(args[0]._model.parameters()),
                                    modifier_rank=0):
                if torch.distributed.get_rank() == 0:
                    return func(*args)
        else:
            return func(*args)
        
    return inner


def sparsity_gather_params(func):
    def inner(*args):
        if args[0].is_zero3:
            with deepspeed.zero.GatheredParameters(list(args[0]._model.parameters()),
                                    modifier_rank=0):
                if torch.distributed.get_rank() == 0:
                    return func(*args)
                return {},-1
        else:
            return func(*args)
        
    return inner

@PRUNER.register_module(name='bbs')
class Prune:
    def __init__(
        self,
        model,
        pretrain_step: int = 0,
        sparse_step: int = 0,
        current_step: int=0,
        frequency: int = 100,
        prune_dict: dict = {},
        restore_sparsity: bool = False,
        fix_sparsity: bool = False,
        prune_device: str = "default",
        deploy_device: str = "none",
        group_size: int = 64,
        set_up_infos: dict = None,
        is_zero3=False
    ):
        self._model = model
        self.set_up_infos = set_up_infos
        self.is_zero3 = is_zero3
        self._t = current_step
        self._initial_sparsity = {}
        self._pretrain_step = pretrain_step
        self._sparse_step = sparse_step
        self._frequency = frequency
        self._prune_dict = prune_dict
        self._restore_sparsity = restore_sparsity
        self._fix_sparsity = fix_sparsity
        self._prune_device = prune_device
        self._deploy_device = deploy_device
        self._fpga_input_group = 4
        # self._asic_input_gloup = 8
        self._group_size = group_size
        self._asic_input_gloup = 512 // group_size
        self._mask = {}
        self._check_parameter()
        self._prepare()

    def _check_parameter(self):
        assert isinstance(self._pretrain_step, int)
        assert isinstance(self._sparse_step, int)
        assert isinstance(self._frequency, int)
        assert isinstance(self._prune_dict, dict)
        assert isinstance(self._restore_sparsity, bool)
        assert isinstance(self._fix_sparsity, bool)
        assert self._prune_device in ["default", "cpu"]
        assert self._deploy_device in ["none", "fpga", "asic"]

    def _prepare(self):
        with torch.no_grad():
            for name, parameter in self._model.named_parameters():
                if any(name == one for one in self._prune_dict):
                    if (
                        (self._deploy_device == "fpga")
                        and (len(parameter.shape) == 4)
                        and (parameter.shape[1] < self._fpga_input_group)
                    ):
                        self._prune_dict.pop(name)
                        print(
                            "For %s, the parameter %s cannot be balanced pruned and will be deleted from the prune_dict."
                            % (self._deploy_device, name)
                        )
                        continue
                    elif (
                        (self._deploy_device == "asic")
                        and (len(parameter.shape) == 4)
                        and (parameter.shape[1] < self._asic_input_gloup)
                        and ([parameter.shape[2], parameter.shape[3]] == [1, 1])
                    ):
                        self._prune_dict.pop(name)
                        print(
                            "For %s, the parameter %s cannot be balanced pruned and will be deleted from the prune_dict."
                            % (self._deploy_device, name)
                        )
                        continue
                    weight = self._get_weight(parameter)
                    if self._restore_sparsity == True:
                        mask = torch.where(
                            weight == 0,
                            torch.zeros_like(weight),
                            torch.ones_like(weight),
                        )
                        self._initial_sparsity[name] = (
                            1
                            - mask.cpu().numpy().astype(numpy.float32).sum()
                            / weight.cpu().numpy().size
                        )
                        self._mask[name] = mask
                    else:
                        self._initial_sparsity[name] = 0
                        self._mask[name] = torch.ones_like(weight)

    def _update_mask(self, weight, keep_k):
        if keep_k >= 1:
            reshape_weight = weight.reshape(-1)
            index = torch.topk(reshape_weight.abs(), keep_k)[1].cpu().numpy().tolist()
            mask = numpy.zeros(reshape_weight.shape)
            mask[index] = 1
            mask = mask.reshape(weight.shape)
            mask = torch.as_tensor(mask, dtype=weight.dtype, device=weight.device)
        else:
            mask = torch.zeros_like(weight)
        return mask

    def _update_mask_fpga(self, name, weight, keep_k):
        def _block_sparsity_balance(transpose_weight, keep_k, inc_group):
            reshape_weight = transpose_weight.reshape(
                [
                    -1,
                    transpose_weight.shape[-2]
                    * transpose_weight.shape[-1]
                    // inc_group,
                ]
            )
            base_k = keep_k // reshape_weight.shape[0]
            remain_k = keep_k % reshape_weight.shape[0]
            if remain_k > 0:
                index = torch.topk(reshape_weight.abs(), base_k + 1)[1]
            else:
                index = torch.topk(reshape_weight.abs(), base_k)[1]
            dim1 = []
            dim2 = []
            for i, temp in enumerate(index.cpu().numpy().tolist()):
                for j in temp:
                    dim1.append(i)
                    dim2.append(j)
            mask = numpy.zeros(reshape_weight.shape)
            mask[dim1, dim2] = 1
            mask = mask.reshape(transpose_weight.shape)
            mask = mask.transpose([0, 2, 1, 3])
            mask = torch.as_tensor(
                mask, dtype=transpose_weight.dtype, device=transpose_weight.device
            )
            return mask

        if keep_k >= 1:
            transpose_weight = weight.permute([0, 2, 1, 3])
            if transpose_weight.shape[-2] % self._fpga_input_group == 0:
                mask = _block_sparsity_balance(
                    transpose_weight, keep_k, self._fpga_input_group
                )
            else:
                temp1 = transpose_weight.shape[-2]
                temp4 = (self._fpga_input_group - 1) * (
                    temp1 // self._fpga_input_group + 1
                )
                keep_k_1 = int(temp4 / temp1 * keep_k)
                keep_k_2 = keep_k - keep_k_1
                transpose_weight_1 = transpose_weight[:, :, :temp4, :]
                transpose_weight_2 = transpose_weight[:, :, temp4:, :]
                mask_1 = _block_sparsity_balance(
                    transpose_weight_1, keep_k_1, self._fpga_input_group - 1
                )
                mask_2 = _block_sparsity_balance(transpose_weight_2, keep_k_2, 1)
                mask = torch.cat([mask_1, mask_2], 1)
            self._mask[name][:] = mask
        else:
            self._mask[name][:] = 0

    def _update_mask_asic_4d(self, weight, keep_k, asic_input_gloup=8, dtype='int8', cgb=512):
        def _block_sparsity_balance(transpose_weight, keep_k):
            reshape_weight = torch.reshape(transpose_weight, [-1, transpose_weight.shape[-1]])
            base_k = keep_k // reshape_weight.shape[0]
            remain_k = keep_k % reshape_weight.shape[0]
            if remain_k > 0:
                index = torch.topk(reshape_weight.abs(), min(reshape_weight.shape[-1], base_k+1))[1]
            else:
                index = torch.topk(reshape_weight.abs(), min(reshape_weight.shape[-1], base_k))[1]
            dim1 = []
            dim2 = []
            for i, temp in enumerate(index.cpu().numpy().tolist()):
                for j in temp:
                    dim1.append(i)
                    dim2.append(j)
            mask = np.zeros(reshape_weight.shape)
            mask[dim1, dim2] = 1
            mask = mask.reshape(transpose_weight.shape)
            mask = mask.transpose([1, 2, 3, 0])
            mask = torch.as_tensor(mask, dtype=transpose_weight.dtype, device=transpose_weight.device)
            return mask

        if keep_k >= 1:
            h, w, i, o = weight.shape
            transpose_weight = weight.permute([3, 0, 1, 2])
            if transpose_weight.shape[1] == 1 and transpose_weight.shape[2] == 1:
                transpose_weight = torch.squeeze(transpose_weight)
                transpose_weight = torch.transpose(transpose_weight, 1, 0)
                mask = self._update_mask_asic_2d(transpose_weight, keep_k, dtype, asic_input_gloup, cgb)
                mask = torch.reshape(mask, [h, w, i, o])
            else:
                group_size = None
                if dtype == 'int8':
                    group_size = self._group_size
                elif dtype == 'bf16':
                    group_size = self._group_size // 2
                temp1 = transpose_weight.shape[-1] // group_size
                temp2 = transpose_weight.shape[-1] % group_size
                keep_k_1 = int(keep_k * temp1 * group_size / transpose_weight.shape[-1])
                keep_k_2 = keep_k - keep_k_1
                mask = np.ones(weight.shape)
                if temp1 > 0:
                    for i in range(temp1):
                        transpose_weight_1 = transpose_weight[:, :, :, i * group_size: (i + 1) * group_size]
                        mask_1 = _block_sparsity_balance(transpose_weight_1, keep_k_1 // temp1)
                        mask[:, :, i * group_size: (i + 1) * group_size, :] = mask_1.cpu().numpy()
                if temp2 > 0:
                    transpose_weight_2 = transpose_weight[:, :, :, temp1 * group_size:]
                    mask_2 = _block_sparsity_balance(transpose_weight_2, keep_k_2)
                    mask[:, :, temp1 * group_size:, :] = mask_2.cpu().numpy()
                mask = torch.as_tensor(mask, dtype=transpose_weight.dtype, device=transpose_weight.device)
        else:
            mask = torch.zeros_like(weight)
        return mask

    def _update_mask_asic_2d(self, weight, keep_k, dtype, asic_input_gloup=8, cgb=512):
        def _block_sparsity_balance(transpose_weight, keep_k):
            reshape_weight = transpose_weight
            base_k = keep_k // reshape_weight.shape[0]
            remain_k = keep_k % reshape_weight.shape[0]
            if remain_k > 0:
                index = torch.topk(reshape_weight.abs(), min(reshape_weight.shape[-1], base_k+1))[1]
            else:
                index = torch.topk(reshape_weight.abs(), min(reshape_weight.shape[-1], base_k))[1]
            dim1 = []
            dim2 = []
            for i, temp in enumerate(index.cpu().numpy().tolist()):
                for j in temp:
                    dim1.append(i)
                    dim2.append(j)
            mask = np.zeros(reshape_weight.shape)
            mask[dim1, dim2] = 1
            mask = mask.transpose([1, 0])
            mask = torch.as_tensor(mask, dtype=transpose_weight.dtype, device=transpose_weight.device)
            return mask

        def _block_1x1(transpose_weight, keep_k, asic_input_gloup=8):
            '''

            :param transpose_weight: [O, I]
            :param keep_k:
            :param asic_input_gloup:
            :return:
            '''
            temp1 = transpose_weight.shape[-1] // asic_input_gloup
            temp2 = transpose_weight.shape[-1] % asic_input_gloup
            for i in range(asic_input_gloup):locals()['list%s' % i] = []
            for i in range(temp1):
                for j in range(i * asic_input_gloup, (i + 1) * asic_input_gloup):
                    locals()['list%s' % (j % asic_input_gloup)].append(j)
            for i in range(temp1 * asic_input_gloup, transpose_weight.shape[-1]):
                locals()['list%s' % (i % asic_input_gloup)].append(i)
            temp3 = []
            for i in range(asic_input_gloup):
                temp3.append(int(len(locals()['list%s' % i]) / transpose_weight.shape[-1] * keep_k))
            group_mask = np.ones(transpose_weight.shape).transpose([1, 0])
            for i in range(asic_input_gloup):
                temp4 = torch.cat([transpose_weight[:, one: one + 1] for one in locals()['list%s' % i]], 1)
                mask = _block_sparsity_balance(temp4, temp3[i])
                for one, two in enumerate(locals()['list%s' % i]):
                    group_mask[two: two + 1, :] = mask[one: one + 1, :].cpu().numpy()
            group_mask = torch.as_tensor(group_mask, dtype=transpose_weight.dtype, device=transpose_weight.device)
            return group_mask

        def computer_mask(weight, in_size, group_size, block_size, keep_k, patch_size, asic_input_gloup):
            temp1_1 = max(int(np.ceil(in_size / group_size)), 1)
            mask = torch.ones(weight.shape, dtype=weight.dtype,device=weight.device)
            np_weight = weight.cpu().numpy()
            ids0 = np.arange(block_size)
            ids0 = np.concatenate([ids0 + (row_id * group_size) for row_id in range(temp1_1)])
            keep_k0 = int(block_size * temp1_1 * keep_k / in_size)
            cur_k = keep_k0
            for col_id in range(patch_size):  # cpart
                ids = ids0 + (block_size * col_id)
                if min(ids) > in_size: break
                if len(ids) > in_size: ids = ids[:in_size]
                ids = ids[:ids.tolist().index(in_size)] if in_size < max(ids) else ids
                mask[ids, :] = _block_1x1(
                    torch.as_tensor(data=np.transpose(np_weight[ids, :], [1, 0]), dtype=weight.dtype,  # IO --> OI
                                    device=weight.device),
                    cur_k,
                    asic_input_gloup
                )
            mask = torch.as_tensor(data=mask, dtype=weight.dtype, device=weight.device)
            return mask

        group_size_max = None
        group_size = None
        block_size = None
        if keep_k >= 1:
            if dtype == 'bf16':
                group_size_max = 256
                group_size = cgb
                block_size = self._group_size // 2
            elif dtype == 'int8':
                group_size_max = 512
                group_size = cgb
                block_size = self._group_size
            in_size, out_size = weight.shape
            if group_size > block_size:
                assert group_size % block_size == 0
            patch_size = max(group_size // block_size, 1)
            if (in_size / patch_size) > group_size_max:
                ori_insize = in_size
                ori_keep_k = keep_k
                inc_group_size = int(np.ceil(in_size / group_size_max))
                temp_list = []
                for i in range(inc_group_size):
                    weight_group = weight[i * group_size_max:(i + 1) * group_size_max, :]
                    in_size, out_size = weight_group.shape
                    keep_k = ori_keep_k * (in_size / ori_insize)
                    mask_group = computer_mask(weight_group, in_size, group_size, block_size, keep_k, patch_size,
                                               asic_input_gloup)
                    temp_list.append(mask_group)
                mask = torch.cat(temp_list, 0)
            else:
                if in_size < block_size:
                    block_size = in_size
                if group_size < self._group_size and dtype == 'int8':
                    group_size = self._group_size
                if group_size < (self._group_size // 2) and dtype == 'bf16':
                    group_size = self._group_size // 2

                mask = computer_mask(weight, in_size, group_size, block_size, keep_k, patch_size, asic_input_gloup)
        else:
            mask = torch.zeros_like(weight)
        return mask

    def _update_mask_conditions(self):
        condition1 = self._fix_sparsity == False
        condition2 = (
            self._pretrain_step < self._t <= self._pretrain_step + self._sparse_step
        )
        condition3 = (self._t - self._pretrain_step) % self._frequency == 0
        return condition1 and condition2 and condition3

    def _get_weight(self, parameter):
        if self._prune_device == "default":
            weight = parameter.data
        elif self._prune_device == "cpu":
            weight = parameter.data.to(device=torch.device("cpu"))
        return weight

    @gather_params
    def prune(self):
        with torch.no_grad():
            self._t = self._t + 1
            for name, parameter in self._model.named_parameters():
                if any(name == one for one in self._prune_dict):
                    weight = self._get_weight(parameter)
                    if self._update_mask_conditions():
                        weight = weight * self._mask[name]
                        target_sparsity = self._prune_dict[name]
                        current_sparse_step = (
                            self._t - self._pretrain_step
                        ) // self._frequency
                        total_srarse_step = self._sparse_step // self._frequency
                        current_sparsity = (
                            target_sparsity
                            + (self._initial_sparsity[name] - target_sparsity)
                            * (1.0 - current_sparse_step / total_srarse_step) ** 3
                        )
                        ####################################
                        keep_k = int(
                            weight.cpu().numpy().size * (1.0 - current_sparsity)
                        )
                        # print('current_sparsity, name, weight.shape: ', current_sparsity, name, weight.cpu().numpy().shape)
                        ##########################################
                        if self._deploy_device == "none":
                            mask = self._update_mask(weight, keep_k)
                            self._mask[name] = mask
                        elif self._deploy_device == "fpga":
                            if len(weight.shape) == 4:
                                self._update_mask_fpga(name, weight, keep_k)
                            else:
                                self._update_mask(weight, keep_k)
                        elif self._deploy_device == "asic":
                            cgb = self.set_up_infos['cgb'][name]
                            dtype_ = self.set_up_infos['dtype'][name]
                            if len(weight.shape) == 4:
                                weight_ = weight.permute([2, 3, 1, 0])
                                weight_ = weight_.cpu().numpy()
                                mask = prune_dim_4(weight=weight_, keep_k=keep_k, dtype=dtype_, cgb=cgb, group_size_value=self._group_size)
                                mask = np.transpose(mask, [3, 2, 0, 1])
                            elif len(weight.shape) == 2:
                                tmp_weight = weight.cpu().numpy()
                                mask = prune_dim_2(weight=tmp_weight, keep_k=keep_k, dtype_=dtype_, cgb=cgb, group_size_value=self._group_size)
                            elif len(weight.shape) == 3:
                                out_, in_, k_ = weight.shape 
                                weight_ = weight.view(-1, self._group_size).cpu().numpy()
                                mask = prune_dim_2(weight=weight_, keep_k=keep_k, dtype_=dtype_, cgb=cgb, group_size_value=self._group_size)
                                mask = np.reshape(mask, [out_, in_, k_])

                            else:
                                mask = update_mask(weight, keep_k)
                            mask = torch.as_tensor(data=mask, dtype=weight.dtype, device=weight.device)
                            self._mask[name] = mask
                    parameter.mul_(self._mask[name])

    @sparsity_gather_params
    def sparsity(self):
        total_param = 0
        total_nonezero = 0
        layer_sparse_rate = {}
        for name, parameter in self._model.named_parameters():
            if any(name == one for one in self._prune_dict):
                temp = parameter.data.cpu().numpy()
                total_param = total_param + temp.size
                total_nonezero = total_nonezero + numpy.flatnonzero(temp).size
                layer_sparse_rate[name] = 1 - numpy.flatnonzero(temp).size / temp.size
        total_sparse_rate = 1 - total_nonezero / total_param
        return layer_sparse_rate, total_sparse_rate


def quick_debug_cls():
    import torchvision.models as models
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    model = models.resnet50(pretrained=True)

    step = 10
    prune_dict = {}
    set_up_infos = {"cgb":{}, "dtype":{}}
    for k, v in model.named_parameters():
        if len(v.shape) < 2:
            continue
        if len(v.shape) == 2:
            set_up_infos["cgb"][k] = 512
        else:
            set_up_infos["cgb"][k] = 64
        print(k, v.shape)
        prune_dict[k] = 1. - (1 / 16)
        set_up_infos["dtype"][k] = 'int8'

    prune = Prune(model, step * 0, step * 8, 10, prune_dict, deploy_device="asic", set_up_infos=set_up_infos)
    prune.prune()

    output_dir="/hdd1/tao/eval_software/debug_case/prune_opti_debug_resnet50/"
    tmp_data = torch.randn(1, 3, 224, 224)
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir,  'resnet50.onnx')
    torch.onnx.export(model, tmp_data, output_path, training=torch.onnx.TrainingMode.TRAINING, do_constant_folding=False)


def quick_debug_nlp():
    bert_path = "/hdd1/tao/prune_params_927/test_framework/frontendcompilerv3/model_and_infos/total/models/nlp/textattack_bert_base_uncased_MRPC#N1#128/traced.pt"
    model = torch.jit.load(bert_path)

    prune_dict = {}
    set_up_infos = {"cgb":{}, "dtype":{}}
    for k, v in model.named_parameters():
        if len(v.shape) < 2:
            continue
        if k == 'bert.pooler.dense.weight' or k == "classifier.weight":
            set_up_infos["cgb"][k] = 256
        else:
            set_up_infos["cgb"][k] = 64
        print(k, v.shape)
        prune_dict[k] = 1. - (1 / 16)
        set_up_infos["dtype"][k] = 'int8'

    step = 10
    prune = Prune(model, step * 0, step * 8, 10, prune_dict, deploy_device="asic", set_up_infos=set_up_infos)
    prune.prune()
    model_save_dir = "/hdd1/tao/eval_software/debug_case/prune_opti_debug_bert/"
    os.makedirs(model_save_dir, exist_ok=True)
    torch.jit.save(model, model_save_dir+"traced.pt")


class yeild_func:
    def __init__(self, params):
        super(yeild_func, self).__init__()
        self.params = params

    def named_parameters(self):
        for k, v in self.params.items():
            if "weight" in k:
                v = torch.as_tensor(data=v.asnumpy(), dtype=torch.float32) if not torch.is_tensor(v) else v
                self.params[k] = v
                yield (k, self.params[k])

    def to_mx_ndarray(self):
        import mxnet as mx
        for k in self.params.keys():
            if "weight" in k:
                self.params[k] = mx.nd.array(self.params[k])


def quick_debug_yolo():
    import mxnet as mx
    model_path = "/hdd1/tao/prune_params_927/test_framework/frontendcompilerv3/model_and_infos/total/models/detection/yolo3_darknet53_coco#N1#256/yolo3_darknet53_coco"
    mx_sym, arg_params, aux_params = mx.model.load_checkpoint(model_path, epoch=0)
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    model = yeild_func(arg_params)

    prune_dict = {}
    set_up_infos = {"cgb":{}, "dtype":{}}
    for k, v in model.named_parameters():
        if len(v.shape) < 2:
            continue
        if len(v.shape) == 2:
            set_up_infos["cgb"][k] = 512
        else:
            set_up_infos["cgb"][k] = 64
        print(k, v.shape)
        prune_dict[k] = 1. - (1 / 16)
        set_up_infos["dtype"][k] = 'int8'
    prune = Prune(model, 0, 1, 10, prune_dict, deploy_device="asic", set_up_infos=set_up_infos)
    prune.prune()

    model.to_mx_ndarray()
    output_dir="/hdd1/tao/eval_software/debug_case/prune_opti_debug_yolo_params_json/"
    os.makedirs(output_dir)
    mx.model.save_checkpoint(os.path.join(output_dir, "yolo3_darknet53_coco"), 0, mx_sym, arg_params, aux_params)


if __name__ == "__main__":
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    class Net(torch.nn.Module):
        def __init__(self):
            super(Net, self).__init__()
            self.conv0 = torch.nn.Conv2d(1, 599, 3, 2)
            self.bn0 = torch.nn.BatchNorm2d(599)
            self.conv1 = torch.nn.Conv2d(599, 100, 1, 1)
            self.bn1 = torch.nn.BatchNorm2d(100)
            self.conv2 = torch.nn.Conv2d(100, 127, 3, 2)
            self.bn2 = torch.nn.BatchNorm2d(127)
            self.conv3 = torch.nn.Conv2d(127, 200, 3, 2)
            self.bn3 = torch.nn.BatchNorm2d(200)
            self.linear1 = torch.nn.Linear(800, 10)

        def forward(self, x):
            x = self.conv0(x)
            x = self.bn0(x)
            x = torch.nn.functional.relu(x)
            x = self.conv1(x)
            x = self.bn1(x)
            x = torch.nn.functional.relu(x)
            x = self.conv2(x)
            x = self.bn2(x)
            x = torch.nn.functional.relu(x)
            x = self.conv3(x)
            x = self.bn3(x)
            x = torch.nn.functional.relu(x)
            x = torch.flatten(x, 1)
            x = self.linear1(x)
            output = torch.nn.functional.softmax(x, dim=1)
            return output

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
    train_data = torchvision.datasets.MNIST(
        "~/.pytorch/datasets", train=True, download=True, transform=transform
    )
    test_data = torchvision.datasets.MNIST(
        "~/.pytorch/datasets", train=False, transform=transform
    )

    batch_size = 256
    epoch = 10
    step = train_data.data.shape[0] // batch_size
    lr = 0.1 / 256 * batch_size

    train_loader = torch.utils.data.DataLoader(
        train_data, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True
    )
    test_loader = torch.utils.data.DataLoader(
        test_data, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True
    )

    model = Net().to(device)

    optimizer = torch.optim.SGD(model.parameters(), lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, step * epoch)

    ########################################################
    prune_dict = {}
    for k, v in model.named_parameters():
        if len(v.shape) < 2:
            continue
        if k == "conv1.weight":
            prune_dict[k] = 0.95
        else:
            prune_dict[k] = 0.99
    prune = Prune(model, step * 0, step * 8, 10, prune_dict, deploy_device="asic")
    ########################################################

    for idx in range(epoch):
        model.train()
        for (data, target) in train_loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            output = model(data)
            loss = torch.nn.functional.cross_entropy(output, target)
            loss.backward()
            optimizer.step()
            scheduler.step()
            #############
            prune.prune()
            #############

        model.eval()
        test_loss = 0
        correct = 0
        with torch.no_grad():
            for data, target in test_loader:
                data, target = data.to(device), target.to(device)
                output = model(data)
                test_loss += torch.nn.functional.cross_entropy(
                    output, target, reduction="sum"
                ).item()
                pred = output.argmax(dim=1, keepdim=True)
                correct += pred.eq(target.view_as(pred)).sum().item()
        test_loss /= len(test_loader.dataset)
        test_acc = correct / len(test_loader.dataset)

        # print(torch.cuda.memory_allocated(torch.device('cuda')))
        #######################################################
        layer_sparse_rate, total_sparse_rate = prune.sparsity()
        #######################################################
        print(
            "Epoch %d: Accuracy=%f; weight sparsity=%s"
            % (idx, test_acc, total_sparse_rate)
        )

    ##########################################################
    layer_sparse_qualify, total_sparse_qualify = prune.check()
    ##########################################################
    print("deploy qualified: %s" % total_sparse_qualify)
    torch.save(model.state_dict(), "pytorch_mnist")
