from nn_optimizer.utils.registry import Registry

PRUNER = Registry('pruner')


def build_pruner(cfg, default_args: dict = None):
    if not default_args.pop('prune', False):
        return None
    return PRUNER.build(cfg, default_args=default_args)
