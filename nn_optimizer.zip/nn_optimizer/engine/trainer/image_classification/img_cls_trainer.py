import os
import glob
from socket import ALG_SET_PUBKEY
import time
import datetime
from datasets import ReadInstruction

import torch
import torch.nn as nn

from tqdm import tqdm
from logging import Logger
from typing import Callable, Dict, Sequence, List, Tuple, Union

from torch.optim import Optimizer
from torch.optim.lr_scheduler import _LRScheduler

from torch.distributed import ReduceOp
from torch.nn.parallel import DataParallel as DP
from torch.nn.parallel import DistributedDataParallel as DDP

from torch.cuda import max_memory_allocated
from torch.utils.data.dataloader import DataLoader
from torch.nn.utils.clip_grad import clip_grad_norm_

from engine.loss import loss_dict
from engine.metric import metric_func_dict

from engine.trainer.builder import TRAINER
from engine.trainer.base_trainer import BaseTrainer

from utils.plot import plot_line
from utils.dist import all_reduce
from utils.meters import AverageMeter, ProgressMeter
from utils.misc import is_seq_of, get_grad_norm, Timer


@TRAINER.register_module(name='image_classification')
class ImgClsTrainer:
    """
    A tranier for image classification task.
    Trainer encapsulates all of operations for network training, e.g. gets batched data, model forwarding,
    computes loss, optimizes parameters, updates lr, saves checkpoints, etc.
    """
    
    # Distribution wrapper, e.g. torch.nn.parallel.DistributedDataParallel
    DIST_CONTAINERS = (DP, DDP,)

    def __init__(
        self, model: nn.Module, optimizer: Optimizer, lr_scheduler: _LRScheduler,
        logger: Logger, epochs: int, log_freq: int = 10, save_freq: int = 10,
        output_dir: str = None, start_epoch: int = 0, grad_accumulation_steps: int = 1,
        clip_grad: bool = False, max_grad_norm: float = 1., loss: str = 'ce', rank=0,
        metric_type: str = 'accuracy', metric_identifier: Sequence[str] = ('top1-accuracy',),
        kd: bool = False, teacher: nn.Module = None, kd_cls_loss: str = None, kd_reg_loss: str = None,
        kd_begin_layer: int = 0
    ):
        """
        Args:
            model (nn.Module): Pytorch neural network module.
            optimizer (Optimizer): Optimize model parameters according to the specified rule.
            lr_scheduler (_LRScheduler): Scheduling learning rate while training.
            logger (BaseLogger): Object that log information and format it.
            epochs (int): Number of training epochs.
            start_epoch (int): The starting training epoch. Default: 0.
            log_freq (int): Logging frequency. Default: 1.
            save_freq (int): Frequency that related to saving checkpoint. Default: 1
            output_dir (str): Directory that store the output results. Default is None.
            grad_accumulation_steps (int): Number of gradient accumulation steps. Default: 1
            clip_grad (bool): Whether to clip gradient during training. Default is False.
            max_grad_norm (float): The max value of gradient norm. Default 1.0.
            loss (str): loss type. Default is None.
            metric_identifier (List[str], str): Metric identifier, such as 'accuracy', 'bleu', etc. Default: 'accuracy'.
            kd (bool): Whether to turn on knowledge distillation. Default is False.
            teacher (nn.Module): The teacher model when kd is set to True. Default is None.
            kd_cls_loss (str): kd classification loss type. Default is None.
            kd_reg_loss (str): kd regression loss type. Default is None.
            kd_begin_layer (int): Default: 0.
        """

        # Model
        self.model = model
        # Naked model without any encapsulated(When in distributed training, model may be encapsulated by DDP)
        self.model_unwrapped = self._unwrap_model(model)

        # Local rank
        self.rank = rank
        # Device
        self.device = model.device
        self.distributed = torch.cuda.is_available() and torch.cuda.device_count() > 1

        # Optimization
        self.optimizer = optimizer
        self.lr_scheduler = lr_scheduler

        # Training Time
        self.start_epoch = start_epoch
        self.end_epoch = epochs

        # Log
        self.log_freq = log_freq
        self.logger = logger
        self.save_freq = save_freq
        self.output_dir = output_dir

        # Gradient
        self.clip_grad = clip_grad
        self.max_grad_norm = max_grad_norm
        self.grad_accumulation_steps = grad_accumulation_steps

        # Loss function type, it should be a keyword
        assert loss in loss_dict, f"loss keyword should be one of: {loss_dict.keys()}, but got '{loss}'"
        self.loss = loss

        # A str keyword used for indicating what kind of metric we will compute
        assert metric_type in metric_func_dict, f"metric type keyword should be one of: {metric_func_dict.keys()}, but got '{metric_type}'"
        self.metric_type = metric_type
        # Metric identifier, like accuracy, f1, etc.
        if isinstance(metric_identifier, str):
            metric_identifier = [metric_identifier]
        assert is_seq_of(metric_identifier, str)
        self.metric_identifier = metric_identifier

        # Knowledge distillation
        self.kd = kd
        if kd:
            assert isinstance(teacher, nn.Module), f"teacher type must be 'nn.Module', but got{type(teacher)}"
            self.teacher = teacher
            self.teacher.eval()

            assert kd_cls_loss is not None and kd_reg_loss is not None, \
                "kd classfication loss & regression loss should not be None!"
            assert kd_cls_loss in loss_dict, kd_reg_loss in loss_dict
            # Loss keyword
            self.kd_cls_loss = kd_cls_loss
            self.kd_reg_loss = kd_reg_loss
            # The begining attention layer to be used in kd
            self.kd_begin_layer = kd_begin_layer

    def fit(
        self, data_container, metric_computor: Callable = None,
        pruner=None, rank=0, **kwargs
    ):
        """
        Training & Evalation.
        Note: sub-class can overwrite this method for self-defined behavior.

        Args:
            accelerator (Accelerator): Accelerator object provided by huggingface.
            data_container (DALIImgClsDataContainer): An object that define some behaviors about data processing(load, process, etc.).
                                               It should be a NLPDataContainer instance.
            metric_computor (Optional): Metric compute function(or a callable object). 
                                        Usually it will be an attribute of data_container. Default is None.
            pruner (Prune, Optional): An object that execute pruning. If it is None, pruning will not be executed. Default is None.
        """

        # Metric compute function
        if metric_computor is None:
            metric_computor = metric_func_dict[self.metric_type]

        # Dataloaders
        train_loader = data_container.dataloaders['train']
        val_loader = data_container.dataloaders['validation']

        # Total of training step
        total_train_steps = (self.end_epoch - self.start_epoch) * len(train_loader)
        # Only main process will show it on the screen
        progress_bar = tqdm(range(total_train_steps), disable=rank > 0)

        # Learning rate of each step
        all_step_lr = []
        # Loss & metric of every epoch
        eval_epoch_loss, eval_epoch_metric = [], []
        train_epoch_loss, train_epoch_metric = [], []

        best_metric = 0.

        # Sign
        self.logger.info('=> Start training!\n')
        with Timer(self.logger, job='Training'):
            # Train & eval loop
            for epoch in range(self.start_epoch, self.end_epoch):
                # Train
                train_loss, train_metric_dict, step_lr = self.train(
                    epoch, self.model,
                    train_loader, metric_computor, 
                    progress_bar, pruner=pruner, **kwargs
                )
                all_step_lr.extend(step_lr)
                train_epoch_loss.append(train_loss)
                train_epoch_metric.append(train_metric_dict)

                # Eval
                eval_loss, eval_metric_dict = self.eval(
                    epoch, self.model, 
                    val_loader, metric_computor, **kwargs
                )
                eval_epoch_loss.append(eval_loss)
                eval_epoch_metric.append(eval_metric_dict)

                cur_metric = eval_metric_dict.get(self.metric_identifier[0], 0.)
                is_best = cur_metric > best_metric
                best_metric = max(best_metric, cur_metric)
                if pruner is not None:
                    pruner.update_metrics(cur_metric)

                # Save state dict
                if self._time_to_save(self.rank, epoch, self.start_epoch, self.end_epoch, self.save_freq, is_best):
                    self.save_checkpoint(
                        self.output_dir, epoch, self.model_unwrapped,
                        self._unwrap_model(self.optimizer), self.lr_scheduler,
                        is_best=is_best, train_loss=train_loss, eval_loss=eval_loss,
                        train_metric_dict=train_metric_dict, eval_metric_dict=eval_metric_dict, **kwargs
                    )
                
                # When in kd mode, teacher will also do eval, cuz it will be the reference of student
                if self.kd:
                    self.eval(
                        epoch, self.teacher, 
                        val_loader, metric_computor, is_teacher=True, rank=rank, **kwargs
                    )
        # self.logger.info(f"Training finished! time used: {datetime.timedelta(seconds=time.time() - start)}\n")

        # Visulization
        self.draw_items(
            train_epoch_loss, eval_epoch_loss, 
            train_epoch_metric, eval_epoch_metric, 
            all_step_lr, len(train_loader)
        )

        return train_epoch_loss, train_epoch_metric, eval_epoch_loss, eval_epoch_metric, all_step_lr

    def train(
        self, epoch: int, model: nn.Module,
        dataloader: DataLoader, metric_computor: Callable,
        progress_bar, pruner=None, **kwargs
    ):
        """
        Training procedure.
        Note: sub-class can overwrite this method for self-defined behavior.
        """

        model.train()

        # Meters
        loss_meter = AverageMeter('loss', fmt=':.4f')
        metric_meters = [AverageMeter(metric_name, fmt=':.3f') for metric_name in self.metric_identifier]
        progress_meter = ProgressMeter(
            len(dataloader), [loss_meter] + metric_meters, 
            prefix=f"Train Epoch[{(epoch):0>3}/{self.end_epoch:0>3}]"
        )

        # Learning rate of each step
        step_lr = []
        # Epoch & Batch start time
        epoch_start = batch_start = time.time()

        # Train loop
        for step, batch in enumerate(dataloader):
            # Sometimes we may pre-process the data before feeding to model
            batch_for_model = self.process_batch(batch, **kwargs)
            # Forward
            if self.kd:
                outputs, teacher_outputs = self.kd_forward(batch_for_model)
            else:
                outputs = self.forward(batch_for_model)

            # Compute loss
            if self.kd:
                loss = self.compute_kd_loss(outputs, teacher_outputs, step, len(dataloader))
            else:
                loss_func = loss_dict[self.loss]
                loss_args = kwargs.get('loss_args', {})
                loss = loss_func(outputs, batch, **loss_args)
            # Scaled by gradient accumulation
            loss /= self.grad_accumulation_steps

            # Backward
            loss.backward()
            loss_meter.update(loss.item())

            # Gradient clip
            if self.clip_grad:
                grad_norm = clip_grad_norm_(model.parameters(), max_norm=self.max_grad_norm)
            else:
                grad_norm = get_grad_norm(model.parameters())

            lr = self.optimizer.param_groups[0]['lr']
            step_lr.append(lr)

            # Update
            if not (step + 1) % self.grad_accumulation_steps or step == len(dataloader) - 1:
                # Note: parameters & lr schedule will be carried by pruner if purning
                self.optimizer.step()
                self.optimizer.zero_grad()
                if pruner is None:
                    self.lr_scheduler.step()
                # Pruning
                else:
                    pruner.prune()
            
            # Post-process the raw model outputs to form the formatted predictions
            predictions = self.generate_predictions(outputs, batch=batch, **kwargs)
            # Compute metrics
            metric_dict = self.compute_metric(predictions, batch, metric_computor, **kwargs)
            # Reduces data across all machines
            if self.distributed:
                metric_dict = self._all_reduce(metric_dict, device=self.device)
            for metric_meter in metric_meters:
                metric_meter.update(metric_dict[metric_meter.name])

            # Log
            global_step = epoch * len(dataloader) + step
            if not global_step % self.log_freq or step == len(dataloader) - 1:
                batch_time = time.time() - batch_start
                memory_used = max_memory_allocated() / (1024. ** 2)

                # Formatted loss & metric string
                info = progress_meter.display(step, print_out=False)
                info += f"\tlr: {lr:.10f}\tgrad norm: {grad_norm:.6f}\t" \
                        f"batch time: {batch_time:.2f}s\tmemory used: {memory_used:.0f}MB\n"
                self.logger.info(info)
            
            # Reset batch start time
            batch_start = time.time()
            # Update progress bar after each step
            progress_bar.update()
            # This may release some memories
            del loss

        # Compute statistic
        epoch_time = time.time() - epoch_start
        epoch_loss = getattr(loss_meter, 'avg')
        epoch_metrics = {metric_meter.name: getattr(metric_meter, 'avg') for metric_meter in metric_meters}
        metric_info = ' '.join([f"{k}: {v:.3f}" for k, v in epoch_metrics.items()])
        # Epoch log
        self.logger.info(
            f"[Train] epoch: {epoch}/{self.end_epoch} "
            f"loss: {epoch_loss:.6f} {metric_info} time: {datetime.timedelta(seconds=epoch_time)}\n"
        )
        if pruner is not None:
            layer_sparse_rate, total_sparse_rate = pruner.sparsity()
            self.logger.info(f'weight sparsity: {total_sparse_rate}\n'
                             f'layer weight sparsity:\n{layer_sparse_rate}\n')

        # Release resources(but not available to Pytorch)
        torch.cuda.empty_cache()

        return epoch_loss, epoch_metrics, step_lr

    def eval(
        self, epoch: int, model: nn.Module,
        dataloader: DataLoader, metric_computor: Callable, 
        is_teacher=False, **kwargs
    ):
        """
        Evalation procedure.
        Note: sub-class can overwrite this method for self-defined behavior.
        """

        model.eval()

        # Meters
        loss_meter = AverageMeter('loss', fmt=':.4f')
        metric_meters = [AverageMeter(metric_name, fmt=':.3f') for metric_name in self.metric_identifier]
        progress_meter = ProgressMeter(
            len(dataloader), [loss_meter] + metric_meters, 
            prefix=f"Eval Epoch[{(epoch):0>3}/{self.end_epoch:0>3}]"
        )

        # Log prefix string(used for distinguishing teacher from student)
        prefix = '[Teacher]\t' if is_teacher else ''
        # Epoch & Batch start time
        epoch_start = batch_start = time.time()

        # Eval loop
        for step, batch in enumerate(dataloader):
            with torch.no_grad():
                # Sometimes we may pre-process the data before feeding to model
                batch_for_model = self.process_batch(batch, **kwargs)
                # Forward
                outputs = self.forward(batch_for_model)
                
                # Compute loss
                loss_func = loss_dict[self.loss]
                loss_args = kwargs.get('loss_args', {})
                loss = loss_func(outputs, batch, **loss_args)
                loss_meter.update(loss.item())

                # Post-process the raw model outputs to form the formatted predictions
                predictions = self.generate_predictions(outputs, batch=batch, **kwargs)
                # Compute metrics
                metric_dict = self.compute_metric(predictions, batch, metric_computor, **kwargs)
                # Reduces data across all machines
                if self.distributed:
                    metric_dict = self._all_reduce(metric_dict, device=self.device)
                for metric_meter in metric_meters:
                    metric_meter.update(metric_dict[metric_meter.name])

            # Log
            if not step % self.log_freq or step == len(dataloader) - 1:
                batch_time = time.time() - batch_start
                lr = self.optimizer.param_groups[0]['lr']
                memory_used = max_memory_allocated() / (1024. ** 2)

                # Formatted loss & metric string
                info = progress_meter.display(step, print_out=False)
                info += f"\tlr: {lr:.10f}\tbatch time: {batch_time:.2f}s\tmemory used: {memory_used:.0f}MB\n"
                self.logger.info(prefix + info)
            
            # Reset batch start time
            batch_start = time.time()
            # This may release some memories
            del loss

        # Release resources(but not available to Pytorch)
        torch.cuda.empty_cache()

        # Compute epoch statistic
        epoch_time = time.time() - epoch_start
        epoch_loss = getattr(loss_meter, 'avg')
        epoch_metrics = {metric_meter.name: getattr(metric_meter, 'avg') for metric_meter in metric_meters}
        metric_info = ' '.join([f"{k}: {v:.3f}" for k, v in epoch_metrics.items()])
        # Epoch log
        self.logger.info(
            f"{prefix}[Eval] epoch: {epoch}/{self.end_epoch} "
            f"loss: {epoch_loss:.6f} {metric_info} time: {datetime.timedelta(seconds=epoch_time)}\n"
        )

        return epoch_loss, epoch_metrics

    def process_batch(self, batch: Sequence, **kwargs):
        """
        Pre-process batched data before feeding to model.
        """
        
        # Tensor
        if isinstance(batch, torch.Tensor):
            batch = [batch.to(self.device)]
        # List, Tuple
        elif isinstance(batch, (List, Tuple)):
            batch = type(batch)(data.to(self.device) for data in batch)
        # Other cases
        else:
            pass

        return batch

    def generate_predictions(self, outputs: torch.Tensor, batch=None, **kwargs):
        """
        Post-process the raw model outputs to generate formatted predictions, used for computing metrics.
        Note: sub-class must implement this method.
        """
        return outputs
    
    def compute_metric(self, predictions: torch.Tensor, batch, metric_computor: Callable, **kwargs):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """

        topk = kwargs.get('topk', (1,))
        targets = batch[1].to(predictions.device)
        metric_dict = metric_computor(predictions, targets, topk=topk)

        return metric_dict
    
    def forward(self, batch_for_model, model=None):
        """
        A wrapper function of model forwarding progress.
        """

        # Assuming that index 0 for images, and index 1 for targets
        images = batch_for_model[0]
        assert images.device == self.device, "Device of images should be the same as self"

        if model is None:
            model = self.model
        return model(images)

    def kd_forward(self, batch_for_model):
        """
        Model Forward progress when in knowledge distillation mode.
        Note: sub-class can implement this method for self-defined behavior.
        """

        outputs = self.forward(batch_for_model)

        # Double check whether the teacher is in eval mode
        if self.teacher.training:
            self.teacher.eval()
        # The forward progress of teacher no need gradient
        # This will save some memories
        with torch.no_grad():
            teacher_outputs = self.forward(batch_for_model, model=self.teacher)

        return outputs, teacher_outputs

    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, *args, **kwargs):
        """
        Compute loss when in knowledge distillation mode.
        Note: sub-class must implement this method.
        """
        raise NotImplementedError("This method should be implemented by sub-class.")
    
    @staticmethod
    def _time_to_save(rank, cur, start, end, save_freq, is_best) -> bool:
        return not rank and (not (cur - start + 1) % save_freq or cur == end - 1 or is_best)

    def save_checkpoint(
        self, output_dir, cur, model, optimizer, lr_scheduler, is_best=False,
        train_loss=None, eval_loss=None, train_metric_dict=None, eval_metric_dict=None, output_file=None,
        **kwargs
    ):
        """
        Save state dict.
        """

        if output_file is None:
            avg_tag = f'-avg{(sum(eval_metric_dict[metric_name] for metric_name in self.metric_identifier) / len(self.metric_identifier)):.3f}-' \
                    if len(eval_metric_dict) > 1 else '-'
            metric_tag = '-'.join( 
                [f"{metric_name}{eval_metric_dict[metric_name]:.3f}" 
                for metric_name in self.metric_identifier]
            )
            lr_tag = f'-lr{optimizer.param_groups[0]["lr"]}'
            bs = kwargs.get("train_batch_size", 0)
            bs_tag = f'-bs{bs}' if bs else '-'
            output_file = f'ep{cur}{bs_tag}{lr_tag}{avg_tag}{metric_tag}.pth'
        output_path = os.path.join(output_dir, output_file)

        state_dict = {
            'epoch': cur,
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'lr_scheduler': lr_scheduler.state_dict(),
            'loss': {'train': train_loss, 'eval': eval_loss},
            'metric': {'train': train_metric_dict, 'eval': eval_metric_dict}
        }
        if is_best:
            # Delete history
            for prev in glob.glob(os.path.join(output_dir, '*.pth')):
                os.remove(prev)
        torch.save(state_dict, output_path)

        self.logger.info(f"\n{'best ' if is_best else ''}checkpoint of epoch{cur} has been saved({output_path}).\n")

    @classmethod
    def _unwrap_model(cls, model: nn.Module):
        """
        Extract a model from its distributed containers.

        Args:
            model (:obj:`torch.nn.Module`): The model to extract.

        Returns:
            :obj:`torch.nn.Module`: The extracted model.
        """

        while isinstance(model, cls.DIST_CONTAINERS):
            model = model.module

        return model

    @staticmethod
    def _all_reduce(metric_dict: dict, op=ReduceOp.SUM, group=None, async_op=False, device=None):
        """
        Reduces the tensor data across all machines in such a way that all get
        the final result.

        After the call ``tensor`` is going to be bitwise identical in all processes.

        Complex tensors are supported.

        Args:
            metric_dict (Dict[str: tensor]): A dict containing some tensors that will be reduced.
            op (optional): One of the values from
                           ``torch.distributed.ReduceOp``
                           enum. Specifies an operation used for element-wise reductions.
            group (ProcessGroup, optional): The process group to work on. If None,
                                            the default process group will be used.
            async_op (bool, optional): Whether this op should be an async op.

        Returns:
            A dict containing reduced tensors
        """

        metric_dict = {k: torch.tensor(v, device=device) for k, v in metric_dict.items()}
        return all_reduce(metric_dict, op=op, group=group, async_op=async_op)

    def draw_items(
        self, train_epoch_loss: Sequence, eval_epoch_loss: Sequence = None, 
        train_epoch_metric: dict = None, eval_epoch_metric: dict = None, 
        all_step_lr: Sequence = None, step_per_epoch: int = -1
    ):
        """
        Plotting function.
        Curves containing loss, metrics & lr items.
        """

        epoch_range = range(self.start_epoch + 1, self.end_epoch + 1)
        plot_line(epoch_range, train_epoch_loss, x_val=epoch_range, y_val=eval_epoch_loss,
                  out_dir=self.output_dir, name='loss')
        
        if not (train_epoch_metric is None or eval_epoch_metric is None):
            for metric_name in self.metric_identifier:
                train_metric_value = [metric_dict[metric_name] for metric_dict in train_epoch_metric if metric_name in metric_dict]
                eval_metric_value = [metric_dict[metric_name] for metric_dict in eval_epoch_metric if metric_name in metric_dict]
                
                if not train_metric_value:
                    train_metric_value = None
                if not eval_metric_value:
                    eval_metric_value = None

                plot_line(epoch_range, train_metric_value, x_val=epoch_range, y_val=eval_metric_value, 
                          item=metric_name, out_dir=self.output_dir, name=metric_name)
        
        if not (all_step_lr is None or step_per_epoch == -1):
            start_step = self.start_epoch * step_per_epoch + 1
            end_step = start_step + (self.end_epoch - self.start_epoch) * step_per_epoch
            step_range = range(start_step, end_step)

            plot_line(step_range, all_step_lr, out_dir=self.output_dir, item='lr', name='lr')


@TRAINER.register_module(name='image_classification_with_hook')
class ImgClsHookTrainer(BaseTrainer):
    """
    A tranier for image classification task, integrate with hook mechanism.
    Trainer encapsulates all of operations for network training, e.g. gets batched data, model forwarding,
    computes loss, optimizes parameters, updates lr, saves checkpoints, etc.
    """

    def __init__(
        self,
        model: nn.Module,
        optimizer: Optimizer,
        lr_scheduler: _LRScheduler,
        logger: Logger, output_dir: str,
        epochs: int, start_epoch: int = 0,
        log_freq: int = 10, save_freq: Union[int, List[int]] = 10, save_type: str = 'frequency',
        save_latest: bool = True, ckpt_savers: Tuple[Dict] = (dict(type='torch'),),
        grad_accumulation_steps: int = 1, clip_grad: bool = False, max_grad_norm: float = 1., 
        loss: str = 'ce', metric_type: str = 'accuracy', metric_identifier: Sequence[str] = ('top1-accuracy',),
        kd: bool = False, kd_begin_layer: int = 0,  kd_cls_loss: str = None, kd_reg_loss: str = None,
        teacher: nn.Module = None, teacher_eval: bool = True, do_train: bool = True, do_eval: bool = True, do_test: bool = False,
        rank=0,draw_results: bool = True, **kwargs
    ):
        """
        Args:
            model (nn.Module): Pytorch neural network module.
            optimizer (Optimizer): Optimize model parameters according to the specified rule.
            lr_scheduler (_LRScheduler): Scheduling learning rate while training.
            logger (BaseLogger): Object that log information and format it.
            epochs (int): Number of training epochs.
            start_epoch (int): The starting training epoch. Default: 0.
            log_freq (int): Logging frequency. Default: 1.
            save_freq (int): Frequency that related to saving checkpoint. Default: 1
            output_dir (str): Directory that store the output results. Default is None.
            grad_accumulation_steps (int): Number of gradient accumulation steps. Default: 1
            clip_grad (bool): Whether to clip gradient during training. Default is False.
            max_grad_norm (float): The max value of gradient norm. Default 1.0.
            loss (str): loss type. Default is None.
            metric_identifier (List[str], str): Metric identifier, such as 'accuracy', 'bleu', etc. Default: 'accuracy'.
            kd (bool): Whether to turn on knowledge distillation. Default is False.
            teacher (nn.Module): The teacher model when kd is set to True. Default is None.
            kd_cls_loss (str): Kd classification loss type. Default is None.
            kd_reg_loss (str): Kd regression loss type. Default is None.
            kd_begin_layer (int): Default: 0.
            rank (int): Local process rank, Default: 0
        """

        super().__init__(
            model, logger, output_dir,
            log_freq=log_freq, save_freq=save_freq, 
            save_latest=save_latest, ckpt_savers=ckpt_savers
        )

        # Optimization
        self.optimizer = optimizer
        self.lr_scheduler = lr_scheduler

        # Whether to do train, eval, test
        self.do_train = do_train
        self.do_eval = do_eval
        self.do_test = do_test

        # Training Time
        self.start_epoch = start_epoch
        self.end_epoch = epochs

        # For quantization
        self.quant_cfg = kwargs.pop('quant_cfg', {'enable': False, 'qr_loss_weight': 0.1})

        # Note: remember to register the 'StepBasedCheckpointHook'
        if save_type == 'prune_step_based':
            pruner = kwargs.pop('pruner', None)
            if pruner is None:
                raise ValueError(f"pruner must be specified when 'save_type' == 'prune_step_based'.")
            # Only save checkpoint when pruning is done at each stage.
            self.save_freq = [prune_steps_per_stage[1] for prune_steps_per_stage in pruner.stage_wise_steps]

        # Gradient
        self.clip_grad = clip_grad
        self.max_grad_norm = max_grad_norm
        self.grad_accumulation_steps = grad_accumulation_steps

        # Loss
        assert loss in loss_dict, f"loss keyword should be one of: {loss_dict.keys()}, but got '{loss}'"
        self.loss = loss

        # Metric
        assert metric_type in metric_func_dict, f"metric type keyword should be one of: {metric_func_dict.keys()}, but got '{metric_type}'"
        self.metric_type = metric_type
        # Metric identifier, like accuracy, f1, etc.
        if isinstance(metric_identifier, str):
            metric_identifier = [metric_identifier]
        assert is_seq_of(metric_identifier, str)
        self.metric_identifier = metric_identifier

        # Knowledge Distillation
        self.kd = kd
        if kd:
            assert isinstance(teacher, nn.Module), f"teacher type must be 'nn.Module', but got{type(teacher)}"
            self.teacher = teacher
            # Note: remember to set the teacher to 'eval' mode
            self.teacher.eval()
            # Whether to let teacher evaluate on eval dataset
            self.teacher_eval = teacher_eval

            if kd_cls_loss is not None:
                # Loss keyword
                assert kd_cls_loss in loss_dict, f"kd_cls_loss should be one of: {loss_dict.keys()}"
                self.kd_cls_loss = kd_cls_loss
            if kd_reg_loss is not None:
                # Loss keyword
                assert kd_reg_loss in loss_dict, f"kd_reg_loss should be one of: {loss_dict.keys()}"
                self.kd_reg_loss = kd_reg_loss

            # The begining layer that kd effects
            self.kd_begin_layer = kd_begin_layer
        
        # Local rank
        self.rank = rank

        self.draw_results = draw_results
    
    def process_batch(self, batch):
        """
        Pre-process batched data(usually including images & targets) before feeding to model.
        """
        
        # Tensor
        if isinstance(batch, torch.Tensor):
            batch = [batch.to(self.device)]
        # List, Tuple
        elif isinstance(batch, (List, Tuple)):
            batch = type(batch)(data.to(self.device) for data in batch)
        # Other cases
        else:
            pass

        return batch
    
    def forward(self, batch_for_model, model=None):
        """
        A wrapper function of model forwarding progress.
        """

        # Assuming that index 0 for images, and index 1 for targets
        images = batch_for_model[0]
        assert images.ndim == 4, f"images tensor should have 4 dims, but got: {images.size()}"
        assert images.device == self.device, "Device of images should be the same as self"

        if model is None:
            model = self.model
        return model(images)

    def kd_forward(self, batch_for_model, teacher=None, model=None):
        """
        Model Forward progress when in knowledge distillation mode.
        Note: sub-class can implement this method for self-defined behavior.
        """

        if model is None:
            model = self.model
        outputs = self.forward(batch_for_model, model=model)

        # Double check whether the teacher is in eval mode
        if teacher is None:
            teacher = self.teacher
        if teacher.training:
            teacher.eval()
        # The forward progress of teacher no need gradient
        # This will save some memories
        with torch.no_grad():
            teacher_outputs = self.forward(batch_for_model, model=teacher)

        return outputs, teacher_outputs

    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, batch: torch.Tensor,*args, **kwargs):
        """
        Compute loss when in knowledge distillation mode.
        Note: sub-class must implement this method.
        """
        # kd logit loss (soft ce)
        cls_loss_func = loss_dict[self.kd_cls_loss]
        if self.kd_cls_loss=='dkd':
            self.logits_loss = cls_loss_func(outputs, teacher_outputs,batch[1])
        else:
            self.logits_loss = cls_loss_func(outputs,teacher_outputs)

        # cls loss 
        # loss_func = loss_dict[self.loss]
        # loss_args = getattr(kwargs, 'loss_args', {})
        # loss = loss_func(outputs,batch, **loss_args)
        # loss = loss + self.logits_loss
        return self.logits_loss

    def run_iter(self, batch, mode='train'):
        # Sometimes we may pre-process the data before feeding to model
        self.batch_for_model = self.process_batch(batch)

        # Forward
        if mode == 'train' and self.kd:
            self.outputs, self.teacher_outputs = self.kd_forward(self.batch_for_model)
        else:
            if getattr(self, 'is_teacher', False):
                model = self.teacher
            else:
                model = self.model

            self.outputs = self.forward(self.batch_for_model, model=model)
    
    def train(
        self, epoch: int, model: nn.Module,
        dataloader: DataLoader, metric_computor: Callable,
        progress_bar, pruner=None, **kwargs
    ):
        """
        Training procedure.
        Note: sub-class can overwrite this method for self-defined behavior.
        """

        model.train()

        self._mode = 'train'
        self.epoch = epoch

        self.model = model
        self.pruner = pruner

        self.dataloader = dataloader
        # Note: some dataloader may not have 'batch_size' attribute
        self.batch_size = dataloader.batch_size or getattr(self, 'train_batch_size', None)

        self.progress_bar = progress_bar
        self.metric_computor = metric_computor

        # MetaHook, TimerHook will be trigerred in order
        self.call_hooks('before_train_epoch')
        # Train loop
        for step, batch in enumerate(dataloader):
            self.step = step
            self.global_step = epoch * len(dataloader) + step
            self.batch = batch
            self.metric_topk = kwargs.get('topk', (1,))
            self.loss_args = kwargs.get('loss_args', {})

            # TimerHook will be trigerred
            self.call_hooks('before_train_iter')
            self.run_iter(batch)
            # OptimizerHook, LrSchedulerHook, PrunerHook, MetaHook,
            # TimerHook, MemoryHook, LoggerHook, VisualHook will be trigerred in order
            self.call_hooks('after_train_iter')

            del self.loss_value

            del self.batch
            del self.batch_for_model

            del self.outputs
            if self.kd and hasattr(self, 'teacher_outputs'):
                del self.teacher_outputs

        # PrunerHook, MetaHook, TimerHook, MemoryHook, LoggerHook will be triggered in order
        self.call_hooks('after_train_epoch')

    @torch.no_grad()
    def eval(
        self, epoch: int, model: nn.Module,
        dataloader: DataLoader, metric_computor: Callable, 
        is_teacher=False,sparse=False, **kwargs
    ):
        """
        Evalation procedure.
        Note: sub-class can overwrite this method for self-defined behavior.
        """

        model.eval()

        self._mode = 'eval'
        self.epoch = epoch

        # self.model = model
        self.is_teacher = is_teacher

        self.dataloader = dataloader
        # Note: some dataloader may not have 'batch_size' attribute
        self.batch_size = dataloader.batch_size or getattr(self, 'val_batch_size', None)

        self.metric_computor = metric_computor

        # MetaHook, TimerHook, LoggerHook will be triggered in order
        if sparse:
            self.call_hooks('before_sparse_eval_epoch')
        self.call_hooks('before_eval_epoch')
        # Eval loop
        for step, batch in enumerate(dataloader):
            self.step = step
            self.batch = batch
            self.metric_topk = kwargs.get('topk', (1,))
            
            # TimerHook will be triggered
            self.call_hooks('before_eval_iter')

            self.run_iter(batch, mode='eval')
            # Compute loss
            loss_func = loss_dict[self.loss]
            loss_args = kwargs.get('loss_args', {})
            loss = loss_func(self.outputs, batch, **loss_args)
            self.loss_value = loss.item()

            self.call_hooks('after_eval_iter')

            # This may release some memories
            del loss
            del self.loss_value

            del self.batch
            del self.batch_for_model

            del self.outputs

        # PrunerHook, MetaHook, TimerHook, MemoryHook, LoggerHook will be triggered in order
        if sparse:
            self.call_hooks('after_sparse_eval_epoch')
        self.call_hooks('after_eval_epoch')

    def run(self, data_container, metric_computor: Callable = None, pruner=None, **kwargs):
        """
        Training & Evalation.
        Note: sub-class can overwrite this method for self-defined behavior.

        Args:
            accelerator (Accelerator): Accelerator object provided by huggingface.
            data_container (DALIImgClsDataContainer): An object that define some behaviors about data processing(load, process, etc.).
                                               It should be a NLPDataContainer instance.
            metric_computor (Optional): Metric compute function(or a callable object). 
                                        Usually it will be an attribute of data_container. Default is None.
            pruner (Prune, Optional): An object that execute pruning. If it is None, pruning will not be executed. Default is None.
        """

        # Metric compute function
        if metric_computor is None:
            metric_computor = metric_func_dict[self.metric_type]
        
        self.pruner = pruner
        
        # Dataloaders
        train_loader = data_container.dataloaders['train']
        val_loader = data_container.dataloaders['validation']

        # Batch size
        # Note: we don't use x_loader.batch_size cuz some wrapped dataloaders may not have this attribute.
        self.train_batch_size = data_container.train_batch_size
        self.val_batch_size = data_container.val_batch_size

        # Total of training step
        self.total_train_steps = (self.end_epoch - self.start_epoch) * len(train_loader)
        # Only main process will show it on the screen
        progress_bar = tqdm(range(self.total_train_steps), disable=self.rank > 0)

        # MetaHook, TimerHook will be triggered
        self.call_hooks('before_run')

        # Train & eval loop
        for epoch in range(self.start_epoch, self.end_epoch):
            if self.do_train:
                # Train
                self.train(
                    epoch, self.model,
                    train_loader, metric_computor, 
                    progress_bar, pruner=pruner, **kwargs
                )
            if self.do_eval:
                # Eval
                self.eval(
                    epoch, self.model, 
                    val_loader, metric_computor, **kwargs
                )
                # Sparse Eval
                if pruner and pruner.TYPE=='bbcs':
                    self.eval(
                        epoch, self.model, 
                        val_loader, metric_computor,sparse=True, **kwargs
                    )
            if self.kd and self.teacher_eval and epoch==self.start_epoch:
                # When in kd mode, let teacher do eval, this can be the reference for student
                self.eval(
                    epoch, self.teacher, val_loader, metric_computor,
                    is_teacher=True, rank=self.rank, **kwargs
                )

        # LoggerHook, VisualHook will be triggered
        self.call_hooks('after_run')

        del self.train_batch_size, self.val_batch_size, self.total_train_steps

    def fit(self, data_container, metric_computor: Callable = None, pruner=None, **kwargs):
        self.logger.warning("\ntrainer.fit() was deprecated, please use trainer.run() instead.\n")
        self.run(data_container, metric_computor=metric_computor, pruner=pruner, **kwargs)

    @property
    def mode(self):
        return self._mode
