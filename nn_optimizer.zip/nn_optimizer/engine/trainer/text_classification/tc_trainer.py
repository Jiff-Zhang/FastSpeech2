import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from tqdm import tqdm
from logging import Logger
from typing import Callable, Mapping

from accelerate import Accelerator

from torch.optim import Optimizer
from torch.optim.lr_scheduler import _LRScheduler
from torch.utils.data.dataloader import DataLoader

from engine.loss import loss_dict
from engine.trainer import NLPTrainer, NLPHookTrainer, TRAINER

from data.nlp import NLPDataContainer


@TRAINER.register_module(name='text_classification_with_hook')
class TextClsHookTrainer(NLPHookTrainer):
    """
    Trainer for text classification task, integrate with hook mechanism.
    """
    
    REMOVE_COLUMNS = ["id"]

    def _process_batch(self, batch):
        """
        Prepares batched data before feeding it to the model, be it a tensor or a nested list/dictionary of tensors.
        """

        if isinstance(batch, Mapping):
            return type(batch)({k: self._process_batch(v) for k, v in batch.items()})
        elif isinstance(batch, (list, tuple)):
            return type(batch)(self._process_batch(v) for v in batch)
        elif isinstance(batch, torch.Tensor):
            kwargs = dict(device=self.device)
            if self.deepspeed and batch.dtype != torch.int64:
                # NLP models inputs are int64 and those get adjusted to the right dtype of the
                # embedding. Other models such as wav2vec2's inputs are already float and thus
                # may need special handling to match the dtypes of the model
                if self.deepspeed._config.fp16_enabled:
                    dtype = torch.float16
                elif self.deepspeed._config.bfloat16_enabled:
                    dtype = torch.bfloat16
                else:
                    dtype = torch.float32
                kwargs.update(dict(dtype=dtype))
            return batch.to(**kwargs)
        else:
            return batch

    def process_batch(self, batch):
        # This model inputs will be set to attr: trainer().batch_for_model
        model_inputs = {k: v for k, v in batch.items() if k not in self.REMOVE_COLUMNS}
        # Pop label when predicting in case of exception occured with loss computation
        if not (self.do_train or self.do_eval):
            model_inputs.pop('labels', -1)

        return self._process_batch(model_inputs)

    def run(
        self, data_container: NLPDataContainer,
        metric_computor: Callable = None, pruner=None, accelerator: Accelerator = None, **kwargs
    ):
        # e.g. rte, mrpc, etc.
        self.task_name = getattr(data_container, 'task_name', kwargs.get('task_name'))
        self.is_regression = getattr(data_container, 'is_regression', kwargs.get('is_regression', False))
        # if not self.is_regression:
        #     self.label_list = data_container.label_list

        super().run(data_container, metric_computor=metric_computor, pruner=pruner, accelerator=accelerator, **kwargs)
    
        # Final evaluate/test on mnli mismatched dataset
        if self.task_name and self.task_name.lower() == "mnli":
            '''VALIDATION-MISMATCHED'''
            if self.do_eval:
                eval_dataloader = data_container.dataloaders["validation_mismatched"]
                # Progress bar
                bar_range = range(len(eval_dataloader))
                # Only main process will show it on the screen
                progress_bar = tqdm(bar_range, disable=self.rank)

                # self.logger.info(f"\nEvaluating on VALIDATION-MISMATCHED set(select {eval_size} samples)..")
                self.logger.info(f"\nEvaluating on VALIDATION-MISMATCHED set..")
                self.eval(
                    self.end_epoch, self.model, eval_dataloader,
                    data_container.metric_computor, accelerator=accelerator, progress_bar=progress_bar, **kwargs
                )
                self.logger.info("\nEvaluation on 'VALIDATION-MISMATCHED' set DONE!")

            '''TEST-MISMATCHED'''
            if self.do_test:
                test_dataset = data_container.data["test_mismatched"]
                test_dataloader = data_container.dataloaders["test_mismatched"]
                
                # Progress bar
                bar_range = range(len(test_dataloader))
                # Only main process will show it on the screen
                progress_bar = tqdm(bar_range, disable=self.rank)

                self.logger.info(f"\nPredicting on TEST-MISMATCHED set..")
                self.test(
                    self.model, test_dataset, test_dataloader,
                    accelerator=accelerator, progress_bar=progress_bar, **kwargs
                )
                self.logger.info("\nPrediction on 'TEST-MISMATCHED' set DONE!")
    
    @torch.no_grad()
    def test(
        self, model: nn.Module, data_samples, dataloader: DataLoader,
        accelerator: Accelerator = None, progress_bar=None, **kwargs
    ):
        if kwargs.get('task_name'):
            self.task_name = kwargs.pop('task_name')

        super().test(model, data_samples, dataloader, accelerator, progress_bar, **kwargs)

    def kd_forward(self, batch: dict, model=None, teacher=None):
        """
        Forwarding progress w knowledge distillation.
        """

        if model is None:
            model = self.model if self.deepspeed is None else self.deepspeed
        outputs = model(**batch, output_attentions=True, output_hidden_states=True)

        if teacher is None:
            teacher = self.teacher
        # Double check whether the teacher is in eval mode
        if teacher.training:
            teacher.eval()
        with torch.no_grad():
            teacher_outputs = teacher(**batch, output_attentions=True, output_hidden_states=True)
            
        return outputs, teacher_outputs

    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, processed_batch, *args, **kwargs):
        """
        Compute loss when in knowledge distillation mode.
        """

        logit_loss_func = loss_dict[self.kd_cfg['logit_loss']]
        hs_loss_func = loss_dict[self.kd_cfg['hs_loss']]
        attn_loss_func = loss_dict[self.kd_cfg['attn_loss']]

        hidden_states, attns, logits = outputs.hidden_states, \
            outputs.attentions, outputs.logits
        teacher_hidden_states, teacher_attns, teacher_logits = teacher_outputs.hidden_states, \
            teacher_outputs.attentions, teacher_outputs.logits

        # Logits loss(ce)
        if self.kd_cfg['add_gt_loss']:
            kd_warmup_steps = len(self.dataloader) * (self.end_epoch - self.start_epoch) // 10
            self.logits_loss = F.cross_entropy(logits, processed_batch['labels']) + \
                min((self.global_step + 1) / kd_warmup_steps, 1.) * logit_loss_func(logits, teacher_logits, labels=processed_batch['labels'], **kwargs)
        else:
            self.logits_loss = logit_loss_func(logits, teacher_logits, labels=processed_batch['labels'], **kwargs)

        begin_layer = self.kd_cfg.get('layer_begin', 0)
        end_layer = self.kd_cfg.get('layer_end', -1)
        if end_layer == -1:
            end_layer = len(hidden_states)

        # Hidden states loss(mse)
        self.hs_loss = 0.
        for layer_hidden_state, teacher_layer_hidden_state in \
            zip(hidden_states[begin_layer:end_layer], teacher_hidden_states[begin_layer:end_layer]):
            # Normalize hidden states, usually for pre-norm model
            if self.kd_cfg['norm_hs']:
                eps = 1e-6

                hs_var = layer_hidden_state.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)
                teacher_hs_var = teacher_layer_hidden_state.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)

                layer_hidden_state = layer_hidden_state * torch.rsqrt(hs_var + eps)
                teacher_layer_hidden_state = teacher_layer_hidden_state * torch.rsqrt(teacher_hs_var + eps)

            if self.kd_cfg['hs_loss'] == 'soft_ce':
                d = layer_hidden_state.size(-1)
                
                hs_corr = torch.matmul(
                    layer_hidden_state,
                    layer_hidden_state.transpose(-1, -2)
                ) / math.sqrt(d)
                teacher_hs_corr = torch.matmul(
                    teacher_layer_hidden_state,
                    teacher_layer_hidden_state.transpose(-1, -2)
                ) / math.sqrt(d)

                self.hs_loss = self.hs_loss + \
                    hs_loss_func(F.softmax(hs_corr, dim=-1), F.softmax(teacher_hs_corr, dim=-1), **kwargs)
            elif self.kd_cfg['hs_loss'] == 'mse':
                self.hs_loss = self.hs_loss + hs_loss_func(layer_hidden_state, teacher_layer_hidden_state, **kwargs)
            else:
                raise NotImplementedError(f"Not supported hidden state loss: {self.kd_cfg['hs_loss']}.")

        # Attentions loss(mse)
        self.attn_loss = 0.
        for layer_attn, teacher_layer_attn in \
            zip(attns[begin_layer:end_layer], teacher_attns[begin_layer:end_layer]):
            self.attn_loss = self.attn_loss + attn_loss_func(layer_attn, teacher_layer_attn, **kwargs)

        kd_loss = self.kd_cfg['logit_weight'] * self.logits_loss + \
            self.kd_cfg['hs_weight'] * self.hs_loss + self.kd_cfg['attn_weight'] * self.attn_loss

        return kd_loss


@TRAINER.register_module(name='text_classification')
class TCTrainer(NLPTrainer):
    """
    Trainer for text classification task.
    """
    
    def __init__(
        self, model: nn.Module, optimizer: Optimizer, lr_scheduler: _LRScheduler, logger: Logger,
        epochs: int, start_epoch: int = 0, log_freq: int = 1, save_freq: int = 1, 
        output_dir: str = None, grad_accumulation_steps: int = 1, clip_grad: bool = False, max_grad_norm: float = 1., 
        loss: str = None, metric_identifier='accuracy',
        kd: bool = False, teacher: nn.Module = None,
        kd_cls_loss: str = None, kd_reg_loss: str = None, kd_begin_layer: int = 0
    ):
        super().__init__(
            model, optimizer, lr_scheduler, logger, 
            epochs, start_epoch=start_epoch, log_freq=log_freq, save_freq=save_freq,
            output_dir=output_dir, grad_accumulation_steps=grad_accumulation_steps,
            clip_grad=clip_grad, max_grad_norm=max_grad_norm, loss=loss, metric_identifier=metric_identifier,
            kd=kd, teacher=teacher, kd_cls_loss=kd_cls_loss, kd_reg_loss=kd_reg_loss, kd_begin_layer=kd_begin_layer
        )
    
    def fit(
        self, accelerator: Accelerator, data_container: NLPDataContainer, 
        metric_computor: Callable = None, pruner=None, **kwargs
    ):
        super().fit(accelerator, data_container, metric_computor=metric_computor, pruner=pruner, **kwargs)
        
        # Final evaluation on mismatched validation set
        if data_container.task_name.lower() == "mnli":
            eval_size = data_container.val_batch_size * accelerator.num_processes * 10
            eval_dataset = data_container.features["validation_mismatched"].select(range(eval_size))
            eval_dataloader = data_container._get_dataloader(
                eval_dataset, data_container.val_batch_size, train=False, 
                num_workers=data_container.num_workers, pin_memory=data_container.pin_memory,
                debug=data_container.debug, seed=data_container.seed, rank=data_container.rank,
                pad_to_max_seq_length=data_container.pad_to_max_seq_length, use_fp16=accelerator.use_fp16
            )
            eval_dataloader = accelerator.prepare(eval_dataloader)
            
            self.logger.info(f"\nEvaluating on MNLI-MISMATCHED validation set({eval_size} samples)")
            self.eval(
                self.end_epoch, self.model, accelerator, eval_dataloader,
                data_container.metric_computor, is_regression=data_container.is_regression
            )
    
    def generate_predictions(self, outputs: torch.Tensor, data=None, is_regression: bool = False, **kwargs):
        return outputs.logits.argmax(dim=-1) if not is_regression else outputs.logits.squeeze()
    
    def kd_forward(self, batch: dict):
        """
        Forwarding progress w knowledge distillation.
        """

        # Double check whether the teacher is in eval mode
        if self.teacher.training:
            self.teacher.eval()

        outputs = self.model(**batch, output_attentions=True, output_hidden_states=True)
        with torch.no_grad():
            teacher_outputs = self.teacher(**batch, output_attentions=True, output_hidden_states=True)
            
        return outputs, teacher_outputs
    
    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, step, step_per_epoch):
        """
        Compute loss when in knowledge distillation mode.
        """

        cls_loss_func = loss_dict[self.kd_cls_loss]
        reg_loss_func = loss_dict[self.kd_reg_loss]

        hidden_states, attns, logits = outputs.hidden_states, \
            outputs.attentions, outputs.logits
        teacher_hidden_states, teacher_attns, teacher_logits = teacher_outputs.hidden_states, \
            teacher_outputs.attentions, teacher_outputs.logits

        # Logits loss(ce)
        logit_loss = cls_loss_func(logits, teacher_logits)

        # Hidden states loss(mse)
        hs_loss = 0.
        for layer_hidden_state, teacher_layer_hidden_state in \
            zip(hidden_states[self.kd_begin_layer:], teacher_hidden_states[self.kd_begin_layer:]):
            hs_loss = hs_loss + reg_loss_func(layer_hidden_state, teacher_layer_hidden_state)

        # Attentions loss(mse)
        attn_loss = 0.
        for layer_attn, teacher_layer_attn in \
            zip(attns[self.kd_begin_layer:], teacher_attns[self.kd_begin_layer:]):
            attn_loss = attn_loss + reg_loss_func(layer_attn, teacher_layer_attn)
        
        global_step = self.start_epoch * step_per_epoch + step
        if not global_step % self.log_freq or step == step_per_epoch - 1:
            self.logger.info(
                f"\nkd logit loss: {logit_loss.item():.8f}\t"
                f"kd hidden states loss: {hs_loss.item():.8f}\t"
                f"kd attentions loss: {attn_loss.item():.8f}\n"
            )

        kd_loss = logit_loss + hs_loss + attn_loss
        del logit_loss, hs_loss, attn_loss

        return kd_loss

    def save_checkpoint(
        self, output_dir, cur, start, end, freq, model, optimizer, lr_scheduler,
        train_loss, eval_loss, train_metric_dict, eval_metric_dict,
        pruner=None, **kwargs
    ):
        """
        Save state dict.
        Note: When pruning, we only save checkpoints in fine-tuning stage.
        """

        avg_tag = f'-avg{(sum(eval_metric_dict[metric_name] for metric_name in self.metric_identifier) / len(self.metric_identifier)):.3f}-' \
                if len(eval_metric_dict) > 1 else '-'
        metric_tag = '-'.join( 
            [f"{metric_name}{eval_metric_dict[metric_name]:.3f}" 
            for metric_name in self.metric_identifier]
        )
        output_file = f'epoch{cur}{avg_tag}{metric_tag}.pth'

        NLPTrainer.save_checkpoint(
            output_dir, cur, start, end, freq,
            model, optimizer, lr_scheduler,
            train_loss=train_loss, eval_loss=eval_loss,
            train_metric_dict=train_metric_dict, eval_metric_dict=eval_metric_dict,
            output_file=output_file, pruner=pruner, **kwargs
        )
