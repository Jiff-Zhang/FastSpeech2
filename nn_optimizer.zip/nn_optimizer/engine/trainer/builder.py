from utils.registry import Registry


TRAINER = Registry('trainer')


def build_trainer(cfg, default_args: dict = None):
    return TRAINER.build(cfg, default_args=default_args)
