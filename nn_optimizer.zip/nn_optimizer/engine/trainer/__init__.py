from torch import import_ir_module_from_buffer
from .builder import build_trainer, TRAINER

# Base
from .base_trainer import BaseTrainer

# NLP
from .nlp_trainer import NLPTrainer, NLPHookTrainer
from .question_answering.qa_trainer import QATrainer, QAHookTrainer
from .question_answering.seq2seq_qa_trainer import Seq2SeqQATrainer
from .masked_language_modeling.span_mlm_trainer import SpanMLMTrainer
from .text_classification.tc_trainer import TCTrainer, TextClsHookTrainer
from .text_classification.seq2seq_tc_trainer import Seq2SeqTextClsTrainer

# CV
from .image_classification.img_cls_trainer import ImgClsTrainer, ImgClsHookTrainer

__all__ = (
    'TRAINER',
    'build_trainer',
    'BaseTrainer',
    'NLPTrainer', 'NLPHookTrainer',
    'ImgClsTrainer', 'ImgClsHookTrainer',
    'QATrainer', 'QAHookTrainer', 'Seq2SeqQATrainer',
    'TCTrainer', 'TextClsHookTrainer', 'Seq2SeqTextClsTrainer',
    'SpanMLMTrainer',
)
