import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from typing import Callable

from accelerate import Accelerator
from torch.utils.data.dataloader import DataLoader

from engine.loss import loss_dict

from data.nlp import NLPDataContainer
from engine.trainer import TRAINER, QAHookTrainer


@TRAINER.register_module(name='seq2seq_question_answering')
class Seq2SeqQATrainer(QAHookTrainer):
    """
    Trainer for question answering task with Seq2Seq model, integrate with hook mechanism.
    """

    def run(
        self, data_container: NLPDataContainer, metric_computor: Callable = None,
        pruner=None, accelerator: Accelerator = None, **kwargs
    ):
        run_args = dict(
            # Raw dataset
            examples=data_container.val_data,
            # Tokenized dataset
            features=data_container.features['validation'],
            version_2_with_negative=kwargs.pop('version_2_with_negative', False),
            generation_max_length=kwargs.pop('generation_max_length', 30),
            generation_num_beams=kwargs.pop('generation_num_beams', 1)
        )
        super().run(
            data_container,
            metric_computor=metric_computor, pruner=pruner,
            accelerator=accelerator, **run_args
        )

    @torch.no_grad()
    def eval(
        self, epoch: int,
        model: nn.Module, dataloader: DataLoader,
        metric_computor: Callable, accelerator: Accelerator = None,
        is_teacher: bool = False, stage: str = 'Eval',
        **kwargs
    ):
        """
        Evalation procedure.
        """

        self.generation_num_beams = kwargs.pop('generation_num_beams', 1)
        self.generation_max_length = kwargs.pop('generation_max_length', 30)
        super().eval(
            epoch, model, dataloader, metric_computor,
            accelerator=accelerator, is_teacher=is_teacher, stage=stage, **kwargs
        )

    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, processed_batch, *args, **kwargs):
        """
        Compute loss when in knowledge distillation mode.
        """

        logit_loss_func = loss_dict[self.kd_cfg['logit_loss']]
        hs_loss_func = loss_dict[self.kd_cfg['hs_loss']]
        attn_loss_func = loss_dict[self.kd_cfg['attn_loss']]

        '''Outputs'''

        # Logits
        logits, teacher_logits = outputs.logits, teacher_outputs.logits

        # Hidden states(encoder & decoder)
        enc_hidden_states, dec_hidden_states = \
            outputs.encoder_hidden_states, outputs.decoder_hidden_states
        teatcher_enc_hidden_states, teacher_dec_hidden_states = \
            teacher_outputs.encoder_hidden_states, teacher_outputs.decoder_hidden_states

        # Cross attentions
        cross_attns, teacher_cross_attns = outputs.cross_attentions, teacher_outputs.cross_attentions

        # Self attentions(encoder & decoder)
        enc_attns, dec_attns = outputs.encoder_attentions, outputs.decoder_attentions
        teacher_enc_attns, teacher_dec_attns = teacher_outputs.encoder_attentions, teacher_outputs.decoder_attentions

        '''Losses'''

        # Logits loss
        # (B,L,C)->(BxL,C)
        logits_ = logits.reshape(-1, logits.size(-1))
        # (B,C)->(BxC,)
        targets = processed_batch['labels'].flatten()
        # (B,L,C)->(BxL,C)
        teacher_logits_ = teacher_logits.reshape(-1, teacher_logits.size(-1))

        if self.kd_cfg['add_gt_loss']:
            kd_warmup_steps = len(self.dataloader) * (self.end_epoch - self.start_epoch) // 10
            self.logits_loss = F.cross_entropy(logits_, targets) + \
                min((self.global_step + 1) / kd_warmup_steps, 1.) * logit_loss_func(logits_, teacher_logits_, targets, **kwargs)
        else:
            self.logits_loss = logit_loss_func(logits_, teacher_logits_, targets, **kwargs)

        enc_begin_layer = self.kd_cfg.get('enc_layer_begin', self.kd_cfg.get('layer_begin', 0))
        enc_end_layer = self.kd_cfg.get('enc_layer_end', self.kd_cfg.get('layer_end', -1))
        if enc_end_layer == -1:
            enc_end_layer = len(enc_hidden_states)

        # Encoder hidden states loss(mse)
        self.enc_hs_loss = 0.
        for enc_hs, teacher_enc_hs in zip(
            enc_hidden_states[enc_begin_layer:enc_end_layer],
            teatcher_enc_hidden_states[enc_begin_layer:enc_end_layer]
        ):
            if self.kd_cfg['norm_hs']:
                eps = 1e-6

                hs_var = enc_hs.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)
                teacher_hs_var = teacher_enc_hs.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)

                enc_hs = enc_hs * torch.rsqrt(hs_var + eps)
                teacher_enc_hs = teacher_enc_hs * torch.rsqrt(teacher_hs_var + eps)

            if self.kd_cfg['hs_loss'] == 'mse':
                self.enc_hs_loss = self.enc_hs_loss + hs_loss_func(enc_hs, teacher_enc_hs, **kwargs)
            elif self.kd_cfg['hs_loss'] == 'soft_ce':
                d = enc_hs.size(-1)

                enc_hs_corr = torch.matmul(
                    enc_hs,
                    enc_hs.transpose(-1, -2)
                ) / math.sqrt(d)
                teacher_enc_hs_corr = torch.matmul(
                    teacher_enc_hs,
                    teacher_enc_hs.transpose(-1, -2)
                ) / math.sqrt(d)

                self.enc_hs_loss = self.enc_hs_loss + hs_loss_func(F.softmax(enc_hs_corr, dim=-1), F.softmax(teacher_enc_hs_corr, dim=-1), **kwargs)
            else:
                raise NotImplementedError(f"Not supported hidden loss type: {self.kd_cfg['hs_loss']}.")

        dec_begin_layer = self.kd_cfg.get('dec_layer_begin', self.kd_cfg.get('layer_begin', 0))
        dec_end_layer = self.kd_cfg.get('dec_layer_end', self.kd_cfg.get('layer_end', -1))
        if dec_end_layer == -1:
            dec_end_layer = len(dec_hidden_states)

        # Decoder hidden states loss(mse)
        self.dec_hs_loss = 0.
        for dec_hs, teacher_dec_hs in zip(
            dec_hidden_states[dec_begin_layer:dec_end_layer],
            teacher_dec_hidden_states[dec_begin_layer:dec_end_layer]
        ):
            if self.kd_cfg['norm_hs']:
                hs_var = dec_hs.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)
                teacher_hs_var = teacher_dec_hs.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)

                dec_hs = dec_hs * torch.rsqrt(hs_var + eps)
                teacher_dec_hs = teacher_dec_hs * torch.rsqrt(teacher_hs_var + eps)
            
            if self.kd_cfg['hs_loss'] == 'mse':
                self.dec_hs_loss = self.dec_hs_loss + hs_loss_func(dec_hs, teacher_dec_hs, **kwargs)
            elif self.kd_cfg['hs_loss'] == 'soft_ce':
                d = dec_hs.size(-1)

                dec_hs_corr = torch.matmul(
                    dec_hs,
                    dec_hs.transpose(-1, -2)
                ) / math.sqrt(d)
                teacher_dec_hs_corr = torch.matmul(
                    teacher_dec_hs,
                    teacher_dec_hs.transpose(-1, -2)
                ) / math.sqrt(d)

                self.dec_hs_loss = self.dec_hs_loss + hs_loss_func(F.softmax(dec_hs_corr, dim=-1), F.softmax(teacher_dec_hs_corr, dim=-1), **kwargs)
            else:
                raise NotImplementedError(f"Not supported hidden loss type: {self.kd_cfg['hs_loss']}.")

        # Cross attentions loss(mse)
        self.cross_attns_loss = 0.
        for cs_attn, teacher_cs_attn in \
            zip(cross_attns[dec_begin_layer:dec_end_layer], teacher_cross_attns[dec_begin_layer:dec_end_layer]):
            self.cross_attns_loss = self.cross_attns_loss + attn_loss_func(cs_attn, teacher_cs_attn, **kwargs)

        # Encoder self attentions loss(mse)
        self.enc_attns_loss = 0.
        for enc_sf_attn, teacher_enc_sf_attn in \
            zip(enc_attns[enc_begin_layer:enc_end_layer], teacher_enc_attns[enc_begin_layer:enc_end_layer]):
            self.enc_attns_loss = self.enc_attns_loss + attn_loss_func(enc_sf_attn, teacher_enc_sf_attn, **kwargs)
        
        # Decoder self attentions loss(mse)
        self.dec_attns_loss = 0.
        for dec_sf_attn, teacher_dec_sf_attn in \
            zip(dec_attns[dec_begin_layer:dec_end_layer], teacher_dec_attns[dec_begin_layer:dec_end_layer]):
            self.dec_attns_loss = self.dec_attns_loss + attn_loss_func(dec_sf_attn, teacher_dec_sf_attn, **kwargs)

        # kd_loss = 1000 * self.logits_loss + self.enc_hs_loss + 2 * self.dec_hs_loss + \
        #     10 * self.cross_attns_loss + 10 * self.enc_attns_loss + self.dec_attns_loss
        kd_loss = self.kd_cfg['logit_weight'] * self.logits_loss + \
            self.kd_cfg.get('enc_hs_weight', 1.) * self.enc_hs_loss + \
            self.kd_cfg.get('dec_hs_weight', 2.) * self.dec_hs_loss + \
            self.kd_cfg.get('cross_attn_weight', 10.) * self.cross_attns_loss + \
            self.kd_cfg.get('enc_attn_weight', 10.) * self.enc_attns_loss + \
            self.kd_cfg.get('dec_attn_weight', 1.) * self.dec_attns_loss

        return kd_loss
