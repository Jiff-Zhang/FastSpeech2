import os
import math
import time
import json
import datetime
import collections
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from tqdm import tqdm
from copy import deepcopy
from logging import Logger
from typing import Callable, Optional, Sequence, Tuple, List

from accelerate import Accelerator

from torch.optim import Optimizer
from torch.optim.lr_scheduler import _LRScheduler

from torch.cuda import max_memory_allocated
from torch.utils.data.dataloader import DataLoader
from torch.nn.utils.clip_grad import clip_grad_norm_

from data.nlp import NLPDataContainer

from utils.misc import get_grad_norm
from utils.meters import AverageMeter, ProgressMeter

from engine.loss import loss_dict, soft_ce_loss
from engine.trainer import TRAINER, NLPTrainer, NLPHookTrainer


@TRAINER.register_module(name='question_answering_with_hook')
class QAHookTrainer(NLPHookTrainer):
    """
    Trainer for question answering task, integrate with hook mechanism.
    """

    def fit(
        self, data_container: NLPDataContainer, metric_computor: Callable = None,
        pruner=None, accelerator: Accelerator = None, **kwargs
    ):
        self.logger.warning("\ntrainer.fit() was deprecated, please use trainer.run() instead.\n")
        self.run(data_container, metric_computor=metric_computor, pruner=pruner, accelerator=accelerator, **kwargs)

    def run(
        self, data_container: NLPDataContainer, metric_computor: Callable = None,
        pruner=None, accelerator: Accelerator = None, **kwargs
    ):
        if metric_computor is None:
            metric_computor = getattr(data_container, 'metric_computor', None)
        assert metric_computor is not None, f"metric computor cannot be None."
        
        self.answer_column_name = getattr(data_container, 'answer_column_name', 'answers')
        self.pad_to_max_seq_length = getattr(data_container, 'pad_to_max_seq_length', False)

        run_args = dict(
            # Raw dataset
            examples=data_container.val_data,
            # Tokenized dataset
            features=data_container.features['validation'],
            n_best_size=kwargs.pop('n_best_size', 20),
            max_answer_length=kwargs.pop('max_answer_length', 30),
            null_score_diff_threshold=kwargs.pop('null_score_diff_threshold', 0.),
            version_2_with_negative=kwargs.pop('version_2_with_negative', False)
        )
        super().run(data_container, metric_computor=metric_computor, pruner=pruner, accelerator=accelerator, **run_args)
        
        # In case of pruner saving checkpoint after training finished.
        self.pruner = None

        if kwargs.pop('eval_on_training_set', False):
            # Eval on training set when training finished
            train_val_examples = data_container.train_data
            train_val_features = data_container.features['train_val']
            train_val_loader = data_container.dataloaders['train_val']

            eval_args = deepcopy(run_args)
            eval_args.update(examples=train_val_examples, features=train_val_features)

            self.eval(
                self.end_epoch, self.model, train_val_loader,
                metric_computor=metric_computor, is_teacher=False,
                accelerator=accelerator, stage='Train_Val', **eval_args
            )
        
        # Do predict
        test_loader = data_container.dataloaders['test']
        if test_loader is not None:
            test_examples = data_container.test_data
            test_features = data_container.features['test']
            
            if not (test_examples is None or test_features is None):
                test_args = deepcopy(run_args)
                test_args.update(
                    examples=test_examples,
                    features=test_features
                )

                self.eval(
                    self.end_epoch, self.model, test_loader,
                    metric_computor=metric_computor,
                    accelerator=accelerator, stage='Test', **test_args
                )
    
    def train(
        self, epoch: int,
        model: nn.Module, dataloader: DataLoader,
        metric_computor: Callable, progress_bar,
        pruner=None, accelerator: Accelerator = None,
        **kwargs
    ):
        """
        Training procedure.
        """

        self.stage = 'train'
        self.examples = kwargs.pop('examples')
        self.features = kwargs.pop('features')
        self.n_best_size = kwargs.pop('n_best_size', 20)
        self.max_answer_length = kwargs.pop('max_answer_length', 30)
        self.null_score_diff_threshold = kwargs.pop('null_score_diff_threshold', 0.)
        self.version_2_with_negative = kwargs.pop('version_2_with_negative', False)

        super().train(
            epoch, model, dataloader, metric_computor, progress_bar,
            pruner=pruner, accelerator=accelerator, **kwargs
        )
    
    @torch.no_grad()
    def eval(
        self, epoch: int,
        model: nn.Module, dataloader: DataLoader,
        metric_computor: Callable, accelerator: Accelerator = None,
        is_teacher: bool = False, stage: str = 'Eval',
        **kwargs
    ):
        """
        Evalation procedure.
        """
        
        # Stage may be 'eval', 'train_val', or 'test', etc.
        self.stage = stage
        self.examples = kwargs.pop('examples')
        self.features = kwargs.pop('features')
        self.n_best_size = kwargs.pop('n_best_size', 20)
        self.max_answer_length = kwargs.pop('max_answer_length', 30)
        self.null_score_diff_threshold = kwargs.pop('null_score_diff_threshold', 0.)
        self.version_2_with_negative = kwargs.pop('version_2_with_negative', False)

        super().eval(
            epoch, model, dataloader, metric_computor,
            accelerator=accelerator, is_teacher=is_teacher, **kwargs
        )
    
    @property
    def mode(self):
        return getattr(self, 'stage', self._mode)
    
    def kd_forward(self, batch: dict, model=None, teacher=None):
        """
        Model forwarding progress when in knowledge distillation.
        """

        if model is None:
            model = self.model if self.deepspeed is None else self.deepspeed
        outputs = model(**batch, output_attentions=True, output_hidden_states=True)

        if teacher is None:
            teacher = self.teacher
        # Double check whether the teacher is in eval mode
        if teacher.training:
            teacher.eval()
        with torch.no_grad():
            teacher_outputs = teacher(**batch, output_attentions=True, output_hidden_states=True)
            
        return outputs, teacher_outputs
    
    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, processed_batch, *args, **kwargs):
        """
        Compute loss when in knowledge distillation mode.
        """

        logit_loss_func = loss_dict[self.kd_cfg['logit_loss']]
        hs_loss_func = loss_dict[self.kd_cfg['hs_loss']]
        attn_loss_func = loss_dict[self.kd_cfg['attn_loss']]

        hidden_states, attns, start_logits, end_logits = outputs.hidden_states, \
            outputs.attentions, outputs.start_logits, outputs.end_logits
        teacher_hidden_states, teacher_attns, teacher_start_logits, teacher_end_logits = teacher_outputs.hidden_states, \
            teacher_outputs.attentions, teacher_outputs.start_logits, teacher_outputs.end_logits

        # Logits loss(ce)
        if self.kd_cfg['add_gt_loss']:
            kd_warmup_steps = len(self.dataloader) * (self.end_epoch - self.start_epoch) // 10
            start_logits_loss = F.cross_entropy(start_logits, processed_batch['start_positions']) + \
                min((self.global_step + 1) / kd_warmup_steps, 1.) * logit_loss_func(start_logits, teacher_start_logits, labels=processed_batch['start_positions'], **kwargs)
            end_logits_loss = F.cross_entropy(end_logits, processed_batch['end_positions']) + \
                min((self.global_step + 1) / kd_warmup_steps, 1.) * logit_loss_func(end_logits, teacher_end_logits, labels=processed_batch['end_positions'], **kwargs)
        else:
            start_logits_loss = logit_loss_func(start_logits, teacher_start_logits, labels=processed_batch['start_positions'], **kwargs)
            end_logits_loss = logit_loss_func(end_logits, teacher_end_logits, labels=processed_batch['end_positions'], **kwargs)

        self.logits_loss = (start_logits_loss + end_logits_loss) / 2.

        begin_layer = self.kd_cfg.get('layer_begin', 0)
        end_layer = self.kd_cfg.get('layer_end', -1)
        if end_layer == -1:
            end_layer = len(hidden_states)

        # Hidden states loss(mse)
        self.hs_loss = 0.
        for layer_hidden_state, teacher_layer_hidden_state in \
            zip(hidden_states[begin_layer:end_layer], teacher_hidden_states[begin_layer:end_layer]):
            if self.kd_cfg['norm_hs']:
                eps = 1e-6

                hs_var = layer_hidden_state.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)
                teacher_hs_var = teacher_layer_hidden_state.to(torch.float32).pow(2).mean(dim=-1, keepdim=True)

                layer_hidden_state = layer_hidden_state * torch.rsqrt(hs_var + eps)
                teacher_layer_hidden_state = teacher_layer_hidden_state * torch.rsqrt(teacher_hs_var + eps)

            if self.kd_cfg['hs_loss'] == 'mse':
                self.hs_loss = self.hs_loss + hs_loss_func(layer_hidden_state, teacher_layer_hidden_state, **kwargs)
            elif self.kd_cfg['hs_loss'] == 'soft_ce':
                d = layer_hidden_state.size(-1)

                layer_hs_corr = torch.matmul(
                    layer_hidden_state,
                    layer_hidden_state.transpose(-1, -2)
                ) / math.sqrt(d)
                teacher_layer_hs_corr = torch.matmul(
                    teacher_layer_hidden_state,
                    teacher_layer_hidden_state.transpose(-1, -2)
                ) / math.sqrt(d)

                self.hs_loss = self.hs_loss + hs_loss_func(F.softmax(layer_hs_corr, dim=-1), F.softmax(teacher_layer_hs_corr, dim=-1), **kwargs)
            else:
                raise NotImplemented(f"Not supported hidden state loss: {self.kd_cfg['hs_loss']}.")

        # Attentions loss(mse)
        self.attn_loss = 0.
        for layer_attn, teacher_layer_attn in \
            zip(attns[begin_layer:end_layer], teacher_attns[begin_layer:end_layer]):
            self.attn_loss = self.attn_loss + attn_loss_func(layer_attn, teacher_layer_attn, **kwargs)

        kd_loss = self.kd_cfg['logit_weight'] * self.logits_loss + \
            self.kd_cfg['hs_weight'] * self.hs_loss + self.kd_cfg['attn_weight'] * self.attn_loss

        return kd_loss


@TRAINER.register_module(name='question_answering')
class QATrainer(NLPTrainer):
    """
    Trainer for question answering task.
    """

    def __init__(
        self, 
        model: nn.Module, optimizer: Optimizer, lr_scheduler: _LRScheduler, 
        logger: Logger, epochs: int, start_epoch: int = 0, 
        log_freq: int = 1, save_freq: int = 1, output_dir: str = None, 
        grad_accumulation_steps: int = 1, clip_grad: bool = False, max_grad_norm: float = 1, 
        loss: str = None, metric_identifier: Sequence[str] = ('exact_match', 'f1',), 
        kd: bool = False, teacher: nn.Module = None, 
        kd_cls_loss: str = None, kd_reg_loss: str = None, kd_begin_layer: int = 0
    ):
        super().__init__(
            model, optimizer, lr_scheduler, logger, 
            epochs, start_epoch=start_epoch, log_freq=log_freq, save_freq=save_freq, 
            output_dir=output_dir, grad_accumulation_steps=grad_accumulation_steps, 
            clip_grad=clip_grad, max_grad_norm=max_grad_norm, loss=loss,
            metric_identifier=metric_identifier, kd=kd, teacher=teacher, 
            kd_cls_loss=kd_cls_loss, kd_reg_loss=kd_reg_loss, kd_begin_layer=kd_begin_layer
        )

    def fit(
        self, accelerator: Accelerator, data_container: NLPDataContainer, 
        metric_computor: Callable = None, pruner=None,
        answer_column_name: str = 'answers', pad_to_max_seq_length: bool = True, n_best_size: int = 20, 
        max_answer_length: int = 30, null_score_diff_threshold: float = 0.,
        version_2_with_negative: bool = False, **kwargs
    ):
        if metric_computor is None:
            metric_computor = getattr(data_container, 'metric_computor', None)
        assert metric_computor is not None, f"metric computor cannot be None."

        # Raw dataset
        examples = data_container.val_data
        # Tokenized dataset
        features = data_container.features['validation']
        super().fit(
            accelerator, data_container, metric_computor=metric_computor, 
            pruner=pruner, examples=examples, features=features,
            pad_to_max_seq_length=pad_to_max_seq_length, n_best_size=n_best_size, max_answer_length=max_answer_length, 
            null_score_diff_threshold=null_score_diff_threshold, version_2_with_negative=version_2_with_negative,
            answer_column_name=answer_column_name, **kwargs
        )

        # Eval on training set when training finished
        train_val_examples = data_container.train_data
        train_val_features = data_container.features['train']
        if not (train_val_examples is None or train_val_features is None):
            train_loader = data_container.dataloaders['train']
            self.eval(
                self.end_epoch, self.model, accelerator, train_loader, metric_computor=metric_computor,
                examples=train_val_examples, features=train_val_features, stage='Train_Val',
                pad_to_max_seq_length=pad_to_max_seq_length, n_best_size=n_best_size, max_answer_length=max_answer_length, 
                null_score_diff_threshold=null_score_diff_threshold, version_2_with_negative=version_2_with_negative,
                answer_column_name=answer_column_name, **kwargs
            )
        
        # Do predict
        test_loader = data_container.dataloaders['test']
        if test_loader is not None:
            test_examples = data_container.test_data
            test_features = data_container.features['test']
            if not (test_examples is None or test_features is None):
                self.eval(
                    self.end_epoch, self.model, accelerator, test_loader, metric_computor=metric_computor,
                    examples=test_examples, features=test_features, stage='Test',
                    pad_to_max_seq_length=pad_to_max_seq_length, n_best_size=n_best_size, max_answer_length=max_answer_length, 
                    null_score_diff_threshold=null_score_diff_threshold, version_2_with_negative=version_2_with_negative,
                    answer_column_name=answer_column_name, **kwargs
                )

    def train(
        self, epoch: int, model: nn.Module, accelerator: Accelerator, 
        dataloader: DataLoader, metric_computor: Callable, progress_bar,
        pruner=None, **kwargs
    ):
        """
        Training procedure.
        """

        model.train()

        # Meters
        loss_meter = AverageMeter('loss', fmt=':.4f')
        progress_meter = ProgressMeter(
            len(dataloader), [loss_meter], 
            prefix=f"Train Epoch[{(epoch):0>3}/{self.end_epoch:0>3}]"
        )

        # Learning rate of each step
        step_lr = []
        # Epoch & Batch start time
        epoch_start = batch_start = time.time()

        # Train loop
        for step, batch in enumerate(dataloader):
            batch_for_model = self.process_batch(batch)
            # Forward
            if self.kd:
                outputs, teacher_outputs = self.kd_forward(batch_for_model)
            else:
                outputs = model(**batch_for_model)

            # Compute loss
            if self.kd:
                loss = self.compute_kd_loss(outputs, teacher_outputs, step, len(dataloader))
            else:
                loss_func = loss_dict[self.loss]
                loss = loss_func(outputs, batch)
            # Scaled by gradient accumulation
            loss /= self.grad_accumulation_steps

            # Backward
            loss.backward()
            loss_meter.update(loss.item())

            # Gradient clipping(optional)
            if self.clip_grad:
                grad_norm = clip_grad_norm_(model.parameters(), max_norm=self.max_grad_norm)
            else:
                grad_norm = get_grad_norm(model.parameters())

            lr = self.optimizer.param_groups[0]['lr']
            step_lr.append(lr)

            # Update
            if not (step + 1) % self.grad_accumulation_steps or step == len(dataloader) - 1:
                self.optimizer.step()
                self.lr_scheduler.step()
                self.optimizer.zero_grad()

                # Pruning
                if pruner is not None:
                    # Do pruning controled by prune frequency,
                    # and return back current sparsity
                    cur_sparsity = pruner.prune()
                    # Log current sparsity
                    if cur_sparsity is not None:
                        self.logger.info(f"\nCurrent sparsity: {cur_sparsity}")
                    # Log current sparsity of each layer
                    if pruner._update_mask_conditions():
                        layer_sparse_rate, total_sparse_rate = pruner.sparsity()
                        self.logger.info(f'\nweight sparsity: {total_sparse_rate}\n'
                                         f'layer weight sparsity:\n{layer_sparse_rate}\n')

            # Log
            global_step = epoch * len(dataloader) + step
            if not global_step % self.log_freq or step == len(dataloader) - 1:
                batch_time = time.time() - batch_start
                memory_used = max_memory_allocated() / (1024. ** 2)

                # Formatted loss & metric string
                info = progress_meter.display(step, print_out=False)
                info += f"\tlr: {lr:.10f}\tgrad norm: {grad_norm:.6f}\t" \
                        f"batch time: {batch_time:.2f}s\tmemory used: {memory_used:.0f}MB\n"
                self.logger.info(info)
            
            # Reset batch start time
            batch_start = time.time()
            # Update progress bar after each step
            progress_bar.update()
            # This may release some memories
            del loss

        # Release resources(but not available to Pytorch)
        torch.cuda.empty_cache()

        # Compute statistic
        epoch_time = time.time() - epoch_start
        epoch_loss = getattr(loss_meter, 'avg')
        epoch_metrics = {}

        # Epoch log
        self.logger.info(
            f"[Train] epoch: {epoch}/{self.end_epoch} "
            f"loss: {epoch_loss:.6f} time: {datetime.timedelta(seconds=epoch_time)}\n"
        )

        return epoch_loss, epoch_metrics, step_lr
    
    def eval(
        self, epoch: int, model: nn.Module, accelerator: Accelerator, 
        dataloader: DataLoader, metric_computor: Callable, 
        is_teacher: bool = False, examples=None, features=None, stage: str = 'Eval',
        pad_to_max_seq_length: bool = True, n_best_size: int = 20, max_answer_length: int = 30, 
        null_score_diff_threshold: float = 0., version_2_with_negative: bool = False, answer_column_name: str = 'answers',
        **kwargs
    ):
        """
        Evalation procedure.
        """

        model.eval()

        # Meters
        loss_meter = AverageMeter('loss', fmt=':.4f')
        progress_meter = ProgressMeter(
            len(dataloader), [loss_meter], 
            prefix=f"{stage} Epoch[{(epoch):0>3}/{self.end_epoch:0>3}]"
        )

        # Logits of each token standing for the first word of answer
        all_start_logits = []
        # Logits of each token standing for the last word of answer
        all_end_logits = []

        # Prefix string(used for distinguishing teacher from student)
        prefix = '[Teacher]\t' if is_teacher else ''
        # Epoch & Batch start time
        epoch_start = batch_start = time.time()

        # Eval loop
        for step, batch in enumerate(dataloader):
            with torch.no_grad():
                batch_for_model = self.process_batch(batch)
                # Forward
                outputs = model(**batch_for_model)
                
                # Compute loss
                loss_func = loss_dict[self.loss]
                loss = loss_func(outputs, batch)
                loss_meter.update(loss.item())

                start_logits = outputs.start_logits
                end_logits = outputs.end_logits

                # Necessary to pad predictions and labels for being gathered
                if not pad_to_max_seq_length:
                    start_logits = accelerator.pad_across_processes(start_logits, dim=1, pad_index=-100)
                    end_logits = accelerator.pad_across_processes(end_logits, dim=1, pad_index=-100)

                all_start_logits.append(accelerator.gather(start_logits).cpu().numpy())
                all_end_logits.append(accelerator.gather(end_logits).cpu().numpy())

            # Log
            if not step % self.log_freq or step == len(dataloader) - 1:
                batch_time = time.time() - batch_start
                lr = self.optimizer.param_groups[0]['lr']
                memory_used = max_memory_allocated() / (1024. ** 2)

                # Formatted loss & metric string
                info = progress_meter.display(step, print_out=False)
                info += f"\tlr: {lr:.10f}\tbatch time: {batch_time:.2f}s\tmemory used: {memory_used:.0f}MB\n"
                self.logger.info(prefix + info)
            
            # Reset batch start time
            batch_start = time.time()
            # This may release some memories
            del loss

        # Release resources(but not available to Pytorch)
        torch.cuda.empty_cache()

        max_len = max([x.shape[1] for x in all_start_logits])  # Get the max_length of the tensor
        # Concatenate the numpy array
        start_logits_concat = self.create_and_fill_np_array(all_start_logits, features, max_len)
        end_logits_concat = self.create_and_fill_np_array(all_end_logits, features, max_len)
        # Delete the list of numpy arrays
        del all_start_logits
        del all_end_logits

        outputs_numpy = (start_logits_concat, end_logits_concat)
        # Post-process the raw model outputs to form the formatted predictions
        predictions = self.generate_predictions(
            examples, features, outputs_numpy, stage=stage, 
            n_best_size=n_best_size, max_answer_length=max_answer_length,
            null_score_diff_threshold=null_score_diff_threshold,
            version_2_with_negative=version_2_with_negative, epoch=epoch
        )

        # Compute epoch statistic
        epoch_time = time.time() - epoch_start
        epoch_loss = getattr(loss_meter, 'avg')
        epoch_metrics = self.compute_metric(
            predictions, examples,
            metric_computor, answer_column_name=answer_column_name
        )
        metric_info = ' '.join([f"{k}: {v:.3f}" for k, v in epoch_metrics.items()])
        # Epoch log
        self.logger.info(
            f"{prefix}[{stage}] epoch: {epoch}/{self.end_epoch} "
            f"loss: {epoch_loss:.6f} {metric_info} time: {datetime.timedelta(seconds=epoch_time)}\n"
        )

        return epoch_loss, epoch_metrics
    
    def kd_forward(self, batch: dict):
        """
        Model forwarding progress when in knowledge distillation.
        """

        # Double check whether the teacher is in eval mode
        if self.teacher.training:
            self.teacher.eval()

        outputs = self.model(**batch, output_attentions=True, output_hidden_states=True)
        with torch.no_grad():
            teacher_outputs = self.teacher(**batch, output_attentions=True, output_hidden_states=True)
            
        return outputs, teacher_outputs
    
    def compute_kd_loss(self, outputs: torch.Tensor, teacher_outputs: torch.Tensor, step: int, step_per_epoch: int):
        """
        Compute loss when in knowledge distillation mode.
        """

        cls_loss_func = loss_dict[self.kd_cls_loss]
        reg_loss_func = loss_dict[self.kd_reg_loss]

        hidden_states, attns, start_logits, end_logits = outputs.hidden_states, \
            outputs.attentions, outputs.start_logits, outputs.end_logits
        teacher_hidden_states, teacher_attns, teacher_start_logits, teacher_end_logits = teacher_outputs.hidden_states, \
            teacher_outputs.attentions, teacher_outputs.start_logits, teacher_outputs.end_logits

        # Logits loss(ce)
        start_logits_loss = cls_loss_func(start_logits, teacher_start_logits)
        end_logits_loss = cls_loss_func(end_logits, teacher_end_logits)
        logits_loss = (start_logits_loss + end_logits_loss) / 2.

        # Hidden states loss(mse)
        hs_loss = 0.
        for layer_hidden_state, teacher_layer_hidden_state in \
            zip(hidden_states[self.kd_begin_layer:], teacher_hidden_states[self.kd_begin_layer:]):
            hs_loss = hs_loss + reg_loss_func(layer_hidden_state, teacher_layer_hidden_state)

        # Attentions loss(mse)
        attn_loss = 0.
        for layer_attn, teacher_layer_attn in \
            zip(attns[self.kd_begin_layer:], teacher_attns[self.kd_begin_layer:]):
            attn_loss = attn_loss + reg_loss_func(layer_attn, teacher_layer_attn)
        
        global_step = self.start_epoch * step_per_epoch + step
        if not global_step % self.log_freq or step == step_per_epoch - 1:
            self.logger.info(
                f"\nkd logits loss: {logits_loss.item():.8f}\t"
                f"kd hidden states loss: {hs_loss.item():.8f}\t"
                f"kd attentions loss: {attn_loss.item():.8f}\n"
            )

        kd_loss = logits_loss + hs_loss + attn_loss
        del start_logits_loss, end_logits_loss, logits_loss, hs_loss, attn_loss

        return kd_loss
    
    def generate_predictions(
        self, examples, features, predictions: Tuple[np.ndarray, np.ndarray],
        stage: str = 'Eval', n_best_size: int = 20, max_answer_length: int = 30, 
        null_score_diff_threshold: float = 0., version_2_with_negative: bool = False, epoch: int = -1
    ):
        """
        Post-process the raw model outputs to generate formatted predictions, used for computing metrics.
        """

        # Post-processing: we match the start logits and end logits to answers in the original context.
        predictions = self._postprocess_qa_predictions(
            examples=examples,
            features=features,
            predictions=predictions,
            version_2_with_negative=version_2_with_negative,
            n_best_size=n_best_size,
            max_answer_length=max_answer_length,
            null_score_diff_threshold=null_score_diff_threshold,
            output_dir=self.output_dir,
            prefix=stage,
            epoch=epoch
        )
        # Format the result to the format the metric expects.
        if version_2_with_negative:
            formatted_predictions = [
                {"id": k, "prediction_text": v, "no_answer_probability": 0.0} for k, v in predictions.items()
            ]
        else:
            formatted_predictions = [{"id": k, "prediction_text": v} for k, v in predictions.items()]

        return formatted_predictions

    def _postprocess_qa_predictions(
        self,
        examples,
        features,
        predictions: Tuple[np.ndarray, np.ndarray],
        version_2_with_negative: bool = False,
        n_best_size: int = 20,
        max_answer_length: int = 30,
        null_score_diff_threshold: float = 0.0,
        output_dir: Optional[str] = None,
        prefix: Optional[str] = None,
        epoch: int = -1
    ):
        """
        Post-processes the predictions of a question-answering model to convert them to answers that are substrings of the
        original contexts. This is the base postprocessing functions for models that only return start and end logits.
        Args:
            examples: The non-preprocessed dataset (see the main script for more information).
            features: The processed dataset (see the main script for more information).
            predictions (:obj:`Tuple[np.ndarray, np.ndarray]`):
                The predictions of the model: two arrays containing the start logits and the end logits respectively. Its
                first dimension must match the number of elements of :obj:`features`.
            version_2_with_negative (:obj:`bool`, `optional`, defaults to :obj:`False`):
                Whether or not the underlying dataset contains examples with no answers.
            n_best_size (:obj:`int`, `optional`, defaults to 20):
                The total number of n-best predictions to generate when looking for an answer.
            max_answer_length (:obj:`int`, `optional`, defaults to 30):
                The maximum length of an answer that can be generated. This is needed because the start and end predictions
                are not conditioned on one another.
            null_score_diff_threshold (:obj:`float`, `optional`, defaults to 0):
                The threshold used to select the null answer: if the best answer has a score that is less than the score of
                the null answer minus this threshold, the null answer is selected for this example (note that the score of
                the null answer for an example giving several features is the minimum of the scores for the null answer on
                each feature: all features must be aligned on the fact they `want` to predict a null answer).
                Only useful when :obj:`version_2_with_negative` is :obj:`True`.
            output_dir (:obj:`str`, `optional`):
                If provided, the dictionaries of predictions, n_best predictions (with their scores and logits) and, if
                :obj:`version_2_with_negative=True`, the dictionary of the scores differences between best and null
                answers, are saved in `output_dir`.
            prefix (:obj:`str`, `optional`):
                If provided, the dictionaries mentioned above are saved with `prefix` added to their names.
            log_level (:obj:`int`, `optional`, defaults to ``logging.WARNING``):
                ``logging`` log level (e.g., ``logging.WARNING``)
        """

        if len(predictions) != 2:
            raise ValueError("`predictions` should be a tuple with two elements (start_logits, end_logits).")
        all_start_logits, all_end_logits = predictions

        if len(all_start_logits) != len(features):
            raise ValueError(f"Got {len(all_start_logits)} predictions and {len(features)} features.")
        if len(all_end_logits) != len(features):
            raise ValueError(f"Got {len(all_end_logits)} predictions and {len(features)} features.")

        # Build a map example to its corresponding features.
        example_id_to_index = {k: i for i, k in enumerate(examples["id"])}
        features_per_example = collections.defaultdict(list)
        for i, feature in enumerate(features):
            features_per_example[example_id_to_index[feature["example_id"]]].append(i)

        # The dictionaries we have to fill.
        all_predictions = collections.OrderedDict()
        all_nbest_json = collections.OrderedDict()
        if version_2_with_negative:
            scores_diff_json = collections.OrderedDict()

        # Log.
        self.logger.info(f"Post-processing {len(examples)} example predictions split into {len(features)} features.")
        # Loop over all the examples
        for example_index, example in enumerate(tqdm(examples)):
            # Those are the indices of the features associated to the current example.
            feature_indices = features_per_example[example_index]

            min_null_prediction = None
            prelim_predictions = []

            # Looping through all the features associated to the current example.
            for feature_index in feature_indices:
                # We grab the predictions of the model for this feature.
                start_logits = all_start_logits[feature_index]
                end_logits = all_end_logits[feature_index]
                # This is what will allow us to map some the positions in our logits to span of texts in the original
                # context.
                offset_mapping = features[feature_index]["offset_mapping"]
                # Optional `token_is_max_context`, if provided we will remove answers that do not have the maximum context
                # available in the current feature.
                token_is_max_context = features[feature_index].get("token_is_max_context", None)

                # Update minimum null prediction.
                feature_null_score = start_logits[0] + end_logits[0]
                if min_null_prediction is None or min_null_prediction["score"] > feature_null_score:
                    min_null_prediction = {
                        "offsets": (0, 0),
                        "score": feature_null_score,
                        "start_logit": start_logits[0],
                        "end_logit": end_logits[0],
                    }

                # Go through all possibilities for the `n_best_size` greater start and end logits.
                start_indexes = np.argsort(start_logits)[-1 : -n_best_size - 1 : -1].tolist()
                end_indexes = np.argsort(end_logits)[-1 : -n_best_size - 1 : -1].tolist()
                for start_index in start_indexes:
                    for end_index in end_indexes:
                        # Don't consider out-of-scope answers, either because the indices are out of bounds or correspond
                        # to part of the input_ids that are not in the context.
                        if (
                            start_index >= len(offset_mapping)
                            or end_index >= len(offset_mapping)
                            or offset_mapping[start_index] is None
                            or offset_mapping[end_index] is None
                        ):
                            continue
                        # Don't consider answers with a length that is either < 0 or > max_answer_length.
                        if end_index < start_index or end_index - start_index + 1 > max_answer_length:
                            continue
                        # Don't consider answer that don't have the maximum context available (if such information is
                        # provided).
                        if token_is_max_context is not None and not token_is_max_context.get(str(start_index), False):
                            continue
                        prelim_predictions.append(
                            {
                                "offsets": (offset_mapping[start_index][0], offset_mapping[end_index][1]),
                                "score": start_logits[start_index] + end_logits[end_index],
                                "start_logit": start_logits[start_index],
                                "end_logit": end_logits[end_index],
                            }
                        )
            if version_2_with_negative:
                # Add the minimum null prediction
                prelim_predictions.append(min_null_prediction)
                null_score = min_null_prediction["score"]

            # Only keep the best `n_best_size` predictions.
            predictions = sorted(prelim_predictions, key=lambda x: x["score"], reverse=True)[:n_best_size]

            # Add back the minimum null prediction if it was removed because of its low score.
            if version_2_with_negative and not any(p["offsets"] == (0, 0) for p in predictions):
                predictions.append(min_null_prediction)

            # Use the offsets to gather the answer text in the original context.
            context = example["context"]
            for pred in predictions:
                offsets = pred.pop("offsets")
                pred["text"] = context[offsets[0] : offsets[1]]

            # In the very rare edge case we have not a single non-null prediction, we create a fake prediction to avoid
            # failure.
            if not len(predictions) or (len(predictions) == 1 and predictions[0]["text"] == ""):
                predictions.insert(0, {"text": "empty", "start_logit": 0.0, "end_logit": 0.0, "score": 0.0})

            # Compute the softmax of all scores (we do it with numpy to stay independent from torch/tf in this file, using
            # the LogSumExp trick).
            scores = np.array([pred.pop("score") for pred in predictions])
            exp_scores = np.exp(scores - np.max(scores))
            probs = exp_scores / exp_scores.sum()

            # Include the probabilities in our predictions.
            for prob, pred in zip(probs, predictions):
                pred["probability"] = prob

            # Pick the best prediction. If the null answer is not possible, this is easy.
            if not version_2_with_negative:
                all_predictions[example["id"]] = predictions[0]["text"]
            else:
                # Otherwise we first need to find the best non-empty prediction.
                i = 0
                while predictions[i]["text"] == "":
                    i += 1
                best_non_null_pred = predictions[i]

                # Then we compare to the null prediction using the threshold.
                score_diff = null_score - best_non_null_pred["start_logit"] - best_non_null_pred["end_logit"]
                scores_diff_json[example["id"]] = float(score_diff)  # To be JSON-serializable.
                if score_diff > null_score_diff_threshold:
                    all_predictions[example["id"]] = ""
                else:
                    all_predictions[example["id"]] = best_non_null_pred["text"]

            # Make `predictions` JSON-serializable by casting np.float back to float.
            all_nbest_json[example["id"]] = [
                {k: (float(v) if isinstance(v, (np.float16, np.float32, np.float64)) else v) for k, v in pred.items()}
                for pred in predictions
            ]
        
        # Write out prediction results to files
        if not os.path.isdir(output_dir):
            raise EnvironmentError(f"{output_dir} is not a directory.")
        dst_dir = os.path.join(output_dir, 'predictions')
        os.makedirs(dst_dir, exist_ok=True)

        prefix_info = f"{prefix}_" if prefix is not None else ""
        if epoch != -1:
            prefix_info += f"epoch{epoch}_"

        prediction_file = os.path.join(dst_dir, f"{prefix_info}predictions.json")
        self.logger.info(f"=> Saving predictions to {prediction_file}.\n")
        with open(prediction_file, "a") as writer:
            writer.write(json.dumps(all_predictions, indent=4) + "\n")

        nbest_file = os.path.join(dst_dir, f"{prefix_info}nbest_predictions.json")
        self.logger.info(f"=> Saving nbest_preds to {nbest_file}.\n")
        with open(nbest_file, "a") as writer:
            writer.write(json.dumps(all_nbest_json, indent=4) + "\n")

        if version_2_with_negative:
            null_odds_file = os.path.join(dst_dir, f"{prefix_info}null_odds.json")
            self.logger.info(f"=> Saving null_odds to {null_odds_file}.\n")
            with open(null_odds_file, "a") as writer:
                writer.write(json.dumps(scores_diff_json, indent=4) + "\n")

        return all_predictions
    
    def compute_metric(self, predictions: List, data, metric_computor: Callable, **kwargs):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """

        answer_column_name = kwargs.pop('answer_column_name', 'answers')
        references = [{"id": example["id"], "answers": example[answer_column_name]} for example in data]

        assert len(predictions) == len(references)
        return metric_computor.compute(predictions=predictions, references=references)
    
    def save_checkpoint(
        self, output_dir, cur, start, end, freq, model, optimizer, lr_scheduler,
        train_loss, eval_loss, train_metric_dict, eval_metric_dict, pruner=None, **kwargs
    ):
        """
        Save state dict.
        Note: When pruning, we only save checkpoints in fine-tuning stage.
        """

        avg_tag = f'-avg{(sum(eval_metric_dict[metric_name] for metric_name in self.metric_identifier) / len(self.metric_identifier)):.3f}-' \
                if len(eval_metric_dict) > 1 else '-'
        metric_tag = '-'.join( 
            [f"{metric_name}{eval_metric_dict[metric_name]:.3f}" 
            for metric_name in self.metric_identifier]
        )
        output_file = f'epoch{cur}{avg_tag}{metric_tag}.pth'

        NLPTrainer.save_checkpoint(
            output_dir, cur, start, end, freq,
            model, optimizer, lr_scheduler,
            train_loss=train_loss, eval_loss=eval_loss,
            train_metric_dict=train_metric_dict, eval_metric_dict=eval_metric_dict,
            output_file=output_file, pruner=pruner, **kwargs
        )

    @staticmethod
    def create_and_fill_np_array(start_or_end_logits: torch.Tensor, dataset, max_len: int):
        """
        Create and fill numpy array of size len_of_validation_data * max_length_of_output_tensor

        Args:
            start_or_end_logits(:obj:`tensor`):
                This is the output predictions of the model. We can only enter either start or end logits.
            eval_dataset: Evaluation dataset
            max_len(:obj:`int`):
                The maximum length of the output tensor. ( See the model.eval() part for more details )
        """

        step = 0

        # create a numpy array and fill it with -100.
        logits_concat = np.full((len(dataset), max_len), -100, dtype=np.float64)
        # Now since we have create an array now we will populate it with the outputs gathered using accelerator.gather
        for output_logit in start_or_end_logits:  # populate columns
            # We have to fill it such that we have to take the whole tensor and replace it on the newly created array
            # And after every iteration we have to change the step
            batch_size = output_logit.shape[0]
            cols = output_logit.shape[1]

            if step + batch_size < len(dataset):
                logits_concat[step : step + batch_size, :cols] = output_logit
            else:
                logits_concat[step:, :cols] = output_logit[: len(dataset) - step]
                # TODO: check this
                break

            step += batch_size

        return logits_concat
