import os

import torch
import torch.nn as nn

from typing import Dict, List, Sequence, Union, Tuple

from logging import Logger
from abc import ABCMeta, abstractmethod

from torch import device, Tensor
from torch.distributed import ReduceOp, all_reduce

from torch.nn.parallel import DataParallel as DP
from torch.nn.parallel import DistributedDataParallel as DDP

from deepspeed import DeepSpeedEngine, InferenceEngine

from utils.misc import is_seq_of

from engine.ckpt import CKPT_SAVER
from engine.hooks import HOOK, Hook, Priority


class BaseTrainer(metaclass=ABCMeta):
    """
    The base class of Trainer, a training helper.
    All subclasses should implement the following APIs:
        - ``run()``
        - ``train()``
        - ``eval()``
    """

    # Distribution wrapper, e.g. torch.nn.parallel.DistributedDataParallel
    DIST_CONTAINERS = (DP, DDP, DeepSpeedEngine, InferenceEngine)

    def __init__(
        self,
        model: nn.Module,
        logger: Logger, output_dir: str,
        log_freq: int = 10, save_freq: Union[int, List[int]] = 1,
        save_latest: bool = False, ckpt_savers: Tuple[Dict] = (dict(type='torch'),),
        num_steps_for_compute_metrics: int = 1, compute_metrics_in_last_step: bool = False
    ):
        # Model
        self.model = model
        if isinstance(model, DeepSpeedEngine):
            self.model = model.module
            self.deepspeed = model
        else:
            self.deepspeed = None
        
        self.distributed = torch.cuda.is_available() and torch.cuda.device_count() > 1

        # Log
        self.logger = logger
        # Frequency for print logs
        self.log_freq = log_freq

        # Output
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
        self.output_dir = output_dir
        # Frequency for saving checkpoints
        self.save_freq = save_freq
        # Whether to save the latest checkpoint
        self.save_latest = save_latest

        # Defines how to save checkpoints(use apis of torch, deepspeed, etc.)
        if ckpt_savers is None:
            ckpt_savers = [dict(type='torch')]
        if isinstance(ckpt_savers, dict):
            ckpt_savers = [ckpt_savers]
        self.ckpt_savers = [CKPT_SAVER.build(cfg) for cfg in ckpt_savers]

        # Hooks
        self._hooks: List[Hook] = []

        self.compute_metrics_in_last_step = compute_metrics_in_last_step
        self.num_steps_for_compute_metrics = num_steps_for_compute_metrics
    
    @property
    def device(self) -> device:
        """
        `torch.device`: The device on which the module is (assuming that all the module parameters are on the same
        device).
        """
        return self.get_parameter_device(self.model)
    
    @staticmethod
    def get_parameter_device(model: nn.Module):
        try:
            return next(model.parameters()).device
        except StopIteration:
            # For nn.DataParallel compatibility in PyTorch 1.5

            def find_tensor_attributes(module: nn.Module) -> List[Tuple[str, Tensor]]:
                tuples = [(k, v) for k, v in module.__dict__.items() if torch.is_tensor(v)]
                return tuples

            gen = model._named_members(get_members_fn=find_tensor_attributes)
            first_tuple = next(gen)

            return first_tuple[1].device

    @abstractmethod
    def run(self, data_container, pruner=None, **kwargs):
        pass

    @abstractmethod
    def train(self, epoch: int, model: nn.Module, dataloader, pruner=None, **kwargs):
        pass

    @abstractmethod
    def eval(self, epoch: int, model: nn.Module, dataloader, is_teacher=False, **kwargs):
        pass

    def has_hook(self, hook: Hook) -> bool:
        return hook in self._hooks

    def register_hook(self, hook: Hook, priority: Union[int, str, Priority] = 'NORMAL'):
        """
        Register a hook into the hook list.

        The hook will be inserted into a priority queue, with the specified
        priority (See :class:`Priority` for details of priorities).
        For hooks with the same priority, they will be triggered in the same
        order as they are registered.

        Args:
            hook (:obj:`Hook`): The hook to be registered.
            priority (int or str or :obj:`Priority`): Hook priority.
                Lower value means higher priority.
        """

        # i. Make sure that hook is an instance of 'Hook' class
        assert isinstance(hook, Hook), f"hook object must be instance of Hook class, but got: {type(hook)}"
        # ii. Checkout that 'priority' is a reserved attribute for hook
        if hasattr(hook, 'priority'):
            raise ValueError('"priority" is a reserved attribute for hooks')

        # iii. Set priority for hook
        priority_value = hook.set_priority(priority)

        # iv. Insert the hook to a sorted list(i.e. register the hook)
        for i in range(self.num_hooks, 0, -1):
            if priority_value >= self._hooks[i - 1].priority:
                self._hooks.insert(i, hook)
                break
        if not self.has_hook(hook):
            self._hooks.insert(0, hook)
        
        self.logger.info(f"-hook: {hook} has been registered.")
    
    def register_hook_from_cfg(self, hook_cfg):
        """
        Register a hook from a config dict.

        Args:
            hook_cfg (dict): Hook config. It should have at least key 'type' indicating its type.
            (better to has key 'priority' to indicate its priority)

        Note:
            The specific hook class to register should not use 'type' and
            'priority' arguments during initialization.
        """

        hook_cfg = hook_cfg.copy()
        # Note: if priority not set in config, 'NORMAL' will be used.
        priority = hook_cfg.pop('priority', 'NORMAL')
        hook = HOOK.build(hook_cfg)

        self.register_hook(hook, priority=priority)
    
    def register_training_hooks(self, hooks_cfg: List[dict]):
        """
        Register hooks for training.

        Example hooks like:
        +----------------------+-------------------------+
        | Hooks                | Priority                |
        +======================+=========================+
        | OptimizerHook        | VERY_HIGH (10)          |
        | LrSchedulerHook      | VERY_HIGH (10)          |
        +----------------------+-------------------------+
        | PrunerHook           | HIGH (30)               |
        +----------------------+-------------------------+
        | MetaHook             | ABOVE_NORMAL (40)       |
        +----------------------+-------------------------+
        | CheckpointHook       | NORMAL (50)             |
        +----------------------+-------------------------+
        | TimerHook            | LOW (70)                |
        +----------------------+-------------------------+
        | MemoryHook           | VERY_LOW (90)           |
        | LoggerHook           | VERY_LOW (90)           |
        | VisualHook           | VERY_LOW (90)           |
        +----------------------+-------------------------+

        Note: for hooks with the same priority, they will be triggered in the same order as they are registered.
        """

        if isinstance(hooks_cfg, dict):
            hooks_cfg = [hooks_cfg]
        elif not isinstance(hooks_cfg, Sequence):
            raise TypeError(f"hooks_cfg must be a sequence, but got: {type(hooks_cfg)}")
        assert is_seq_of(hooks_cfg, dict), f"hooks_cfg must be a sequence of dict, but got: {type(hooks_cfg)}[{type(hooks_cfg[0])}]"
    
        for hook_cfg in hooks_cfg:
            self.register_hook_from_cfg(hook_cfg)

    def call_hooks(self, fn_name):
        """
        Call all hooks in order.

        Args:
            fn_name (str): The function name in each hook to be called, e.g. "before_train_epoch".
        """

        if not self._hooks:
            self.logger.warning("No hook has been registered, please register at least one hook first.")
            return

        for hook in self._hooks:
            getattr(hook, fn_name)(self)

    def get_hook_info(self):
        """
        Get hooks info of all stages.
        """

        stage_hook_map = {stage: [] for stage in Hook.STAGES}
        for hook in self._hooks:
            for trigger_stage in hook.get_triggered_stages():
                stage_hook_map[trigger_stage].append(str(hook))

        stage_hook_infos = []
        for stage in Hook.STAGES:
            hook_infos = stage_hook_map[stage]
            if len(hook_infos) > 0:
                info = f'{stage}:\n'
                info += '\n'.join(hook_infos)
                info += '\n -------------------- '
                stage_hook_infos.append(info)

        return '\n'.join(stage_hook_infos)
    
    @property
    def model_unwrapped(self):
        # Naked model without any encapsulated(When in distributed training, model may be encapsulated by DDP)
        return self._unwrap_model(self.model)

    @property
    def num_hooks(self):
        return len(self._hooks)

    @classmethod
    def _unwrap_model(cls, model: nn.Module):
        """
        Extract a model from its distributed containers.

        Args:
            model (:obj:`torch.nn.Module`): The model to extract.

        Returns:
            :obj:`torch.nn.Module`: The extracted model.
        """

        while isinstance(model, cls.DIST_CONTAINERS):
            model = model.module

        return model

    @staticmethod
    def _all_reduce(metric_dict: dict, op=ReduceOp.SUM, group=None, async_op=False, device=None):
        """
        Reduces the tensor data across all machines in such a way that all get
        the final result.

        After the call ``tensor`` is going to be bitwise identical in all processes.

        Complex tensors are supported.

        Args:
            metric_dict (Dict[str: tensor]): A dict containing some tensors that will be reduced.
            op (optional): One of the values from
                           ``torch.distributed.ReduceOp``
                           enum. Specifies an operation used for element-wise reductions.
            group (ProcessGroup, optional): The process group to work on. If None,
                                            the default process group will be used.
            async_op (bool, optional): Whether this op should be an async op.

        Returns:
            A dict containing reduced tensors
        """

        metric_dict = {k: torch.tensor(v, device=device) for k, v in metric_dict.items()}
        return all_reduce(metric_dict, op=op, group=group, async_op=async_op)
