import math

from copy import deepcopy
from typing import Optional, Union

from torch.optim import Optimizer

from transformers.trainer_utils import SchedulerType
from transformers.optimization import TYPE_TO_SCHEDULER_FUNCTION as _type_to_scheduler_func

from .scheduler import get_constant_linear_schedule_with_warmup


# Note: must do deepcopy(instead copy) in case of modifying the original
TYPE_TO_SCHEDULER_FUNCTION = deepcopy(_type_to_scheduler_func)
TYPE_TO_SCHEDULER_FUNCTION.update(constant_linear=get_constant_linear_schedule_with_warmup)

ENUM_SHEDULER_TYPE = ('constant_linear',)


def build_lr_scheduler(optimizer, cfg, step_per_epoch):
    """
    Build lr scheduler.

    It should be a type as below:
        "polynomial",
        "linear", "constant_linear",
        "cosine", "cosine_with_restarts",
        "constant", "constant_with_warmup"
    """

    # Update steps of 1 epoch
    update_steps_per_epoch = math.ceil(step_per_epoch / cfg.trainer.grad_accumulation_steps)
    # Total update steps
    train_steps = (cfg.trainer.epochs - cfg.trainer.start_epoch) * update_steps_per_epoch
    # Total warmup steps
    if cfg.lr_scheduler.get('warmup_steps'):
        warmup_steps = cfg.lr_scheduler.warmup_steps
    elif cfg.lr_scheduler.get('warmup_epochs'):
        warmup_steps = cfg.lr_scheduler.warmup_epochs * update_steps_per_epoch
    else:
        warmup_steps = 0

    kwargs = {}

    scheduler_name = cfg.lr_scheduler.type.lower()
    if scheduler_name == 'cosine_with_restarts':
        kwargs['num_cycles'] = cfg.lr_scheduler.num_cycles
    if scheduler_name == 'constant_linear':
        kwargs['num_sparse_steps'] = (cfg.pruner.get('sparse_step') or train_steps) if cfg.train.prune else 0
        kwargs['min_factor'] = cfg.lr_scheduler.min_factor
    if scheduler_name == 'consine':
        kwargs['num_cycles'] = cfg.lr_scheduler.num_cycles

    return get_scheduler(
        scheduler_name,
        optimizer=optimizer,
        num_warmup_steps=warmup_steps,
        num_training_steps=train_steps,
        **kwargs
    ), train_steps


def get_scheduler(
    name: Union[str, SchedulerType],
    optimizer: Optimizer,
    num_warmup_steps: Optional[int] = None,
    num_training_steps: Optional[int] = None,
    **kwargs
):
    """
    Unified API to get any scheduler from its name.

    Args:
        name (:obj:`str` or `:obj:`SchedulerType`):
            The name of the scheduler to use.
        optimizer (:obj:`torch.optim.Optimizer`):
            The optimizer that will be used during training.
        num_warmup_steps (:obj:`int`, `optional`):
            The number of warmup steps to do. This is not required by all schedulers (hence the argument being
            optional), the function will raise an error if it's unset and the scheduler type requires it.
        num_training_steps (:obj:`int`, `optional`):
            The number of training steps to do. This is not required by all schedulers (hence the argument being
            optional), the function will raise an error if it's unset and the scheduler type requires it.
    """

    if name not in ENUM_SHEDULER_TYPE:
        name = SchedulerType(name)
    schedule_func = TYPE_TO_SCHEDULER_FUNCTION[name]

    if name == SchedulerType.CONSTANT:
        return schedule_func(optimizer)

    # All other schedulers require `num_warmup_steps`
    if num_warmup_steps is None:
        raise ValueError(f"{name} requires `num_warmup_steps`, please provide that argument.")

    if name == SchedulerType.CONSTANT_WITH_WARMUP:
        return schedule_func(optimizer, num_warmup_steps=num_warmup_steps)

    # All other schedulers require `num_training_steps`
    if num_training_steps is None:
        raise ValueError(f"{name} requires `num_training_steps`, please provide that argument.")

    return schedule_func(optimizer, num_warmup_steps=num_warmup_steps, 
                         num_training_steps=num_training_steps, **kwargs)
