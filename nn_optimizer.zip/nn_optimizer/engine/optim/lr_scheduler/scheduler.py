from torch.optim.lr_scheduler import LambdaLR


def get_constant_linear_schedule_with_warmup(
    optimizer, num_sparse_steps, num_training_steps, 
    num_warmup_steps=0, last_epoch=-1, min_factor=0.
):
    """
    Create a schedule with a learning rate that decreases linearly from the initial lr set in the optimizer to 0, after
    a warmup period during which it increases linearly from 0 to the initial lr set in the optimizer.

    Args:
        optimizer (:class:`~torch.optim.Optimizer`):
            The optimizer for which to schedule the learning rate.
        num_warmup_steps (:obj:`int`):
            The number of steps for the warmup phase.
        num_training_steps (:obj:`int`):
            The total number of training steps.
        last_epoch (:obj:`int`, `optional`, defaults to -1):
            The index of the last epoch when resuming training.
        min_factor (:obj:`float`, `optional`, defaults to 0.0):
            The minimum multiplicative factor.
    Return:
        :obj:`torch.optim.lr_scheduler.LambdaLR` with the appropriate schedule.
    """

    def lr_lambda(current_step: int):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        elif current_step < num_sparse_steps:
            return 1.
        else:
            return max(
                min_factor, 
                float(
                    num_training_steps - current_step) / 
                    float(max(1, num_training_steps - max(num_sparse_steps, num_warmup_steps))
                )
            )

    return LambdaLR(optimizer, lr_lambda, last_epoch)

