from torch.optim import SGD, Adam, AdamW

from utils.misc import is_seq_of
from .optimizer import ChildTuningAdamW


def set_weight_decay(model, skip=()):
    decay, no_decay = [], []
    
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
            
        if any(nd in name for nd in skip):
            no_decay.append(param)
        else:
            decay.append(param)
    
    return [{'params': decay}, {'params': no_decay, 'weight_decay': 0.}]


def build_optimizer(model, cfg):
    # Divide into decay & no-decay groups
    no_decay = model.no_decay() if hasattr(model, 'no_decay') else cfg.optimizer.no_decay_keywords
    if isinstance(no_decay, str):
        no_decay = [no_decay]
    assert is_seq_of(no_decay, str)
    
    params = set_weight_decay(model, skip=no_decay)

    # Set optimizer
    optimizer, opt_name = None, cfg.optimizer.type
    if opt_name.lower() == 'sgd':
        optimizer = SGD(params, lr=cfg.train.lr, 
                        momentum=cfg.optimizer.momentum, weight_decay=cfg.optimizer.weight_decay)
    elif opt_name.lower() == 'adam':
        optimizer = Adam(params, lr=cfg.train.lr, betas=cfg.optimizer.betas,
                         eps=cfg.optimizer.eps, weight_decay=cfg.optimizer.weight_decay)
    elif opt_name.lower() == 'adamw':
        optimizer = AdamW(params, lr=cfg.train.lr, betas=cfg.optimizer.betas,
                          eps=cfg.optimizer.eps, weight_decay=cfg.optimizer.weight_decay)
    elif opt_name.lower() == 'child_tuning_adamw':
        optimizer = ChildTuningAdamW(
            params, lr=cfg.train.lr, betas=cfg.optimizer.betas,
            eps=cfg.optimizer.eps, weight_decay=cfg.optimizer.weight_decay,
            reserve_p=cfg.optimizer.reverse_p, 
            mode=cfg.optimizer.mode
        )
    else:
        raise NotImplementedError(f"=> Current only support 'Adam', 'AdamW'\n")

    return optimizer
