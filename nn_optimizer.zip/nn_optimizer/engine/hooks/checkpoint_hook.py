from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='checkpoint')
class CheckpointHook(Hook):
    def after_eval_epoch(self, trainer):
        # Note: we don't save the checkpoint of teacher
        if getattr(trainer, 'is_teacher', False):
            return
        
        # Out of training stage, no need to save checkpoint
        if trainer.epoch >= trainer.end_epoch:
            return

        if trainer.save_latest:
            for ckpt_saver in trainer.ckpt_savers:
                ckpt_saver.save_latest(trainer)

        if self._is_time_to_save(trainer):
            for ckpt_saver in trainer.ckpt_savers:
                if trainer.pruner and trainer.pruner.TYPE=='bbcs':
                    trainer.pruner.sparse_model(adaptive_mask=False)
                    ckpt_saver.save(trainer)
                    trainer.pruner.recover()
                else:
                    ckpt_saver.save(trainer)

    def _is_time_to_save(self, trainer) -> bool:
        return not ((trainer.epoch - trainer.start_epoch + 1) % trainer.save_freq) or self.is_last_epoch(trainer) or trainer.get_best


@HOOK.register_module(name='step_based_checkpoint')
class StepBasedCheckpointHook(CheckpointHook):
    def __init__(self):
        self.ptr = 0

    def _is_time_to_save(self, trainer) -> bool:
        if self.ptr < len(trainer.save_freq) and trainer.global_step >= trainer.save_freq[self.ptr]:
            self.ptr += 1
            return True
        elif self.is_last_epoch(trainer) or trainer.get_best:
            return True
        else:
            return False


@HOOK.register_module(name='epoch_based_checkpoint')
class EpochBasedCheckpointHook(CheckpointHook):
    def __init__(self):
        self.ptr = 0

    def _is_time_to_save(self, trainer) -> bool:
        if self.ptr < len(trainer.save_freq) and trainer.epoch >= trainer.save_freq[self.ptr]:
            self.ptr += 1
            return True
        elif self.is_last_epoch(trainer) or trainer.get_best:
            return True
        else:
            return False


@HOOK.register_module(name='prune_based_checkpoint')
class PruneBasedCheckpointHook(CheckpointHook):
    def __init__(self):
        super().__init__()
        self.best = 0.

    def _is_time_to_save(self, trainer) -> bool:
        if trainer.global_step < trainer.pruner.stage_wise_steps[trainer.pruner.index][1]:
            self._reset(trainer)
            return False
        elif trainer.pruner.stage_wise_steps[trainer.pruner.index][1] <= trainer.global_step <= trainer.pruner.stage_wise_steps[trainer.pruner.index][2]:
            if trainer.pruner.best_metric > self.best:
                trainer.get_pruning_best = True
                self.best = trainer.pruner.best_metric
                return True
            else:
                return False
        elif self.is_last_epoch(trainer):
            return True
        else:
            return False

    def _reset(self, trainer):
        self.best = 0.
        trainer.get_pruning_best = False
