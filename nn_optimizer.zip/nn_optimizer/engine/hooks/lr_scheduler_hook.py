from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='lr_scheduler')
class LrSchedulerHook(Hook):
    def before_train_epoch(self, trainer):
        trainer.step_lr = []

    def after_train_iter(self, trainer):
        lr = trainer.optimizer.param_groups[0]['lr']
        trainer.step_lr.append(lr)

        # Note: lr schedule will be carried by pruner if purning
        if self._is_time_to_update(trainer) and trainer.pruner is None:
            trainer.lr_scheduler.step()

    def _is_time_to_update(self, trainer) -> bool:
        return self.every_n_steps(trainer, trainer.grad_accumulation_steps) or self.is_last_step(trainer)
