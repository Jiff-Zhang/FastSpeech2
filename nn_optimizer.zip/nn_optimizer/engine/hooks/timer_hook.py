import time

from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='timer')
class TimerHook(Hook):
    def before_run(self, trainer):
        self.total_begin = time.time()

        trainer.timer = {
            'data_time': 0.,
            'iter_time': 0.,
            'epoch_time': 0.,
            'total_time': 0.
        }
        trainer.logger.info(f"\nNote: auto setting trainer.timer to:\n{trainer.timer}\n")

    def before_epoch(self, trainer):
        self.epoch_begin = self.iter_begin = time.time()

    def before_iter(self, trainer):
        trainer.timer.update(data_time=time.time() - self.iter_begin)
        self.iter_begin = time.time()

    def after_iter(self, trainer):
        trainer.timer.update(iter_time=time.time() - self.iter_begin)
        self.iter_begin = time.time()

    def after_epoch(self, trainer):
        trainer.timer.update(epoch_time=time.time() - self.epoch_begin)

    def after_run(self, trainer):
        trainer.timer.update(total_time=time.time() - self.total_begin)
    
    def before_test_epoch(self, trainer):
        self.before_epoch(trainer)
    
    def before_test_iter(self, trainer):
        self.before_iter(trainer)
    
    def after_test_iter(self, trainer):
        self.after_iter(trainer)
    
    def after_test_epoch(self, trainer):
        self.after_epoch(trainer)
