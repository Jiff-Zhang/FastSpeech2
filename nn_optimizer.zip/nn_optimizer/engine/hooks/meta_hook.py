import os
import json
import torch
import collections
import numpy as np

from tqdm import tqdm
from copy import deepcopy
from statistics import mean
from abc import abstractmethod

from torch.distributed import ReduceOp

from data.nlp.tc_container import STR_LABEL_TO_CLS_ID

from utils.dist import all_reduce, is_master
from utils.meters import AverageMeter, ProgressMeter

from engine.hooks.hook import HOOK, Hook


class MetaHook(Hook):
    @abstractmethod
    def _generate_predictions(self, trainer):
        """
        Post-process the raw model outputs to generate formatted predictions, used for computing metrics.
        Note: sub-class must implement this method.
        """
        pass

    @abstractmethod
    def _gather_targets(self, trainer):
        """
        Gather targets, as preparation for computing metrics.
        """
        pass
    
    @abstractmethod
    def _compute_metric(self, trainer):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """
        pass
    
    @staticmethod
    def _all_reduce(metric_dict: dict, op=ReduceOp.SUM, group=None, async_op=False, device=None):
        """
        Reduces the tensor data across all machines in such a way that all get
        the final result.

        After the call ``tensor`` is going to be bitwise identical in all processes.

        Complex tensors are supported.

        Args:
            metric_dict (Dict[str: tensor]): A dict containing some tensors that will be reduced.
            op (optional): One of the values from
                           ``torch.distributed.ReduceOp``
                           enum. Specifies an operation used for element-wise reductions.
            group (ProcessGroup, optional): The process group to work on. If None,
                                            the default process group will be used.
            async_op (bool, optional): Whether this op should be an async op.

        Returns:
            A dict containing reduced tensors
        """

        metric_dict = {k: torch.tensor(v, device=device) for k, v in metric_dict.items()}
        return all_reduce(metric_dict, op=op, group=group, async_op=async_op)

    def _is_main_process(self, trainer):
        if hasattr(trainer, 'rank'):
            return not trainer.rank
        else:
            return is_master()


class EpochMetaHook(MetaHook):
    def before_run(self, trainer):
        trainer.meta = {}

        if trainer.do_train:
            trainer.meta.update(
                best_metric=0.,
                all_step_lr=[],
                train_epoch_loss=[],
                train_epoch_metric=[]
            )
        if trainer.do_eval:
            trainer.meta.update(
                best_metric=0.,
                eval_epoch_loss=[],
                eval_epoch_metric=[]
            )
        if trainer.kd:
            trainer.meta.update(teacher_eval_epoch_loss=[], teacher_eval_epoch_metric=[])

    def before_epoch(self, trainer):
        if hasattr(trainer, 'epoch_loss'):
            del trainer.epoch_loss
        if hasattr(trainer, 'epoch_metrics'):
            del trainer.epoch_metrics
        if hasattr(trainer, 'cur_metric'):
            del trainer.cur_metric

        trainer.loss_meter = AverageMeter('loss', fmt=':.4f')
        trainer.metric_meters = [AverageMeter(metric_name, fmt=':.3f') for metric_name in trainer.metric_identifier]
        trainer.progress_meter = ProgressMeter(
            len(trainer.dataloader), [trainer.loss_meter] + trainer.metric_meters, 
            prefix=f"{trainer.mode} epoch[{(trainer.epoch):0>3}/{trainer.end_epoch:0>3}]"
        )

        # When in multiprocess case, the last batch may have duplicated samples.
        # So, we use this counter for identify them.
        if trainer.distributed:
            self.samples_seen = 0
    
    def before_iter(self, trainer):
        if hasattr(trainer, 'predictions'):
            del trainer.predictions
        if hasattr(trainer, 'targets'):
            del trainer.targets
    
    def after_iter(self, trainer):
        assert hasattr(trainer, 'loss_value'), "loss_value must be set in trainer first."
        # Loss
        loss_dict = {'loss': trainer.loss_value}

        # In case intermediate gradients
        with torch.no_grad():
            # Metrics
            # Post-process the raw model outputs to form the formatted predictions
            trainer.predictions = self._generate_predictions(trainer)
            # Gather targets as preparation for computing metrics
            trainer.targets = self._gather_targets(trainer)
            # Compute metrics
            # Note: in some cases, they are not compute metrics every iteration,
            # thus 'metric_dict' will be None.
            metric_dict = self._compute_metric(trainer)

        # Gather losses and metrics among all process
        if trainer.distributed:
            loss_dict = self._all_reduce(loss_dict, device=trainer.device)
            if self.every_n_steps(trainer, trainer.num_steps_for_compute_metrics):
                assert metric_dict is not None, "'metric_dict' should not be None when the step for computing metrics meets."
                metric_dict = self._all_reduce(metric_dict, device=trainer.device)
        
        # Update values to meters
        trainer.loss_meter.update(loss_dict['loss'])
        if self.every_n_steps(trainer, trainer.num_steps_for_compute_metrics):
            assert metric_dict is not None, "'metric_dict' should not be None when the step for computing metrics meets."
            for metric_meter in trainer.metric_meters:
                metric_meter.update(metric_dict[metric_meter.name])
    
    def after_train_epoch(self, trainer):
        assert hasattr(trainer, 'step_lr'), "LrSchedulerHook should set the attribute 'step_lr' to trainer."
        trainer.meta['all_step_lr'].extend(trainer.step_lr)

        trainer.epoch_loss = getattr(trainer.loss_meter, 'avg')
        trainer.meta['train_epoch_loss'].append(trainer.epoch_loss)

        trainer.epoch_metrics = {metric_meter.name: getattr(metric_meter, 'avg') for metric_meter in trainer.metric_meters}
        trainer.meta['train_epoch_metric'].append(trainer.epoch_metrics)
    
    def before_eval_epoch(self, trainer):
        # Reset best state when it is not teacher
        if not getattr(trainer, 'is_teacher', False):
            trainer.get_best = False

        self.before_epoch(trainer)
    
    def after_eval_epoch(self, trainer):
        trainer.epoch_loss = getattr(trainer.loss_meter, 'avg')
        trainer.epoch_metrics = {metric_meter.name: getattr(metric_meter, 'avg') for metric_meter in trainer.metric_meters}

        # Note: teacher will also do evaluation, so we should distinguish between model & teacher
        if not getattr(trainer, 'is_teacher', False):
            trainer.meta['eval_epoch_loss'].append(trainer.epoch_loss)
            trainer.meta['eval_epoch_metric'].append(trainer.epoch_metrics)

            trainer.cur_metric = mean([trainer.epoch_metrics.get(metric_key, 0.) for metric_key in trainer.metric_identifier])
            prev_best_metric = trainer.meta['best_metric']
            trainer.get_best = trainer.cur_metric > prev_best_metric
            trainer.meta.update(best_metric=max(prev_best_metric, trainer.cur_metric))
        else:
            trainer.meta['teacher_eval_epoch_loss'].append(trainer.epoch_loss)
            trainer.meta['teacher_eval_epoch_metric'].append(trainer.epoch_metrics)


@HOOK.register_module(name='img_cls_meta')
class ImgClsMetaHook(EpochMetaHook):
    def _generate_predictions(self, trainer):
        """
        Post-process the raw model outputs to generate formatted predictions, used for computing metrics.
        Note: sub-class must implement this method.
        """
        return trainer.outputs
    
    def _gather_targets(self, trainer):
        return trainer.batch[1].to(trainer.device)
    
    def _compute_metric(self, trainer):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """

        metric_dict = trainer.metric_computor(
            trainer.predictions, trainer.targets,
            topk=trainer.metric_topk
        )
        return metric_dict


@HOOK.register_module(name='text_cls_meta')
class TextClsMetaHook(EpochMetaHook):
    def before_test_epoch(self, trainer):
        trainer.all_example_id = []
        trainer.all_predicted_cls_id = []
    
    def after_test_iter(self, trainer):
        example_ids = trainer.batch["id"]
        # In case intermediate gradients
        with torch.no_grad():
            # Metrics
            # Post-process the raw model outputs to form the formatted predictions
            predicted_cls_ids = self._generate_predictions(trainer)

        # Gather a batch of results of all processes
        if trainer.accelerator is not None:
            example_ids = trainer.accelerator.gather(example_ids)
            predicted_cls_ids = trainer.accelerator.gather(predicted_cls_ids)
        assert len(example_ids) == len(predicted_cls_ids), \
            f"example_ids len:{len(example_ids)} != predicted_cls_ids len:{len(predicted_cls_ids)}"

        trainer.all_example_id.append(example_ids)
        trainer.all_predicted_cls_id.append(predicted_cls_ids)
    
    def after_test_epoch(self, trainer):
        if not trainer.is_regression:
            cls_name_to_int_label = STR_LABEL_TO_CLS_ID.get(trainer.task_name, {})
            # Map int label to cls name
            int_label_to_cls_name = {i: n for n, i in cls_name_to_int_label.items()}
            # int_label_to_cls_name = {i: n for i, n in enumerate(trainer.label_list)}

            # Map predicted cls id to int or str label
            cls_id_to_int_or_str_label = trainer.model_unwrapped.config.id2label
            # Map predicted cls id to cls name
            cls_id_to_cls_name = {
                cls_id: label if isinstance(label, str) else int_label_to_cls_name.get(label) 
                for cls_id, label in cls_id_to_int_or_str_label.items()
            }

        trainer.all_example_id = torch.concat(trainer.all_example_id)
        trainer.all_predicted_cls_id = torch.concat(trainer.all_predicted_cls_id)
        assert len(trainer.all_example_id) == len(trainer.all_predicted_cls_id), \
            f"example id len:{len(trainer.all_example_id)} != predicted cls id len:{len(trainer.all_predicted_cls_id)}"
        
        if len(trainer.all_example_id) > len(trainer.examples):
            trainer.logger.warning(
                f"num predicted examples:{len(trainer.all_example_id)} truncated to num examples:{len(trainer.examples)}, "
                f"this may happened on sample padding."
            )
            trainer.all_example_id = trainer.all_example_id[:len(trainer.examples)]
            trainer.all_predicted_cls_id = trainer.all_predicted_cls_id[:len(trainer.examples)]

        assert len(trainer.all_example_id) == len(trainer.examples), \
            f"example id len:{len(trainer.all_example_id)} != examples len:{len(trainer.examples)}"
        assert trainer.all_example_id.max().item() < len(trainer.examples), \
            f"max example id:{trainer.all_example_id.max().item()} >= examples len:{len(trainer.examples)}"
        
        trainer.prediction_results = []
        for example_id, predicted_result in zip(trainer.all_example_id, trainer.all_predicted_cls_id):
            # In case to damage the original data sample
            predicted_example = deepcopy(trainer.examples[example_id.item()])
            predicted_example.update(
                prediction=predicted_result.item() if trainer.is_regression 
                else cls_id_to_cls_name.get(predicted_result.item())
            )
            trainer.prediction_results.append(predicted_example)

        # Save prediction results
        # Only main process need to do writing operation.
        if trainer.write_out_predictions and self._is_main_process(trainer):
            if not os.path.isdir(trainer.output_dir):
                raise EnvironmentError(f"{trainer.output_dir} is not a directory.")
            
            import json
            dst = os.path.join(trainer.output_dir, f"{trainer.task_name}_pred.json")
            with open(dst, "a") as f:
                f.write(json.dumps(trainer.prediction_results, indent=4) + "\n")
            trainer.logger.info(f"Note: prediction results saved to:{dst}")
        
        del trainer.all_example_id, trainer.all_predicted_cls_id

    def _generate_predictions(self, trainer):
        return trainer.outputs.logits.argmax(dim=-1) if not trainer.is_regression \
            else trainer.outputs.logits.squeeze()
        
    def _gather_targets(self, trainer):
        return trainer.batch['labels']

    def _compute_metric(self, trainer):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """

        predictions, references = trainer.predictions, trainer.batch['labels']
        # Ensure that references & predictions remain on the same device
        references = references.to(predictions.device)
        if trainer.distributed:
            predictions, references = trainer.accelerator.gather((predictions, references))
            if self.is_last_step(trainer):
                # The last batch may have duplicates when in multiprocess case
                num_samples_wo_duplicated = len(trainer.dataloader.dataset) - self.samples_seen
                # For the convenience of debugging
                self.num_samples_duplicated = references.size(0) - num_samples_wo_duplicated
                self.samples_seen = len(trainer.dataloader.dataset)

                predictions = predictions[:num_samples_wo_duplicated]
                references = references[:num_samples_wo_duplicated]
            else:
                self.samples_seen += references.size(0)

        trainer.metric_computor.add_batch(
            predictions=predictions,
            references=references
        )
        
        if self.every_n_steps(trainer, trainer.num_steps_for_compute_metrics):
            return trainer.metric_computor.compute()
        else:
            return None


@HOOK.register_module(name='seq2seq_text_cls_meta')
class Seq2SeqTextClsMetaHook(TextClsMetaHook):
    def after_train_iter(self, trainer):
        # Note: we don't do evaluation after each train step cuz it cost too much time.
        
        assert hasattr(trainer, 'loss_value'), "loss_value must be set in trainer first."

        # Loss
        loss_dict = {'loss': trainer.loss_value}
        # Gather losses and metrics among all process
        if trainer.distributed:
            loss_dict = self._all_reduce(loss_dict, device=trainer.device)

        # Update values to meters
        trainer.loss_meter.update(loss_dict['loss'])
    
    def after_test_iter(self, trainer):
        example_ids = trainer.batch["id"]
        # In case intermediate gradients
        with torch.no_grad():
            # Metrics
            # Post-process the raw model outputs to form the formatted predictions
            predicted_cls_names = self._generate_predictions(trainer)
        
        # When it is a regression task(e.g. stsb),
        # seq2seq model aim to regress values with str format(instead of predicting class names)
        if trainer.is_regression:
            predicted_str_values = predicted_cls_names
            predicted_float_values = []
            for str_v in predicted_str_values:
                try:
                    predicted_float_values.append(float(str_v.strip()))
                except:
                    predicted_float_values.append(-1.0)
                    trainer.logger.warning(
                        f"model predicted value:{str_v.strip()} not belong to float type, "
                        f"use -1.0 instead."
                    )
            
            predicted_cls_ids = torch.tensor(
                predicted_float_values,
                device=trainer.batch["input_ids"].device
            )
        else:
            # Map class name to id
            cls_name_to_id = STR_LABEL_TO_CLS_ID.get(trainer.task_name, {})
            # cls_name_to_id = {n: i for i, n in enumerate(trainer.label_list)}
            predicted_cls_ids = torch.tensor(
                [cls_name_to_id.get(cls_name.strip(), -1) for cls_name in predicted_cls_names],
                dtype=trainer.batch["class_id"].dtype,
                device=trainer.batch["class_id"].device,
            )

        # Gather a batch of results of all processes
        if trainer.accelerator is not None:
            example_ids = trainer.accelerator.gather(example_ids)
            predicted_cls_ids = trainer.accelerator.gather(predicted_cls_ids)
        assert len(example_ids) == len(predicted_cls_ids), \
            f"example_ids len:{len(example_ids)} != predicted_cls_ids len:{len(predicted_cls_ids)}"

        trainer.all_example_id.append(example_ids)
        trainer.all_predicted_cls_id.append(predicted_cls_ids)
    
    def after_test_epoch(self, trainer):
        if not trainer.is_regression:
            cls_name_to_id = STR_LABEL_TO_CLS_ID.get(trainer.task_name, {})
            id_to_cls_name = {i: n for n, i in cls_name_to_id.items()}
            # id_to_cls_name = {i: n for i, n in enumerate(trainer.label_list)}

        trainer.all_example_id = torch.concat(trainer.all_example_id)
        trainer.all_predicted_cls_id = torch.concat(trainer.all_predicted_cls_id)
        assert len(trainer.all_example_id) == len(trainer.all_predicted_cls_id), \
            f"example id len:{len(trainer.all_example_id)} != predicted cls id len:{len(trainer.all_predicted_cls_id)}"
        
        if len(trainer.all_example_id) > len(trainer.examples):
            trainer.logger.warning(
                f"num predicted examples:{len(trainer.all_example_id)} truncated to num examples:{len(trainer.examples)}, "
                f"this may happened on sample padding."
            )
            trainer.all_example_id = trainer.all_example_id[:len(trainer.examples)]
            trainer.all_predicted_cls_id = trainer.all_predicted_cls_id[:len(trainer.examples)]
            
        assert len(trainer.all_example_id) == len(trainer.examples), \
            f"example id len:{len(trainer.all_example_id)} != examples len:{len(trainer.examples)}"
        assert trainer.all_example_id.max().item() < len(trainer.examples), \
            f"max example id:{trainer.all_example_id.max().item()} >= examples len:{len(trainer.examples)}"
        
        trainer.prediction_results = []
        for example_id, predicted_result in zip(trainer.all_example_id, trainer.all_predicted_cls_id):
            # In case to damage the original data sample
            predicted_example = deepcopy(trainer.examples[example_id.item()])
            predicted_example.update(
                prediction=predicted_result.item() if trainer.is_regression 
                else id_to_cls_name.get(predicted_result.item())
            )
            trainer.prediction_results.append(predicted_example)

        # Save prediction results
        # Only main process need to do writing operation.
        if trainer.write_out_predictions and self._is_main_process(trainer):
            if not os.path.isdir(trainer.output_dir):
                raise EnvironmentError(f"{trainer.output_dir} is not a directory.")
            
            import json
            dst = os.path.join(trainer.output_dir, f"{trainer.task_name}_pred.json")
            with open(dst, "a") as f:
                f.write(json.dumps(trainer.prediction_results, indent=4) + "\n")
            trainer.logger.info(f"Note: prediction results saved to:{dst}")
        
        del trainer.all_example_id, trainer.all_predicted_cls_id

    def _generate_predictions(self, trainer):
        gen_kwargs = {
                "num_beams": trainer.generation_num_beams,
                "max_length": trainer.generation_max_length,
                "synced_gpus": True if getattr(trainer, 'deepspeed', None) else False
        }
        model_input_names = trainer.tokenizer.model_input_names if hasattr(trainer, 'tokenizer') else ["input_ids"]
        generation_inputs = {k: v for k, v in trainer.batch_for_model.items() if k in model_input_names}
        
        # Note: in distributed training, 'DistributedDataParallel' does not inherit 'generate()' methods by seq2seq models
        # So we should unwrap the model here.
        if not getattr(trainer, 'is_teacher', False):
            generated_tokens = trainer.model_unwrapped.generate(
                **generation_inputs,
                **gen_kwargs
            )
        else:
            generated_tokens = trainer._unwrap_model(trainer.teacher).generate(
                **generation_inputs,
                **gen_kwargs
            )

        # Decode the predicted tokens.
        predictions = trainer.tokenizer.batch_decode(
            generated_tokens,
            skip_special_tokens=True
        )

        return predictions
    
    def _gather_targets(self, trainer):
        return trainer.batch["class_id"]
    
    def _compute_metric(self, trainer):
        """
        Compute metrics according to the predictions & references,
        the regular for computing metrics defined by metric_computor.
        """

        cls_name_to_id = STR_LABEL_TO_CLS_ID.get(trainer.task_name, {})
        predicted_cls_ids = torch.tensor(
            [cls_name_to_id.get(predicted_cls_name.strip(), -1) for predicted_cls_name in trainer.predictions],
            dtype=trainer.targets.dtype,
            device=trainer.targets.device,
        )

        metric = trainer.metric_computor.compute(
            predictions=trainer.accelerator.gather(predicted_cls_ids) if trainer.accelerator is not None else predicted_cls_ids,
            references=trainer.accelerator.gather(trainer.targets) if trainer.accelerator is not None else trainer.targets
        )
    
        return metric


@HOOK.register_module(name='span_mlm_meta')
class SpanMLMMetaHook(EpochMetaHook):
    def _generate_predictions(self, trainer):
        return trainer.outputs.logits.argmax(dim=-1)
    
    def _gather_targets(self, trainer):
        return trainer.batch['labels']

    def _compute_metric(self, trainer):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """

        trainer.metric_computor.add_batch(
            # Note: we should gather all processes' results
            predictions=trainer.accelerator.gather(trainer.predictions.flatten()) if trainer.accelerator is not None else trainer.predictions.flatten(),
            references=trainer.accelerator.gather(trainer.targets.flatten()) if trainer.accelerator is not None else trainer.targets.flatten()
        )
        metric = trainer.metric_computor.compute()

        return metric


@HOOK.register_module(name='squad_meta')
class SquadMetaHook(EpochMetaHook):
    def before_eval_epoch(self, trainer):
        super().before_eval_epoch(trainer)

        trainer.all_start_logits = []
        trainer.all_end_logits = []

    def after_iter(self, trainer):
        assert hasattr(trainer, 'loss_value'), "loss_value must be set in trainer first."
        loss_dict = {'loss': trainer.loss_value}
        # Gather losses among all process
        if trainer.distributed:
            loss_dict = self._all_reduce(loss_dict, device=trainer.device)

        trainer.loss_meter.update(loss_dict['loss'])

    def after_eval_iter(self, trainer):
        self.after_iter(trainer)

        start_logits = trainer.outputs.start_logits
        end_logits = trainer.outputs.end_logits

        # Necessary to pad predictions and labels for being gathered
        if not trainer.pad_to_max_seq_length and trainer.accelerator is not None:
            start_logits = trainer.accelerator.pad_across_processes(start_logits, dim=1, pad_index=-100)
            end_logits = trainer.accelerator.pad_across_processes(end_logits, dim=1, pad_index=-100)
        if trainer.accelerator is not None:
            # Gather all process results
            start_logits = trainer.accelerator.gather(start_logits)
            end_logits = trainer.accelerator.gather(end_logits)

        trainer.all_start_logits.append(start_logits.cpu().numpy())
        trainer.all_end_logits.append(end_logits.cpu().numpy())

        # Note: When it is the last step of a epoch, we collection all predictions & metrics,
        # the reason we do this here but not 'after_eval_epoch' cuz PrunerHook, whose prioriy is
        # higher, need to get the metrics in 'after_eval epoch'.
        if self.is_last_step(trainer):

            def _create_and_fill_np_array(start_or_end_logits: torch.Tensor, dataset, max_len: int):
                """
                Create and fill numpy array of size len_of_validation_data * max_length_of_output_tensor

                Args:
                    start_or_end_logits(:obj:`tensor`):
                        This is the output predictions of the model. We can only enter either start or end logits.
                    eval_dataset: Evaluation dataset
                    max_len(:obj:`int`):
                        The maximum length of the output tensor. ( See the model.eval() part for more details )
                """

                step = 0
                # create a numpy array and fill it with -100.
                logits_concat = np.full((len(dataset), max_len), -100, dtype=np.float64)

                # Now since we have create an array now we will populate it with the outputs gathered using accelerator.gather
                for output_logit in start_or_end_logits:  # populate columns
                    # We have to fill it such that we have to take the whole tensor and replace it on the newly created array
                    # And after every iteration we have to change the step
                    batch_size = output_logit.shape[0]
                    cols = output_logit.shape[1]

                    if step + batch_size < len(dataset):
                        logits_concat[step : step + batch_size, :cols] = output_logit
                    else:
                        logits_concat[step:, :cols] = output_logit[:(len(dataset) - step)]
                        # TODO: check this
                        break

                    step += batch_size

                return logits_concat

            # Get the max_length of the tensor
            max_len = max([x.shape[1] for x in trainer.all_start_logits])

            # Concatenate the numpy array
            trainer.all_start_logits = _create_and_fill_np_array(trainer.all_start_logits, trainer.features, max_len)
            trainer.all_end_logits = _create_and_fill_np_array(trainer.all_end_logits, trainer.features, max_len)

            # Note: this predictions & metrics are the avg result among all processes
            trainer.predictions = self._generate_predictions(trainer)
            trainer.targets = self._gather_targets(trainer)
            metric_dict = self._compute_metric(trainer)
            for metric_meter in trainer.metric_meters:
                metric_meter.update(metric_dict[metric_meter.name])

    def _generate_predictions(self, trainer):
        """
        Post-process the raw model outputs to generate formatted predictions, used for computing metrics.
        
        Post-processes the predictions of a question-answering model to convert them to answers that are substrings of the
        original contexts. This is the base postprocessing functions for models that only return start and end logits.
        Args:
            examples: The non-preprocessed dataset (see the main script for more information).
            features: The processed dataset (see the main script for more information).
            predictions (:obj:`Tuple[np.ndarray, np.ndarray]`):
                The predictions of the model: two arrays containing the start logits and the end logits respectively. Its
                first dimension must match the number of elements of :obj:`features`.
            version_2_with_negative (:obj:`bool`, `optional`, defaults to :obj:`False`):
                Whether or not the underlying dataset contains examples with no answers.
            n_best_size (:obj:`int`, `optional`, defaults to 20):
                The total number of n-best predictions to generate when looking for an answer.
            max_answer_length (:obj:`int`, `optional`, defaults to 30):
                The maximum length of an answer that can be generated. This is needed because the start and end predictions
                are not conditioned on one another.
            null_score_diff_threshold (:obj:`float`, `optional`, defaults to 0):
                The threshold used to select the null answer: if the best answer has a score that is less than the score of
                the null answer minus this threshold, the null answer is selected for this example (note that the score of
                the null answer for an example giving several features is the minimum of the scores for the null answer on
                each feature: all features must be aligned on the fact they `want` to predict a null answer).
                Only useful when :obj:`version_2_with_negative` is :obj:`True`.
            output_dir (:obj:`str`, `optional`):
                If provided, the dictionaries of predictions, n_best predictions (with their scores and logits) and, if
                :obj:`version_2_with_negative=True`, the dictionary of the scores differences between best and null
                answers, are saved in `output_dir`.
            prefix (:obj:`str`, `optional`):
                If provided, the dictionaries mentioned above are saved with `prefix` added to their names.
            log_level (:obj:`int`, `optional`, defaults to ``logging.WARNING``):
                ``logging`` log level (e.g., ``logging.WARNING``)
        """

        if len(trainer.all_start_logits) != len(trainer.features):
            raise ValueError(f"Got {len(trainer.all_start_logits)} predictions and {len(trainer.eatures)} features.")
        if len(trainer.all_end_logits) != len(trainer.features):
            raise ValueError(f"Got {len(trainer.all_end_logits)} predictions and {len(trainer.features)} features.")

        # Build a map example to its corresponding features.
        example_id_to_index = {k: i for i, k in enumerate(trainer.examples["id"])}

        features_per_example = collections.defaultdict(list)
        for i, feature in enumerate(trainer.features):
            features_per_example[example_id_to_index[feature["example_id"]]].append(i)

        # The dictionaries we have to fill.
        all_predictions = collections.OrderedDict()
        all_nbest_json = collections.OrderedDict()
        if trainer.version_2_with_negative:
            scores_diff_json = collections.OrderedDict()

        # Log.
        trainer.logger.info(f"Post-processing {len(trainer.examples)} example predictions splited into {len(trainer.features)} features.")
        
        # Loop over all the examples
        for example_index, example in enumerate(tqdm(trainer.examples)):
            # Those are the indices of the features associated to the current example.
            feature_indices = features_per_example[example_index]

            min_null_prediction = None
            prelim_predictions = []

            # Looping through all the features associated to the current example.
            for feature_index in feature_indices:
                # We grab the predictions of the model for this feature.
                start_logits = trainer.all_start_logits[feature_index]
                end_logits = trainer.all_end_logits[feature_index]

                # This is what will allow us to map some the positions in our logits 
                # to span of texts in the original context.
                offset_mapping = trainer.features[feature_index]["offset_mapping"]
                # Optional `token_is_max_context`, if provided we will remove answers that 
                # do not have the maximum context available in the current feature.
                token_is_max_context = trainer.features[feature_index].get("token_is_max_context", None)

                # Update minimum null prediction.
                # Logits of cls_token
                feature_null_score = start_logits[0] + end_logits[0]
                if min_null_prediction is None or min_null_prediction["score"] > feature_null_score:
                    min_null_prediction = {
                        "offsets": (0, 0),
                        "score": feature_null_score,
                        "start_logit": start_logits[0],
                        "end_logit": end_logits[0],
                    }

                # Go through all possibilities for the `n_best_size` greater start and end logits.
                start_indexes = np.argsort(start_logits)[-1 : -trainer.n_best_size - 1 : -1].tolist()
                end_indexes = np.argsort(end_logits)[-1 : -trainer.n_best_size - 1 : -1].tolist()
                for start_index in start_indexes:
                    for end_index in end_indexes:
                        # Don't consider out-of-scope answers, either because the indices are out of bounds 
                        # or correspond to part of the input_ids that are not in the context(in which case offset_mapping is None).
                        if (
                            start_index >= len(offset_mapping)
                            or end_index >= len(offset_mapping)
                            or offset_mapping[start_index] is None
                            or offset_mapping[end_index] is None
                        ):
                            continue

                        # Don't consider answers with a length that is either < 0 or > max_answer_length.
                        if end_index < start_index or end_index - start_index + 1 > trainer.max_answer_length:
                            continue

                        # Don't consider answer that don't have the maximum context available 
                        # (if such information is provided).
                        if token_is_max_context is not None and not token_is_max_context.get(str(start_index), False):
                            continue

                        prelim_predictions.append(
                            {
                                "offsets": (offset_mapping[start_index][0], offset_mapping[end_index][1]),
                                "score": start_logits[start_index] + end_logits[end_index],
                                "start_logit": start_logits[start_index],
                                "end_logit": end_logits[end_index],
                            }
                        )

            if trainer.version_2_with_negative:
                # Add the minimum null prediction
                null_score = min_null_prediction["score"]
                prelim_predictions.append(min_null_prediction)

            # Only keep the best `n_best_size` predictions.
            predictions = sorted(prelim_predictions, key=lambda x: x["score"], reverse=True)[:trainer.n_best_size]
            # Add back the minimum null prediction if it was removed because of its low score.
            if trainer.version_2_with_negative and not any(p["offsets"] == (0, 0) for p in predictions):
                predictions.append(min_null_prediction)

            # Use the offsets to gather the answer text in the original context.
            context = example["context"]
            for pred in predictions:
                offsets = pred.pop("offsets")
                pred["text"] = context[offsets[0] : offsets[1]]

            # In the very rare edge case we have not a single non-null prediction,
            # we create a fake prediction to avoid failure.
            if not len(predictions) or (len(predictions) == 1 and predictions[0]["text"] == ""):
                predictions.insert(0, {"text": "empty", "start_logit": 0.0, "end_logit": 0.0, "score": 0.0})

            # Compute the softmax of all scores 
            # (we do it with numpy to stay independent from torch/tf in this file, using the LogSumExp trick).
            scores = np.array([pred.pop("score") for pred in predictions])
            exp_scores = np.exp(scores - np.max(scores))
            probs = exp_scores / exp_scores.sum()
            # Include the probabilities in our predictions.
            for prob, pred in zip(probs, predictions):
                pred["probability"] = prob

            # Pick the best prediction. If the null answer is not possible, this is easy.
            if not trainer.version_2_with_negative:
                all_predictions[example["id"]] = predictions[0]["text"]
            else:
                # Otherwise we first need to find the best non-empty prediction.
                i = 0
                while predictions[i]["text"] == "":
                    i += 1

                best_non_null_pred = predictions[i]
                # Then we compare to the null prediction using the threshold.
                score_diff = null_score - best_non_null_pred["start_logit"] - best_non_null_pred["end_logit"]
                scores_diff_json[example["id"]] = float(score_diff)  # To be JSON-serializable.
                if score_diff > trainer.null_score_diff_threshold:
                    all_predictions[example["id"]] = ""
                else:
                    all_predictions[example["id"]] = best_non_null_pred["text"]

            # Make `predictions` JSON-serializable by casting np.float back to float.
            all_nbest_json[example["id"]] = [
                {k: (float(v) if isinstance(v, (np.float16, np.float32, np.float64)) else v) for k, v in pred.items()}
                for pred in predictions
            ]
        
        # Write out prediction results to files, but only main process will do this
        if self._is_main_process(trainer):
            if not os.path.isdir(trainer.output_dir):
                raise EnvironmentError(f"{trainer.output_dir} is not a directory.")
            dst_dir = os.path.join(trainer.output_dir, 'predictions')
            os.makedirs(dst_dir, exist_ok=True)

            prefix_info = f"{trainer.stage}_" if trainer.stage is not None else ""
            prefix_info += f"epoch{trainer.epoch}_"

            prediction_file = os.path.join(dst_dir, f"{prefix_info}predictions.json")
            trainer.logger.info(f"=> Saving predictions to {prediction_file}.\n")
            with open(prediction_file, "a") as writer:
                writer.write(json.dumps(all_predictions, indent=4) + "\n")

            nbest_file = os.path.join(dst_dir, f"{prefix_info}nbest_predictions.json")
            trainer.logger.info(f"=> Saving nbest_preds to {nbest_file}.\n")
            with open(nbest_file, "a") as writer:
                writer.write(json.dumps(all_nbest_json, indent=4) + "\n")

            if trainer.version_2_with_negative:
                null_odds_file = os.path.join(dst_dir, f"{prefix_info}null_odds.json")
                trainer.logger.info(f"=> Saving null_odds to {null_odds_file}.\n")
                with open(null_odds_file, "a") as writer:
                    writer.write(json.dumps(scores_diff_json, indent=4) + "\n")

        # Format the result to the format the metric expects.
        if trainer.version_2_with_negative:
            formatted_predictions = [
                {"id": k, "prediction_text": v, "no_answer_probability": 0.0} for k, v in all_predictions.items()
            ]
        else:
            formatted_predictions = [{"id": k, "prediction_text": v} for k, v in all_predictions.items()]

        return formatted_predictions
    
    def _gather_targets(self, trainer):
        return [{"id": example["id"], "answers": example[trainer.answer_column_name]} for example in trainer.examples]

    def _compute_metric(self, trainer):
        """
        Compute metrics according to the predictions & targets,
        the regular for computing metrics defined by metric_computor.
        """

        assert len(trainer.predictions) == len(trainer.targets)
        return trainer.metric_computor.compute(predictions=trainer.predictions, references=trainer.targets)


@HOOK.register_module(name='seq2seq_qa_meta')
class Seq2SeqQAMetaHook(SquadMetaHook):
    def before_eval_epoch(self, trainer):
        trainer.all_generated_tokens = []
        super().before_eval_epoch(trainer)

        # These will not output by Seq2seq models
        if hasattr(trainer, 'all_start_logits'):
            del trainer.all_start_logits
        if hasattr(trainer, 'all_end_logits'):
            del trainer.all_end_logits

    def after_eval_iter(self, trainer):
        super().after_iter(trainer)

        def _pad_tensors_to_max_len(tensor, max_length):
            if trainer.tokenizer is not None and hasattr(trainer.tokenizer, "pad_token_id"):
                # If PAD token is not defined at least EOS token has to be defined
                pad_token_id = (
                    trainer.tokenizer.pad_token_id if trainer.tokenizer.pad_token_id is not None else trainer.tokenizer.eos_token_id
                )
            else:
                if trainer.model_unwrapped.config.pad_token_id is not None:
                    pad_token_id = trainer.model_unwrapped.config.pad_token_id
                else:
                    raise ValueError("Pad_token_id must be set in the configuration of the model, in order to pad tensors")

            padded_tensor = pad_token_id * torch.ones((tensor.size(0), max_length), dtype=tensor.dtype, device=tensor.device)
            padded_tensor[:, :tensor.size(-1)] = tensor

            return padded_tensor

        gen_kwargs = {
                "num_beams": trainer.generation_num_beams,
                "max_length": trainer.generation_max_length,
                # "synced_gpus": True if is_deepspeed_zero3_enabled() else False
                "synced_gpus": True if getattr(trainer, 'deepspeed', None) else False
        }
        model_input_names = trainer.tokenizer.model_input_names if hasattr(trainer, 'tokenizer') else ["input_ids"]
        generation_inputs = {k: v for k, v in trainer.batch_for_model.items() if k in model_input_names}
        # Note: in distributed training, 'DistributedDataParallel' does not inherit 'generate()' methods by seq2seq models
        # So we should unwrap the model here.
        if not getattr(trainer, 'is_teacher', False):
            generated_tokens = trainer.model_unwrapped.generate(
                **generation_inputs,
                **gen_kwargs
            )
        else:
            generated_tokens = trainer._unwrap_model(trainer.teacher).generate(
                **generation_inputs,
                **gen_kwargs
            )
        
        # In case the batch is shorter than max length, the output should be padded
        if generated_tokens.size(-1) < gen_kwargs["max_length"]:
            generated_tokens = _pad_tensors_to_max_len(generated_tokens, gen_kwargs["max_length"])
        if not trainer.pad_to_max_seq_length and trainer.accelerator is not None:
            generated_tokens = trainer.accelerator.pad_across_processes(
                generated_tokens, dim=1, pad_index=trainer.tokenizer.pad_token_id
            )
        if trainer.accelerator is not None:
            generated_tokens = trainer.accelerator.gather(generated_tokens).cpu().numpy()

        trainer.all_generated_tokens.append(generated_tokens)

        # Note: When it is the last step of a epoch, we collection all predictions & metrics,
        # the reason we do this here but not 'after_eval_epoch' cuz PrunerHook, whose prioriy is
        # higher, need to get the metrics in 'after_eval epoch'.
        if self.is_last_step(trainer):
            trainer.all_generated_tokens = np.concatenate(trainer.all_generated_tokens, axis=0)
            # Note: this predictions & metrics are the avg result among all processes
            trainer.predictions = self._generate_predictions(trainer)
            trainer.targets = self._gather_targets(trainer)
            metric_dict = self._compute_metric(trainer)
            for metric_meter in trainer.metric_meters:
                metric_meter.update(metric_dict[metric_meter.name])

    def _generate_predictions(self, trainer):

        def _nested_truncate(tensors, limit):
            "Truncate `tensors` at `limit` (even if it's a nested list/tuple of tensors)."

            if isinstance(tensors, (list, tuple)):
                return type(tensors)(_nested_truncate(t, limit) for t in tensors)
            return tensors[:limit]

        if len(trainer.all_generated_tokens) > len(trainer.features):
            trainer.logger.warning(
                f"\nNote: generated tokens len: {len(trainer.all_generated_tokens)} longer than "
                f"features len: {len(trainer.features)}, tokens will be truncated.\n"
            )

        # Decode the predicted tokens.
        all_decoded_predictions = trainer.tokenizer.batch_decode(
            _nested_truncate(trainer.all_generated_tokens, len(trainer.features)),
            skip_special_tokens=True
        )
        assert len(all_decoded_predictions) == len(trainer.features)

        example_id_to_feature_index = {feature['example_id']: index for index, feature in enumerate(trainer.features)}

        all_predictions = []
        # Let's loop over all the features!
        for example in trainer.examples:
            feature_idx = example_id_to_feature_index[example['id']]
            formatted_prediction = {
                'id': example['id'],
                'prediction_text': all_decoded_predictions[feature_idx]
            }
            if trainer.version_2_with_negative:
                formatted_prediction.update(no_answer_probability=0.)
            
            all_predictions.append(formatted_prediction)

        return all_predictions
