import torch
import datetime

from pprint import pformat

from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='logger')
class LoggerHook(Hook):
    def before_run(self, trainer):
        stages = []
        if trainer.do_train:
            stages.append('Train')
        if trainer.do_eval:
            stages.append('Eval')
        if trainer.do_test:
            stages.append('Test')

        self.stages = ','.join(stages)
        trainer.logger.info(f'Trainer[{self.stages}] start!\n')

    def after_train_iter(self, trainer):
        if self._is_time_to_log(trainer):
            # Kd info
            if trainer.mode == 'train' and trainer.kd:
                self._log_kd_losses(trainer)
            
            if trainer.quant_cfg['enable']:
                self._log_quant_losses(trainer)

            # Formatted loss & metric string
            info = trainer.progress_meter.display(trainer.step, print_out=False)

            assert hasattr(trainer, 'step_lr'), f"LrSchedulerHook should set the attribute 'step_lr' to trainer"
            info += f"\tlr: {trainer.step_lr[-1]:.10f}\tnext lr: {trainer.optimizer.param_groups[0]['lr']:.10f}\t" \
                    f"grad norm: {trainer.grad_norm:.6f}\t" \
                    f"data time: {trainer.timer['data_time']:.4f}s\titer time: {trainer.timer['iter_time']:.2f}s"
            
            if torch.cuda.is_available() and hasattr(trainer, 'memory_used'):
                info += f"\tmemory used: {trainer.memory_used:.0f}MB"
            
            trainer.logger.info(f"{info}\n")
    
    def after_train_epoch(self, trainer):
        metric_info = '; '.join([f"{k}: {v:.3f}" for k, v in trainer.epoch_metrics.items()]) or 'None'
        time_used = datetime.timedelta(seconds=trainer.timer['epoch_time'])
        train_info = f"\n\n[Train Epoch] {trainer.epoch}/{trainer.end_epoch}\n[Loss] {trainer.epoch_loss:.6f}\n[Metric] {metric_info}\n[Time] {time_used}\n"
        if trainer.pruner is not None:
            train_info += f"[Weight Sparsity] {trainer.total_sparse_rate}\n[Layer weight Sparsity]\n{trainer.layer_sparse_rate}\n"

        trainer.logger.info(train_info)
    
    def before_eval_epoch(self, trainer):
        self.prefix = '[Teacher]\n' if getattr(trainer, 'is_teacher', False) else ''
    
    def after_eval_iter(self, trainer):
        if self._is_time_to_log(trainer):
            if trainer.quant_cfg['enable']:
                self._log_quant_losses(trainer)

            # Formatted loss & metric string
            info = trainer.progress_meter.display(trainer.step, print_out=False)
            if hasattr(trainer, 'step_lr'):
                info += f"\tlr: {trainer.step_lr[-1]:.10f}\tnext lr: {trainer.optimizer.param_groups[0]['lr']:.10f}\t"
            info += f"data time: {trainer.timer['data_time']:.4f}s\titer time: {trainer.timer['iter_time']:.2f}s"
            if torch.cuda.is_available() and hasattr(trainer, 'memory_used'):
                info += f"\tmemory used: {trainer.memory_used:.0f}MB"

            assert hasattr(self, 'prefix'), "trainer must call 'before_eval_epoch()' first"
            trainer.logger.info(f"{self.prefix}{info}\n")
    
    def after_eval_epoch(self, trainer):
        metric_info = '; '.join([f"{k}: {v:.3f}" for k, v in trainer.epoch_metrics.items()]) or 'None'
        time_used = datetime.timedelta(seconds=trainer.timer['epoch_time'])
        eval_info = f"\n\n{self.prefix}[{trainer.mode.title()} Epoch] {trainer.epoch}/{trainer.end_epoch}\n[Loss] {trainer.epoch_loss:.6f}\n[Metric] {metric_info}\n[Time] {time_used}\n"

        trainer.logger.info(eval_info)
    
    def after_test_iter(self, trainer):
        if self._is_time_to_log(trainer):
            info = f"step:{trainer.step}\tdata time: {trainer.timer['data_time']:.4f}s\titer time: {trainer.timer['iter_time']:.2f}s"
            if torch.cuda.is_available() and hasattr(trainer, 'memory_used'):
                info += f"\tmemory used: {trainer.memory_used:.0f}MB"

            trainer.logger.info(info)
    
    def after_test_epoch(self, trainer):
        if trainer.print_out_predictions:
            trainer.logger.info(f"Prediction Results:\n{pformat(trainer.prediction_results)}\n")
        trainer.logger.info(f"Prediction time used: {datetime.timedelta(seconds=trainer.timer['epoch_time'])}\n")
    
    def after_run(self, trainer):
        trainer.logger.info(f"Trainer[{self.stages}] finished, time used: {datetime.timedelta(seconds=trainer.timer['total_time'])}\n")

    def _is_time_to_log(self, trainer) -> bool:
        if trainer.mode == 'train':
            return self.every_n_global_steps(trainer, trainer.log_freq) or self.is_last_step(trainer)
        else:
            return self.every_n_steps(trainer, trainer.log_freq) or self.is_last_step(trainer)
    
    def _log_kd_losses(self, trainer):
        trainer.logger.info('\n')

        # Logits
        if hasattr(trainer, 'logit_loss'):
            trainer.logger.info(f"kd logit loss: {trainer.logit_loss.item():.8f}\n")
        if hasattr(trainer, 'logits_loss'):
            trainer.logger.info(f"kd logits loss: {trainer.logits_loss.item():.8f}\n")

        '''----------------------------AutoEncoding structure------------------------------'''

        # Hidden states
        if hasattr(trainer, 'hs_loss'):
            trainer.logger.info(f"kd hidden states loss: {trainer.hs_loss.item():.8f}\n")
        # Self-attentions
        if hasattr(trainer, 'attn_loss'):
            trainer.logger.info(f"kd attentions loss: {trainer.attn_loss.item():.8f}\n")

        '''---------------------------Encoder-Decoder structure-----------------------------'''

        # Encoder hidden states
        if hasattr(trainer, 'enc_hs_loss'):
            trainer.logger.info(f"kd encoder hidden states loss: {trainer.enc_hs_loss.item():.8f}\n")
        # Decoder hidden states
        if hasattr(trainer, 'dec_hs_loss'):
            trainer.logger.info(f"kd decoder hidden states loss: {trainer.dec_hs_loss.item():.8f}\n")
        
        # Encoder self-attentions
        if hasattr(trainer, 'enc_attns_loss'):
            trainer.logger.info(f"kd encoder self-attentions loss: {trainer.enc_attns_loss.item():.8f}\n")
        # Decoder self-attentions
        if hasattr(trainer, 'dec_attns_loss'):
            trainer.logger.info(f"kd decoder self-attentions loss: {trainer.dec_attns_loss.item():.8f}\n")

        # Cross attentions
        if hasattr(trainer, 'cross_attns_loss'):
            trainer.logger.info(f"kd cross-attentions loss: {trainer.cross_attns_loss.item():.8f}\n")
        
        trainer.logger.info('---------------------------------------------\n')

    def _log_quant_losses(self, trainer):
        info = ''
        if hasattr(trainer.outputs, 'qr_losses_str'):
            info += f"qr loss details: {trainer.outputs.qr_losses_str}"
        if hasattr(trainer, 'qr_loss_value'):
            info += f"; qr loss(true-softmax) = {trainer.qr_loss_value}"
        if hasattr(trainer, 'qr_excluded_loss_value'):
            info += f"; qr excluded loss = {trainer.qr_excluded_loss_value}"        
        if info:
            trainer.logger.info(f'{info}\n')
