from utils.dist import is_master
from utils.plot import plot_line

from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='visual')
class VisualHook(Hook):
    def after_train_iter(self, trainer):
        if trainer.do_train and hasattr(trainer, 'progress_bar'):
            trainer.progress_bar.update()
    
    def after_eval_iter(self, trainer):
        if hasattr(trainer, 'progress_bar') and ((not trainer.do_train and trainer.do_eval) or (trainer.epoch >= trainer.end_epoch)):
            trainer.progress_bar.update()
    
    def after_test_iter(self, trainer):
        if trainer.do_test and hasattr(trainer, 'progress_bar'):
            trainer.progress_bar.update()

    def after_run(self, trainer):
        # Note: Only main process will draw items
        if is_master() and trainer.draw_results:
            self._draw_items(trainer)

    def _draw_items(self, trainer):
        """
        Plotting function.
        Curves containing loss, metrics & lr items.
        """

        epoch_range = range(trainer.start_epoch + 1, trainer.end_epoch + 1)

        # Loss
        train_epoch_loss = trainer.meta.get('train_epoch_loss')
        eval_epoch_loss = trainer.meta.get('eval_epoch_loss')

        if not (train_epoch_loss is None and eval_epoch_loss is None):
            plot_line(epoch_range, train_epoch_loss, x_val=epoch_range, y_val=eval_epoch_loss,
                    out_dir=trainer.output_dir, name='loss')
        
        # Metrics
        train_epoch_metric = trainer.meta.get('train_epoch_metric')
        eval_epoch_metric = trainer.meta.get('eval_epoch_metric')
        if not (train_epoch_metric is None or eval_epoch_metric is None):
            for metric_name in trainer.metric_identifier:
                train_metric_value = [metric_dict[metric_name] for metric_dict in train_epoch_metric if metric_name in metric_dict]
                eval_metric_value = [metric_dict[metric_name] for metric_dict in eval_epoch_metric if metric_name in metric_dict]
                
                if not train_metric_value:
                    train_metric_value = None
                if not eval_metric_value:
                    eval_metric_value = None

                plot_line(epoch_range, train_metric_value, x_val=epoch_range, y_val=eval_metric_value, 
                          item=metric_name, out_dir=trainer.output_dir, name=metric_name)
        
        # Lr
        if trainer.meta.get('all_step_lr'):
            step_range = range(len(trainer.meta['all_step_lr']))
            plot_line(step_range, trainer.meta['all_step_lr'], out_dir=trainer.output_dir, item='lr', name='lr')
