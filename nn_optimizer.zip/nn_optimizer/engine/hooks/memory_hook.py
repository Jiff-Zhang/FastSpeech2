import torch
import deepspeed

from torch.cuda import max_memory_allocated

from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='memory')
class MemoryHook(Hook):
    def after_iter(self, trainer):
        trainer.memory_used = max_memory_allocated() / (1024. ** 2) if torch.cuda.is_available() else 0

    def after_eval_iter(self, trainer):
        self.after_iter(trainer)
        # When contiguous memory optimizations are enabled, the buffers
        # allocated by the optimizations are de-allocated during backward pass
        # in the absence of backward pass the buffers should be reset after each forward pass
        if trainer.deepspeed is not None and deepspeed.checkpointing.is_configured():
            deepspeed.checkpointing.reset()
    
    def after_test_iter(self, trainer):
        self.after_iter(trainer)

    def after_epoch(self, trainer):
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def after_test_epoch(self, trainer):
        self.after_epoch(trainer)
