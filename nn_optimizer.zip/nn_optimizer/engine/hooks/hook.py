from enum import Enum
from typing import List, Union

from utils.registry import Registry
from utils.misc import is_method_overridden


class Priority(Enum):
    """
    Hook priority levels.

    (Note: lower value means higher priority)
    +--------------+------------+
    | Level        | Value      |
    +==============+============+
    | HIGHEST      | 0          |
    +--------------+------------+
    | VERY_HIGH    | 10         |
    +--------------+------------+
    | HIGH         | 30         |
    +--------------+------------+
    | ABOVE_NORMAL | 40         |
    +--------------+------------+
    | NORMAL       | 50         |
    +--------------+------------+
    | BELOW_NORMAL | 60         |
    +--------------+------------+
    | LOW          | 70         |
    +--------------+------------+
    | VERY_LOW     | 90         |
    +--------------+------------+
    | LOWEST       | 100        |
    +--------------+------------+
    """

    HIGHEST = 0
    VERY_HIGH = 10
    HIGH = 30
    ABOVE_NORMAL = 40
    NORMAL = 50
    BELOW_NORMAL = 60
    LOW = 70
    VERY_LOW = 90
    LOWEST = 100


HOOK = Registry('HOOK')


class Hook:
    STAGES = (
        'before_run',
        'before_train_epoch', 'before_train_iter',
        'after_train_iter', 'after_train_epoch',
        'before_val_epoch', 'before_val_iter',
        'after_val_iter', 'after_val_epoch',
        'after_run'
    )

    def before_run(self, trainer):
        pass

    def after_run(self, trainer):
        pass

    def before_epoch(self, trainer):
        pass

    def after_epoch(self, trainer):
        pass

    def before_iter(self, trainer):
        pass

    def after_iter(self, trainer):
        pass

    def before_train_epoch(self, trainer):
        self.before_epoch(trainer)

    def before_eval_epoch(self, trainer):
        self.before_epoch(trainer)
    
    def before_sparse_eval_epoch(self,trainer):
        self.before_epoch(trainer)
    
    def before_test_epoch(self, trainer):
        pass

    def after_train_epoch(self, trainer):
        self.after_epoch(trainer)

    def after_eval_epoch(self, trainer):
        self.after_epoch(trainer)
    
    def after_sparse_eval_epoch(self,trainer):
        self.after_epoch(trainer)
    
    def after_test_epoch(self, trainer):
        pass

    def before_train_iter(self, trainer):
        self.before_iter(trainer)

    def before_eval_iter(self, trainer):
        self.before_iter(trainer)
    
    def before_test_iter(self, trainer):
        pass

    def after_train_iter(self, trainer):
        self.after_iter(trainer)

    def after_eval_iter(self, trainer):
        self.after_iter(trainer)
    
    def after_test_iter(self, trainer):
        pass
    
    def every_n_epochs(self, trainer, n: int):
        return not (trainer.epoch + 1) % n if n > 0 else False

    def every_n_steps(self, trainer, n: int):
        return not (trainer.step + 1) % n if n > 0 else False
    
    def every_n_global_steps(self, trainer, n: int):
        return not (trainer.global_step + 1) % n if n > 0 else False

    def is_last_epoch(self, trainer):
        return trainer.epoch == trainer.end_epoch - 1

    def is_last_step(self, trainer):
        return trainer.step == len(trainer.dataloader) - 1

    def get_triggered_stages(self) -> List[str]:
        """
        Returns stages that this hook instance will be triggered.
        """
        
        trigger_stages = set()
        for stage in Hook.STAGES:
            if is_method_overridden(stage, Hook, self):
                trigger_stages.add(stage)

        # Some methods will be triggered in multi stages,
        # so we use this dict to map method to stages.
        method_stages_map = {
            'before_epoch': ['before_train_epoch', 'before_eval_epoch','before_sparse_eval_epoch'],
            'after_epoch': ['after_train_epoch', 'after_eval_epoch','after_sparse_eval_epoch'],
            'before_iter': ['before_train_iter', 'before_eval_iter'],
            'after_iter': ['after_train_iter', 'after_eval_iter']
        }
        for method, map_stages in method_stages_map.items():
            if is_method_overridden(method, Hook, self):
                trigger_stages.update(map_stages)
        
        # Note：we don't directly return 'trigger_stages' cuz we should keep the relative order of each stage.
        return [stage for stage in Hook.STAGES if stage in trigger_stages]

    @property
    def name(self):
        return self.__class__.__name__
    
    def set_priority(self, priority: Union[int, str, Priority]):
        if hasattr(self, 'priority'):
            raise ValueError(f'"priority" is already set to: {self.priority}')
        
        priority_value: int = get_priority(priority)
        self.priority: int = priority_value

        return priority_value

    def __repr__(self) -> str:
        # Note: the 'priority' attribute will be set only after the hook has been registered
        return f"{self.name:<35}({(Priority(self.priority).name if hasattr(self, 'priority') else 'Un-registered'):<12})"


def get_priority(priority: Union[int, str, Priority]):
    """
    Get priority value.
    Args:
        priority (int or str or :obj:`Priority`): Priority.
    Returns:
        int: The priority value.
    """

    if isinstance(priority, int):
        if priority < 0 or priority > 100:
            raise ValueError(f'priority must be between 0 and 100, current is: {priority}')
        return priority
    elif isinstance(priority, Priority):
        return priority.value
    elif isinstance(priority, str):
        return Priority[priority.upper()].value
    else:
        raise TypeError(f'priority must be an integer or Priority enum value, but got: {type(priority)}')
