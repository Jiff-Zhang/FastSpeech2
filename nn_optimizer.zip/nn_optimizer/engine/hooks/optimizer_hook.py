from torch.nn.utils.clip_grad import clip_grad_norm_

from utils.misc import get_grad_norm

from engine.loss import loss_dict
from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='optimizer')
class OptimizerHook(Hook):
    def before_train_epoch(self, trainer):
        self._start_batch = 0
        self._total_batches = len(trainer.dataloader)
    
    def before_train_iter(self, trainer):
        if hasattr(trainer, 'loss_value'):
            del trainer.loss_value

    def after_train_iter(self, trainer):
        # Compute loss
        loss_args = getattr(trainer, 'loss_args', {})
        if trainer.kd:
            # loss = trainer.compute_kd_loss(
            #     trainer.outputs, trainer.teacher_outputs,
            #     trainer.step, len(trainer.dataloader)
            # )
            loss = trainer.compute_kd_loss(trainer.outputs, trainer.teacher_outputs, trainer.batch_for_model, **loss_args)
        else:
            loss_func = loss_dict[trainer.loss]
            loss = loss_func(trainer.outputs, trainer.batch, **loss_args)

        # For quantization
        # TODO: make this more elegant
        if trainer.quant_cfg['enable']:
            qr_loss = trainer.outputs.qr_loss
            trainer.qr_loss_value = qr_loss.item()
            # Record the original loss standalone
            trainer.qr_excluded_loss_value = loss.item()
            loss = loss + trainer.quant_cfg['qr_loss_weight'] * qr_loss

        # Deepspeed handles loss scaling by gradient_accumulation_steps in its `backward`
        if trainer.deepspeed:
            # Loss gets scaled under gradient_accumulation_steps in deepspeed
            loss = trainer.deepspeed.backward(loss)
            # Note: we cannot get the correct grad norm here due to 'DeepSpeedEngine.step()' will zero grad.
            trainer.grad_norm = get_grad_norm(trainer.model.parameters())
            # Optimizer step for deepspeed must be called on every step regardless of the outer value of gradient_accumulation_steps
            trainer.deepspeed.step()
        else:
            # Note: When it is the last step of a epoch or accumulates enough steps(according to your accumulaltion steps setting)
            # loss should be scaled by the correct batch counts
            loss /= min(self.accum_batches, trainer.grad_accumulation_steps)
            # Backward
            loss.backward()
            # Gradient norm before clipping
            # Note: this should be calculated before 'optimizer.zero_grad()'
            trainer.grad_norm = get_grad_norm(trainer.model.parameters())

            # Update model weights
            if self._is_time_to_update(trainer):
                # Gradient clip
                if trainer.clip_grad:
                    trainer.grad_norm = clip_grad_norm_(trainer.model.parameters(), trainer.max_grad_norm)
                
                trainer.optimizer.step()
                trainer.optimizer.zero_grad()

        trainer.loss_value = loss.item()
        del loss

    def _is_time_to_update(self, trainer) -> bool:
        if self.every_n_steps(trainer, trainer.grad_accumulation_steps) or self.is_last_step(trainer):
            self._start_batch = trainer.step + 1
            return True
        
        return False

    @property
    def accum_batches(self):
        return self._total_batches - self._start_batch
