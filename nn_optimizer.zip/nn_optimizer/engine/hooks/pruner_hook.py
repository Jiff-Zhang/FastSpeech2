from statistics import mean

from utils.misc import cmp_models
from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='pruner')
class PrunerHook(Hook):
    def after_train_iter(self, trainer):
        if trainer.pruner is not None and self._is_time_to_prune(trainer):
            trainer.pruner.prune()
    
    def after_train_epoch(self, trainer):
        if trainer.pruner is not None:
            trainer.layer_sparse_rate, trainer.total_sparse_rate = trainer.pruner.sparsity()

            # TODO: remove this in future
            # Make sure that pruner model is the same object as trainer model.
            cmp_models(trainer.pruner.model, trainer.model_unwrapped)
    
    def before_eval_epoch(self, trainer):
        if trainer.pruner is None:
            return
    
    def before_sparse_eval_epoch(self, trainer):
        if trainer.pruner.TYPE=='bbcs' and trainer.pruner.finetune==False:
            trainer.pruner.sparse_model(adaptive_mask=True)
        return 
    
    def after_eval_epoch(self, trainer):
        if trainer.pruner is None:
            return

        # Out of training stage
        if trainer.epoch >= trainer.end_epoch:
            return

        # Cuz teacher will also do evaluation
        if not getattr(trainer, 'is_teacher', False):
            epoch_metrics = {metric_meter.name: getattr(metric_meter, 'avg') for metric_meter in trainer.metric_meters}
            cur_metric = mean([epoch_metrics.get(metric_key, 0.) for metric_key in trainer.metric_identifier])
            trainer.pruner.update_metrics(cur_metric)

            # This is useful for auto-resume
            states = {'epoch': trainer.epoch, 'metric': cur_metric}
            if hasattr(trainer, 'step_lr') and trainer.step_lr:
                states.update(lr=trainer.step_lr[-1])
            trainer.pruner.save(**states)
    
    def after_sparse_eval_epoch(self, trainer):
        if trainer.pruner is None:
            return

        # Out of training stage
        if trainer.epoch >= trainer.end_epoch:
            return

        # Cuz teacher will also do evaluation
        if not getattr(trainer, 'is_teacher', False):
            epoch_metrics = {metric_meter.name: getattr(metric_meter, 'avg') for metric_meter in trainer.metric_meters}
            cur_metric = mean([epoch_metrics.get(metric_key, 0.) for metric_key in trainer.metric_identifier])
            trainer.pruner.update_metrics(cur_metric)

            # This is useful for auto-resume
            states = {'epoch': trainer.epoch, 'metric': cur_metric}
            if hasattr(trainer, 'step_lr') and trainer.step_lr:
                states.update(lr=trainer.step_lr[-1])
            trainer.pruner.save(**states)

            if trainer.pruner.TYPE=='bbcs' and trainer.pruner.finetune==False:
                trainer.pruner.recover()

    def _is_time_to_prune(self, trainer) -> bool:
        """
        Returns whether it is time to call 'pruner.prune()'.
        Note: in fact, whether to do pruning is controled by pruner.
        """
        
        assert trainer.pruner is not None, "Pruner cannot be None when pruning."
        return self.every_n_steps(trainer, trainer.grad_accumulation_steps) or self.is_last_step(trainer)
