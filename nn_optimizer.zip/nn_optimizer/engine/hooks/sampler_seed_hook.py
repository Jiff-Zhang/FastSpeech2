from torch.utils.data.dataloader import DataLoader

from engine.hooks.hook import HOOK, Hook


@HOOK.register_module(name='dist_sampler_seed')
class DistSamplerSeedHook(Hook):
    """
    Data-loading sampler for distributed training.
    """

    def before_epoch(self, trainer):
        if isinstance(trainer.dataloader, DataLoader):
            if hasattr(trainer.dataloader.sampler, 'set_epoch'):
                # In case the data loader uses `SequentialSampler` in Pytorch
                trainer.dataloader.sampler.set_epoch(trainer.epoch)
            elif hasattr(trainer.dataloader.batch_sampler.sampler, 'set_epoch'):
                # Batch sampler in pytorch warps the sampler as its attributes.
                trainer.dataloader.batch_sampler.sampler.set_epoch(trainer.epoch)
