#!/bin/bash

ROOT=$(dirname $PWD)

# Path to execution file
EXE=$ROOT/test/gen_embed.py

# Path to config file
CONFIG=embed/glue/stsb.yaml

# Path to log file
NOHUP_OUTPUT=$PWD/$(date +%m-%d-%H-%M).log

OMP_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false MPLBACKEND='Agg' \
  nohup accelerate launch $EXE --config $CONFIG \
  --data_split_key train --batch_size 128 \
  --embed_way after_sos --target_keyword decoder_hidden_states --target_layer -1 \
  >> $NOHUP_OUTPUT 2>&1 &

echo $NOHUP_OUTPUT
