#!/bin/bash

# ROOT=../..
ROOT=$(dirname $(dirname $PWD))

# Path to execution file
EXE=$ROOT/pipelines/run_img_cls.py

# Path to config file
CONFIG=model/resnet/prune/rn50-imagenet.yaml

# Path to log file
NOHUP_OUTPUT=$PWD/$(date +%m-%d-%H-%M).log

MPLBACKEND='Agg' \
  nohup torchrun \
  --standalone --nnodes=1 --nproc_per_node=8  $EXE \
  --config $CONFIG  \
  >> $NOHUP_OUTPUT 2>&1 &

echo $NOHUP_OUTPUT
