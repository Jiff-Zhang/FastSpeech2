#!/bin/bash

ROOT=../..

# Path to execution file
EXE=$ROOT/test/run_qa.py

# Path to config file
CONFIG=$ROOT/config/model/deberta/base-squad.yaml

# Train
EPOCHS=10

# Path to log file
NOHUP_OUTPUT=$(date +%m-%d-%H-%M).log

OMP_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false MPLBACKEND='Agg' \
nohup accelerate launch $EXE --config $CONFIG --debug --epochs $EPOCHS --prune >> $NOHUP_OUTPUT 2>&1 &

echo $NOHUP_OUTPUT
