#!/bin/bash

ROOT=$(dirname $PWD)

# Path to execution file
EXE=$ROOT/pipelines/run_nlp.py

# Path to config file
CONFIG=model/bert/large-cola.yaml

# Path to log file
NOHUP_OUTPUT=$PWD/$(date +%m-%d-%H-%M).log

CUDA_VISIBLE_DEVICES=4,5,6,7 OMP_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false MPLBACKEND='Agg' \
nohup accelerate launch $EXE --config $CONFIG >> $NOHUP_OUTPUT 2>&1 &

echo $NOHUP_OUTPUT
