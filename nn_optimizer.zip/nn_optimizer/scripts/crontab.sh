#!/bin/bash

ROOT=$(dirname $PWD)
OUTPUT=$(date +%m-%d-%H-%M).log

nohup /root/anaconda3/envs/py39/bin/accelerate launch test.py >> $PWD/$OUTPUT 2>&1 &

