from utils.registry import Registry

__all__ = ('DATA', 'build_data_container',)


DATA = Registry('data')


def build_data_container(cfg, default_args: dict = None):
    return DATA.build(cfg, default_args=default_args)
