import random
import torch.nn as nn

from typing import Union
from copy import deepcopy
from logging import Logger

from torch.utils.data import DataLoader

from transformers.tokenization_utils import PreTrainedTokenizer
from transformers.data.data_collator import DataCollatorForSeq2Seq
from transformers.tokenization_utils_fast import PreTrainedTokenizerFast

from datasets.arrow_dataset import Dataset
from datasets import load_dataset, load_metric
from datasets.iterable_dataset import IterableDataset
from datasets.dataset_dict import DatasetDict, IterableDatasetDict

from utils.misc import is_seq_of, Timer
from utils.seed import reseed_workers_fn

from data.builder import DATA
from data.nlp import NLPDataContainer


@DATA.register_module(name='question_answering')
class QADataContainer(NLPDataContainer):
    """
    Data container for question answering task.
    """
    
    REMOVE_COLUMNS = ["example_id", "offset_mapping"]
    
    def __init__(self, doc_stride: int = 128, **kwargs):
        # Whether to add task prompt to input text, usually for seq2seq lm.
        self.add_task_prompt = kwargs.pop('add_task_prompt', False)
        super().__init__(**kwargs)

        # It it the stride to take between chunks when splitting up a long document into chunks
        self.doc_stride = doc_stride

        self.column_names = self.train_data.column_names
        self.question_column_name = "question" if "question" in self.column_names else self.column_names[0]
        self.context_column_name = "context" if "context" in self.column_names else self.column_names[1]
        self.answer_column_name = "answers" if "answers" in self.column_names else self.column_names[2]

        # Add these for evaluating on training set shen training finished.
        # self.features.update(train_val=None)
        # self.dataloaders.update(train_val=None)

    def load_data(self):
        """
        Get the datasets: you can either provide your own CSV/JSON/TXT training and evaluation files (see below)
        or just provide the name of one of the public datasets available on the hub at https://huggingface.co/datasets/
        (the dataset will be downloaded automatically from the datasets Hub).
        
        For CSV/JSON files, this script will use the column called 'text' or the first column if no column called
        'text' is found. You can easily tweak this behavior (see below).
        
        In distributed training, the load_dataset function guarantee that only one local process can concurrently
        download the dataset.
        """

        '''
        Dataset may looks like:

        DatasetDict({
            train: Dataset({
                features: ['id', 'title', 'context', 'question', 'answers'],
                num_rows: 87599
            })
            validation: Dataset({
                features: ['id', 'title', 'context', 'question', 'answers'],
                num_rows: 10570
            })
        })

        A data sample may looks like:
        
        {
            'answers': {'answer_start': [515], 'text': ['Saint Bernadette Soubirous']},
            'context': 'Architecturally, the school has a Catholic character. '
                       'Atop the Main Building\'s gold dome is a golden statue of the Virgin Mary. '
                       'Immediately in front of the Main Building and facing it, is a copper statue of '
                       'Christ with arms upraised with the legend "Venite Ad Me Omnes". Next to the Main Building '
                       'is the Basilica of the Sacred Heart. Immediately behind the basilica is the Grotto, '
                       'a Marian place of prayer and reflection. It is a replica of the grotto at Lourdes, '
                       'France where the Virgin Mary reputedly appeared to Saint Bernadette Soubirous in 1858. '
                       'At the end of the main drive (and in a direct line that connects through 3 statues and '
                       'the Gold Dome), is a simple, modern stone statue of Mary.',
            'id': '5733be284776f41900661182',
            'question': 'To whom did the Virgin Mary allegedly appear in 1858 in Lourdes France?',
            'title': 'University_of_Notre_Dame'
        }
        '''

        # Loading the dataset from local csv or json file.
        if not (self.train_file is None and self.val_file is None):
            data_files = {}
            if self.train_file is not None:
                data_files['train'] = self.train_file
            if self.val_file is not None:
                data_files['validation'] = self.val_file
            if self.test_file is not None:
                data_files['test'] = self.test_file

            extension = (self.train_file if self.train_file is not None \
                else self.val_file).split(".")[-1]
            data = load_dataset(extension, data_files=data_files, field='data')

            # Note:
            # The final train, val & test data usually processed by tokenizer
            # It is the initial state here
            self.train_data = data[self.train_data_key]
            self.val_data = data[self.val_data_key]
            self.test_data = data[self.test_data_key]
            if self.debug:
                self._select_part_of_data_for_debug()

            return data
        # Downloading & loading a dataset.
        else:
            # From huggingface hub
            return super().load_data()

    def gen_features(self, tokenizer, accelerator=None, num_proc=4, **kwargs):
        """
        Generate features, i.e. tokenized data.
        """
        
        # Padding side: (question|context) or (context|question).
        pad_on_right = tokenizer.padding_side == "right"

        if self.max_seq_length > tokenizer.model_max_length:
            self.logger.warning(
                f"The max_seq_length passed ({self.max_seq_length}) is larger than the maximum length for the"
                f"model ({tokenizer.model_max_length}). Using max_seq_length={tokenizer.model_max_length}."
            )
            self.max_seq_length = tokenizer.model_max_length

        # Preprocessing
        def _gen_features(examples):
            # Some of the questions and context have lots of whitespace on the left, which is not useful and will make the
            # truncation of the context fail (the tokenized question will take a lots of space).
            # So we remove those left whitespace.
            examples[self.question_column_name] = [
                f'question: {q.lstrip()}' if self.add_task_prompt else q.lstrip()
                for q in examples[self.question_column_name]
            ]
            examples[self.context_column_name] = [
                f'context: {c.lstrip()}' if self.add_task_prompt else c.lstrip()
                for c in examples[self.context_column_name]
            ]
            
            # Tokenize our examples with truncation and maybe padding, but keep the overflows using a stride.
            # This results in one example possible giving several features when a context is long,
            # each of those features having a context that overlaps a bit the context of the previous feature.
            tokenized_examples = tokenizer(
                examples[self.question_column_name if pad_on_right else self.context_column_name],
                examples[self.context_column_name if pad_on_right else self.question_column_name],
                truncation="only_second" if pad_on_right else "only_first",
                max_length=self.max_seq_length,
                stride=self.doc_stride,
                return_overflowing_tokens=True,
                return_offsets_mapping=True,
                padding="max_length" if self.pad_to_max_seq_length else False,
            )

            # Since one example might give us several features if it has a long context, 
            # we need a map from a feature to its corresponding example. This key gives us just that.
            sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")
            # The offset mappings will give us a map from token to character position in the original context.
            # This will help us compute the start_positions and end_positions.
            offset_mapping = tokenized_examples["offset_mapping"]
            # For evaluation, we will need to convert our predictions to substrings of the context, so we keep the
            # corresponding example_id and we will store the offset mappings.
            tokenized_examples["example_id"] = []

            # Let's label those examples!
            tokenized_examples["start_positions"] = []
            tokenized_examples["end_positions"] = []

            for i, offsets in enumerate(offset_mapping):
                # We will label impossible answers with the index of the CLS token.
                input_ids = tokenized_examples["input_ids"][i]
                # Note: some tokenizers don't have cls token
                cls_index = input_ids.index(tokenizer.cls_token_id) if tokenizer.cls_token_id is not None else 0

                context_id = 1 if pad_on_right else 0
                # Grab the sequence corresponding to that example (to know what is the context and what is the question).
                sequence_ids = tokenized_examples.sequence_ids(i)

                # One example can give several spans, this is the index of the example containing this span of text.
                sample_index = sample_mapping[i]
                tokenized_examples['example_id'].append(examples['id'][sample_index])

                answers = examples[self.answer_column_name][sample_index]
                # If no answers are given, set the cls_index as answer.
                if len(answers["answer_start"]) == 0:
                    tokenized_examples["start_positions"].append(cls_index)
                    tokenized_examples["end_positions"].append(cls_index)
                else:
                    # Start/end character index of the answer in the text.
                    start_char = answers["answer_start"][0]
                    end_char = start_char + len(answers["text"][0])

                    # Start token index of the current span in the text.
                    token_start_index = 0
                    while sequence_ids[token_start_index] != context_id:
                        token_start_index += 1

                    # End token index of the current span in the text.
                    token_end_index = len(input_ids) - 1
                    while sequence_ids[token_end_index] != context_id:
                        token_end_index -= 1
                    
                    # Detect if the answer is out of the span (in which case this feature is labeled with the CLS index).
                    if not (offsets[token_start_index][0] <= start_char and offsets[token_end_index][1] >= end_char):
                        tokenized_examples["start_positions"].append(cls_index)
                        tokenized_examples["end_positions"].append(cls_index)
                    else:
                        # Otherwise move the token_start_index and token_end_index to the two ends of the answer.
                        # Note: we could go after the last offset if the answer is the last word (edge case).
                        while token_start_index < len(offsets) and offsets[token_start_index][0] <= start_char:
                            token_start_index += 1
                        tokenized_examples["start_positions"].append(token_start_index - 1)

                        while offsets[token_end_index][1] >= end_char:
                            token_end_index -= 1
                        tokenized_examples["end_positions"].append(token_end_index + 1)
                
                # Set to None the offset_mapping that are not part of the context
                # so it's easy to determine if a token position is part of the context or not.
                offsets = [
                    token_offset if sequence_ids[token_idx] == context_id else None \
                        for token_idx, token_offset in enumerate(offsets)
                ]

            return tokenized_examples

        def _map_data_to_features():
            """
            Map the raw data to tokenized form.
            """
            
            self.features['train'] = self.train_data.map(
                _gen_features,
                batched=True,
                num_proc=num_proc,
                remove_columns=self.column_names,
                load_from_cache_file=self.load_from_cache,
                desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} train dataset",
            )
            # Use this for evaluating traning set when training finished.
            if kwargs.pop('add_train_val_data', False):
                self.features['train_val'] = deepcopy(self.features['train'])

            self.features['validation'] = self.val_data.map(
                _gen_features,
                batched=True,
                num_proc=num_proc,
                remove_columns=self.column_names,
                load_from_cache_file=self.load_from_cache,
                desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} validation dataset"
            )

            if self.test_data is not None and len(self.test_data):
                self.features['test'] = self.test_data.map(
                    _gen_features,
                    batched=True,
                    num_proc=num_proc,
                    remove_columns=self.column_names,
                    load_from_cache_file=self.load_from_cache,
                    desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} prediction dataset"
                )

        # Create train feature from dataset
        if accelerator is not None:
            with accelerator.main_process_first():
                _map_data_to_features()
        else:
            _map_data_to_features()

        return self.features

    def get_dataloaders(self, features=None, tokenizer=None, **kwargs):
        """
        Get train, eval, test dataloaders.
        """
        
        # TODO: add comments
        if features is None:
            # Features for model should remove un-used keys
            features = deepcopy(self.features)
            for k, feat in self.features.items():
                if feat is None:
                    continue

                columns_to_remove = [column for column in self.REMOVE_COLUMNS if column in feat.column_names]
                if columns_to_remove:
                    features[k] = feat.remove_columns(columns_to_remove)

        return super().get_dataloaders(features=features, tokenizer=tokenizer, **kwargs)


@DATA.register_module(name='cmrc2018')
class CMRC2018DataContainer(QADataContainer):
    def __init__(
        self, dataset_name: str = None, train_file: str = None, val_file: str = None, test_file: str = None,
        train_batch_size: int = None, val_batch_size: int = None, num_workers: int = 0, pin_memory: bool = True,
        seed: int = 0, rank: int = 0, debug: bool = False, use_fp16: bool = False, logger: Logger = None,
        doc_stride: int = 128, load_from_cache: bool = False, metric='f1', pad_to_max_seq_length: bool = True,
        max_seq_length: int = 384
    ):
        super().__init__(
            dataset_name, train_file, val_file, test_file, train_batch_size, val_batch_size,
            num_workers, pin_memory, seed, rank, debug, use_fp16, logger, doc_stride, load_from_cache,
            metric, pad_to_max_seq_length, max_seq_length
        )

    def load_metric(self):
        try:
            return load_metric('squad')
        except:
            import os

            BASE_DIR = os.path.dirname(__file__)
            return load_metric(os.path.join(BASE_DIR, NLPDataContainer.METRIC_SCRIPT['squad']))


@DATA.register_module(name='seq2seq_question_answering')
class Seq2SeqQADataContainer(QADataContainer):
    def __init__(
        self, max_answer_length: int = 30,
        ignored_value_for_loss: int = -100,
        ignore_pad_token_for_loss: bool = True, **kwargs
    ):
        super().__init__(**kwargs)

        self.max_answer_length = max_answer_length

        self.ignored_value_for_loss = ignored_value_for_loss
        self.ignore_pad_token_for_loss = ignore_pad_token_for_loss

    def _concat_questions_and_contexts(self, q, c):
        return ' '.join(['question:', q.lstrip(), 'context:', c.lstrip()])

    def _gen_train_features(self, examples):
        questions = examples[self.question_column_name]
        contexts = examples[self.context_column_name]
        answers = examples[self.answer_column_name]

        # Compatible with 'batched=False'
        if isinstance(questions, str):
            questions = [questions]
        if isinstance(contexts, str):
            contexts = [contexts]
        if isinstance(answers, dict):
            answers = [answers]

        assert is_seq_of(questions, str), f"questions should be sequence of str, but got: {type(questions)}[{type(questions[0])}]"
        assert is_seq_of(contexts, str), f"contexts should be sequence of str, but got: {type(contexts)}[{type(contexts[0])}]"
        assert is_seq_of(answers, dict), f"answers should be sequence of cict, but got: {type(answers)}[{type(answers[0])}]"

        padding = "max_length" if self.pad_to_max_seq_length else False

        inputs = [
            self._concat_questions_and_contexts(question, context)
            for question, context in zip(questions, contexts)
        ]
        targets = [answer['text'][0] if len(answer['text']) else '' for answer in answers]

        tokenized_examples = self.tokenizer(
            inputs, max_length=self.max_seq_length,
            padding=padding, truncation=True
        )
        with self.tokenizer.as_target_tokenizer():
            labels = self.tokenizer(
                targets, max_length=self.max_answer_length,
                padding=padding, truncation=True
            )

        labels_token_id = labels["input_ids"]
        # Compatible with 'batched=False'
        if not self.batched_tokenize:
            assert is_seq_of(labels_token_id, int)
            labels_token_id = [labels_token_id]

        # If we are padding here, replace all tokenizer.pad_token_id in the labels by -100 when we want to ignore
        # padding in the loss.
        if padding and self.ignore_pad_token_for_loss:
            labels_token_id = [
                [(l if l != self.tokenizer.pad_token_id else self.ignored_value_for_loss) for l in label]
                for label in labels_token_id
            ]
        # Expand labels as token ids
        if not self.batched_tokenize:
            assert len(labels_token_id) == 1
            labels_token_id = labels_token_id.pop()
        
        tokenized_examples["labels"] = labels_token_id

        return tokenized_examples

    def _gen_val_features(self, examples):
        questions = examples[self.question_column_name]
        contexts = examples[self.context_column_name]
        answers = examples[self.answer_column_name]

        # Compatible with 'batched=False'
        if isinstance(questions, str):
            questions = [questions]
        if isinstance(contexts, str):
            contexts = [contexts]
        if isinstance(answers, dict):
            answers = [answers]

        assert is_seq_of(questions, str), f"questions should be sequence of str, but got: {type(questions)}[{type(questions[0])}]"
        assert is_seq_of(contexts, str), f"contexts should be sequence of str, but got: {type(contexts)}[{type(contexts[0])}]"
        assert is_seq_of(answers, dict), f"answers should be sequence of cict, but got: {type(answers)}[{type(answers[0])}]"

        padding = "max_length" if self.pad_to_max_seq_length else False

        inputs = [
            self._concat_questions_and_contexts(question, context)
            for question, context in zip(questions, contexts)
        ]
        targets = [answer['text'][0] if len(answer['text']) else '' for answer in answers]

        tokenized_examples = self.tokenizer(
            inputs, max_length=self.max_seq_length,
            padding=padding, truncation=True,
            return_overflowing_tokens=True
        )
        with self.tokenizer.as_target_tokenizer():
            labels = self.tokenizer(
                targets, max_length=self.max_answer_length,
                padding=padding, truncation=True
            )

        labels_token_id = labels["input_ids"]
        if not self.batched_tokenize:
            labels_token_id = [labels_token_id]
        # If we are padding here, replace all tokenizer.pad_token_id in the labels by -100 when we want to ignore
        # padding in the loss.
        if padding and self.ignore_pad_token_for_loss:
            labels_token_id = [
                [(l if l != self.tokenizer.pad_token_id else self.ignored_value_for_loss) for l in label]
                for label in labels_token_id
            ]
        assert len(labels_token_id) == len(answers)

        tokenized_examples["labels"] = []
        # For evaluation, we will need to convert our predictions to substrings of the context, so we keep the
        # corresponding example_id and we will store the offset mappings.
        # One example can give several spans, this is the index of the example containing this span of text.
        tokenized_examples["example_id"] = []

        # Compatible with 'batched=False'
        examples_id = examples["id"]
        if not self.batched_tokenize:
            examples_id = [examples_id]

        # Since one example might give us several features if it has a long context, we need a map from a feature to
        # its corresponding example. This key gives us just that.
        sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")
        for example_idx_per_feature in sample_mapping:
            label_for_feature = labels_token_id[example_idx_per_feature]
            tokenized_examples["labels"].append(label_for_feature)
            tokenized_examples["example_id"].append(examples_id[example_idx_per_feature])

        return tokenized_examples

    def gen_features(self, tokenizer, accelerator=None, num_proc=4, batched=True, **kwargs):
        if self.max_seq_length > tokenizer.model_max_length:
            self.logger.warning(
                f"The max_seq_length passed ({self.max_seq_length}) is larger than the maximum length for the"
                f"model ({tokenizer.model_max_length}). Using max_seq_length={tokenizer.model_max_length}."
            )
            self.max_seq_length = tokenizer.model_max_length
        
        self.tokenizer = tokenizer
        self.batched_tokenize = batched

        def _map_data_to_features():
            """
            Map the raw data to tokenized form.
            """
            
            self.features['train'] = self.train_data.map(
                self._gen_train_features,
                batched=batched,
                num_proc=num_proc,
                remove_columns=self.column_names,
                load_from_cache_file=self.load_from_cache,
                desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} train dataset",
            )
            if kwargs.pop('add_train_val_data', False):
                # Use this for evaluating training set when training finshed.
                self.features['train_val'] = self.train_data.map(
                    self._gen_val_features,
                    batched=batched,
                    num_proc=num_proc,
                    remove_columns=self.column_names,
                    load_from_cache_file=self.load_from_cache,
                    desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} train_val dataset"
                )

            self.features['validation'] = self.val_data.map(
                self._gen_val_features,
                batched=batched,
                num_proc=num_proc,
                remove_columns=self.column_names,
                load_from_cache_file=self.load_from_cache,
                desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} validation dataset"
            )

            if self.test_data is not None and len(self.test_data):
                self.features['test'] = self.test_data.map(
                    self._gen_val_features,
                    batched=batched,
                    num_proc=num_proc,
                    remove_columns=self.column_names,
                    load_from_cache_file=self.load_from_cache,
                    desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} prediction dataset"
                )
        
        if accelerator is not None:
            with accelerator.main_process_first():
                _map_data_to_features()
        else:
            _map_data_to_features()
        
        # Post-process val & test features when passing 'batched=False' to trainsformers api: 'dataset.map()'
        if not batched:
            for k, features in self.features.items():
                if k != 'train':
                    self.features[k] = self._post_process_val_features(features)
    
        return self.features

    def _post_process_val_features(self, features):
        """
        When passing 'batched=False' to trainsformers api: 'dataset.map()' methods,
        we should post process tokenized features.
        """

        if features is None:
            return

        features = features.to_dict()

        processed_labels = []
        processed_input_ids = []
        processed_attn_mask = []
        processed_example_id = []
        processed_offset_mapping = []

        for idx, input_ids in enumerate(features['input_ids']):
            labels = features['labels'][idx]
            example_id = features['example_id'][idx]
            attn_mask = features['attention_mask'][idx]
            offset_mapping = features['offset_mapping'][idx]
            assert len(input_ids) == len(labels) == len(attn_mask) == len(offset_mapping) == len(example_id)

            assert is_seq_of(input_ids, list)
            processed_input_ids.extend(input_ids)

            assert is_seq_of(labels, list) and len(labels) == len(input_ids)
            processed_labels.extend(labels)

            assert is_seq_of(example_id, str) and len(example_id) == len(input_ids)
            processed_example_id.extend(example_id)

            assert is_seq_of(attn_mask, list) and len(attn_mask) == len(input_ids)
            processed_attn_mask.extend(attn_mask)

            assert is_seq_of(offset_mapping, list) and len(offset_mapping) == len(input_ids)
            processed_offset_mapping.extend(offset_mapping)

        assert len(processed_input_ids) == len(processed_labels) == len(processed_attn_mask) \
            == len(processed_offset_mapping) == len(processed_example_id)

        features.update(
            labels=processed_labels,
            input_ids=processed_input_ids,
            example_id=processed_example_id,
            attention_mask=processed_attn_mask,
            offset_mapping=processed_offset_mapping
        )
        features = Dataset.from_dict(features)

        return features

    def _get_dataloader(
        self, data: Union[DatasetDict, Dataset, IterableDatasetDict, IterableDataset], 
        batch_size: int, mode: bool = 'train',
        num_workers: int = 0, pin_memory: bool = True, 
        tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast] = None,
        model: nn.Module = None, seed: int = 0, rank: int = 0, **kwargs
    ):
        """
        Returns a dataloader according to the given dataset with specified batch size.

        Args:
            data (Union[DatasetDict, Dataset, IterableDatasetDict, IterableDataset]) : Dataset object.
            batch_size (int) : Number of data samples in a batch.
            train: (bool) : Training or not. Default is False.
            tokenizer (Union[PretrainedTokenizer, PretrainedTokenizerFast], optional) : Tokenizer object. Default is None.
        
        Returns:
            An instance of torch.utils.data.DataLoader.
        """

        if data is None or not len(data):
            self.logger.info(f"Note: input {mode} data IS NONE, SKIP building dataloader.")
            return None
        
        if not self.rank:
            # Log a few random samples from the training set
            for index in random.sample(range(len(data)), 2):
                self.logger.info(f"=> Sample {index} of the {mode} set: {data[index]}.")
        
        label_pad_token_id = self.ignored_value_for_loss \
            if self.ignore_pad_token_for_loss else tokenizer.pad_token_id

        data_collator = DataCollatorForSeq2Seq(
            tokenizer,
            model=model,
            label_pad_token_id=label_pad_token_id,
            pad_to_multiple_of=8 if self.use_fp16 else None,
        )

        with Timer(self.logger, job=f"=> Build {mode} dataloader"):
            shuffle = True if mode == 'train' else False
            dataloader = DataLoader(
                data, batch_size=batch_size,
                shuffle=shuffle, num_workers=num_workers,
                collate_fn=data_collator, pin_memory=pin_memory,
                # Set 'worker_init_fn' for randomness of multi-process
                # Random seed of different sub process in different rank is different
                worker_init_fn=reseed_workers_fn(num_workers, seed, rank=rank) if shuffle else None
            )

        return dataloader
