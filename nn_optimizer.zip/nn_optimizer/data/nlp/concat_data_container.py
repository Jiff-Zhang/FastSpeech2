from logging import Logger
from typing import Dict, Iterable, List

from torch.utils.data.dataset import ConcatDataset

from data.builder import DATA
from data.utils import ConcatDataLoader, MixupDataLoader
from data.nlp.nlp_data_container import NLPDataContainer


DATALOADER_CLS = {
    'mixup': MixupDataLoader,
    'concat': ConcatDataLoader
}


@DATA.register_module(name='concat')
class ConcatDataContainer:
    """
    DataContainer as a concatenation of multiple data containers.
    This class is useful to assemble different existing data containers.

    Args:
        data_containers (Iterable): Seqence of data containers to be concatenated.
    """

    # Configuration of each data container
    data_container_cfgs: Iterable[Dict]
    # Sequence of data containers
    data_containers: List[NLPDataContainer]
    cumulative_sizes: Dict[str, List[int]]

    @staticmethod
    def cumsum(seq: Iterable) -> List[int]:
        r, s = [], 0
        for sub in seq:
            l = len(sub) if sub is not None else 0
            r.append(s + l)
            s += l
        
        return r

    @classmethod
    def cal_cum_sizes(cls, key_values: Dict) -> List[int]:
        cum_sizes = {}
        for key, values in key_values.items():
            cum_sizes[key] = cls.cumsum(values)
            assert len(cum_sizes[key]) == len(values)

        return cum_sizes 

    @classmethod
    def concat_items(cls, key_values: Dict, concat_cls, **kwargs) -> Dict:
        concat_key_values = {
            key: list(filter(lambda v: v is not None, values)) 
            for key, values in key_values.items()
        }

        for key, values in concat_key_values.items():
            concat_key_values[key] = values or None
            if concat_key_values[key] is not None:
                concat_key_values[key] = concat_cls(values, **kwargs)
        
        return concat_key_values

    def __init__(
        self, data_container_cfgs: Iterable[Dict], dataloader_type: str = 'mixup',
        train_batch_size: int = 4, val_batch_size: int = 4, test_batch_size: int = 1,
        use_fp16: bool = False, seed: int = 0, rank: int = 0, logger: Logger = None,
        debug: bool = False, num_debug_samples: int = 0, **kwargs
    ) -> None:
        # Cuz we accept multiple data containers, this is multi-task,
        # we don't need 'dataset_name' & 'task_name' here
        kwargs.pop('dataset_name', None)
        kwargs.pop('task_name', None)

        if dataloader_type not in DATALOADER_CLS:
            raise ValueError(f"'dataloader_type' should be one of: {set(DATALOADER_CLS.keys())}, current is: {dataloader_type}")
        # The target dataloader wrapping all of dataloaders
        self.dataloader_cls = DATALOADER_CLS[dataloader_type]

        self.data_container_cfgs = list(data_container_cfgs)
        assert len(self.data_container_cfgs), f"data container configs should not be an empty iterable."

        kwargs.update(
            seed=seed,
            rank=rank,
            debug=debug,
            logger=logger,
            use_fp16=use_fp16,
            val_batch_size=val_batch_size,
            test_batch_size=test_batch_size,
            train_batch_size=train_batch_size,
            num_debug_samples=num_debug_samples
        )
        # Set basic attributes
        for k, v in kwargs.items():
            setattr(self, k, v)

        self._data = {}
        self.data_containers = []
        # Build each data container & set their data split here
        for cfg in self.data_container_cfgs:
            assert isinstance(cfg, Dict), f"data container config must be Dict type."
            
            # data_container = DATA.build(cfg, default_args=common_args_for_data_containers)
            data_container = DATA.build(cfg, default_args=kwargs)
            self.data_containers.append(data_container)

            for key, data_split in data_container.data.items():
                self._data.setdefault(key, [])
                self._data[key].append(data_split)

        # Cummulate size of each data split
        self.cum_data_sizes = self.cal_cum_sizes(self._data)
        # Concat all the datasets
        self.data = self.concat_items(self._data, ConcatDataset)

        self.train_data = self.data[self.train_data_key]
        self.val_data = self.data[self.val_data_key]
        self.test_data = self.data[self.test_data_key]

    @property
    def dataset_name(self):
        return self.data_containers[0].dataset_name
    
    @property
    def task_name(self):
        return self.data_containers[0].task_name
    
    @property
    def train_data_key(self):
        return self.data_containers[0].train_data_key
    
    @property
    def val_data_key(self):
        return self.data_containers[0].val_data_key
    
    @property
    def test_data_key(self):
        return self.data_containers[0].test_data_key

    @property
    def metric_computor(self):
        return self.data_containers[0].metric_computor

    def gen_features(self, tokenizer, accelerator=None, batched=True, **kwargs):
        self._features = {}
        for data_container in self.data_containers:
            features = data_container.gen_features(tokenizer, accelerator=accelerator, batched=batched, **kwargs)
            for key, feature_split in features.items():
                self._features.setdefault(key, [])
                self._features[key].append(feature_split)

        # Cummulate size of each feature split
        self.cum_feature_sizes = self.cal_cum_sizes(self._features)
        # Concat all the features of each data container
        self.features = self.concat_items(self._features, ConcatDataset)

    def get_dataloaders(self, tokenizer=None, model=None, features=None, accelerator=None, **kwargs):
        self._dataloaders = {}
        for data_container in self.data_containers:
            dataloaders = data_container.get_dataloaders(tokenizer=tokenizer, model=model, features=features, **kwargs)
            for key, dataloader_split in dataloaders.items():
                self._dataloaders.setdefault(key, [])
                self._dataloaders[key].append(dataloader_split)

        # Cummulate size of each dataloader split
        self.cum_dataloader_sizes = self.cal_cum_sizes(self._dataloaders)
        # Use the target dataloader type to concat all dataloaders of each data container
        self.dataloaders = self.concat_items(self._dataloaders, self.dataloader_cls, accelerator=accelerator)

        return self.dataloaders
