import random
import numpy as np
import torch.nn as nn

from typing import List, Union, Tuple

from torch.utils.data import DataLoader

from datasets.arrow_dataset import Dataset
from datasets.iterable_dataset import IterableDataset
from datasets.dataset_dict import DatasetDict, IterableDatasetDict

from transformers import PretrainedConfig
from transformers.tokenization_utils import PreTrainedTokenizer
from transformers.data.data_collator import DataCollatorForSeq2Seq
from transformers.tokenization_utils_fast import PreTrainedTokenizerFast

from data.builder import DATA
from data.nlp import NLPDataContainer

from utils.misc import is_seq_of, Timer
from utils.seed import reseed_workers_fn


TASK_TO_KEYS = {
    "cola": ("sentence", None),
    "mnli": ("premise", "hypothesis"),
    "mrpc": ("sentence1", "sentence2"),
    "qnli": ("question", "sentence"),
    "qqp": ("question1", "question2"),
    "rte": ("sentence1", "sentence2"),
    "sst2": ("sentence", None),
    "stsb": ("sentence1", "sentence2"),
    "wnli": ("sentence1", "sentence2"),
}

STR_LABEL_TO_CLS_ID = {
    "cola": {'unacceptable': 0, 'acceptable': 1},
    "rte": {'entailment': 0, 'not_entailment': 1},
    "mnli": {'entailment': 0, 'neutral': 1, 'contradiction': 2},
    "sst2": {'negative': 0, 'positive': 1},
    "mrpc": {'not_equivalent': 0, 'equivalent': 1},
    "qnli": {'entailment': 0, 'not_entailment': 1},
    "qqp": {'not_duplicate': 0, 'duplicate': 1},
    "wnli": {'not_equivalent': 0, 'equivalent': 1}
}


@DATA.register_module(name='text_classification')
class TCDataContainer(NLPDataContainer):
    """
    Data container for text classification task.
    """
    
    def __init__(self, **kwargs):
        # Note: key of MNLI valdation & test dataset are different from others.
        task_name = kwargs.get('task_name')
        if task_name.lower() == 'mnli':
            kwargs.update({
                'val_data_key': 'validation_matched',
                'test_data_key': 'test_matched',
            })
        # Whether to add task prompt for input text, usually for seq2seq lm.
        self.add_task_prompt = kwargs.pop('add_task_prompt', False) and task_name

        super().__init__(**kwargs)

        if not (self.train_file is None and self.val_file is None and self.test_file is None):
            if self.train_data is not None:
                data_ref = self.train_data
            elif self.val_data is not None:
                data_ref = self.val_data
            elif self.test_data is not None:
                data_ref = self.test_data
            else:
                raise RuntimeError(f"'train', 'val' and 'test' data split are all NONE.")

            self.is_regression = data_ref.features["label"].dtype in ["float32", "float64"]

            if self.is_regression:
                self.num_labels = 1
            else:
                self.label_list = data_ref.unique("label")
                # Let's sort it for determinism
                self.label_list.sort()
                self.num_labels = len(self.label_list)
        else:
            assert self.task_name is not None

            self.is_regression = self.task_name == 'stsb'

            if self.is_regression:
                self.num_labels = 1
            else:
                if self.train_data is not None:
                    self.label_list = self.train_data.features["label"].names
                elif self.val_data is not None:
                    self.label_list = self.val_data.features["label"].names
                elif self.test_data is not None:
                    self.label_list = self.test_data.features["label"].names
                else:
                    raise RuntimeError(f"data container should at least contain one of 'train', 'val' or 'test' data split.")

                self.num_labels = len(self.label_list)
    
    def gen_features(self, tokenizer, model_config, accelerator=None, batched=True):
        """
        Generate features, i.e. tokenized data.
        """

        # Preprocessing the datasets
        if not (self.train_file is None or self.val_file is None):
            # Again, we try to have some nice defaults but don't hesitate to tweak to your use case.
            non_label_column_names = [name for name in self.train_data.column_names if name != "label"]
            if "sentence1" in non_label_column_names and "sentence2" in non_label_column_names:
                sentence1_key, sentence2_key = "sentence1", "sentence2"
            else:
                if len(non_label_column_names) >= 2:
                    sentence1_key, sentence2_key = non_label_column_names[:2]
                else:
                    sentence1_key, sentence2_key = non_label_column_names[0], None
        else:
            assert self.task_name is not None
            sentence1_key, sentence2_key = TASK_TO_KEYS[self.task_name]

        # Some models have set the order of the labels to use, so let's make sure we do use it.
        label_to_id = None
        if (
            # Usually are both: {'LABEL_0': 0, 'LABEL_1': 1}
            model_config.label2id != PretrainedConfig(num_labels=self.num_labels).label2id
            and self.task_name is not None
            and self.train_file is None
            and not self.is_regression
        ):
            # Some have all caps in their config, some don't.
            label_name_to_id = {k.lower(): v for k, v in model_config.label2id.items()}
            if list(sorted(label_name_to_id.keys())) == list(sorted(self.label_list)):
                self.logger.info(
                    f"\nThe configuration of the model provided the following label correspondence: {label_name_to_id}. "
                    "Using it!\n"
                )
                label_to_id = {i: label_name_to_id[self.label_list[i]] for i in range(self.num_labels)}
            else:
                self.logger.warning(
                    f"\nYour model seems to have been trained with labels, but they don't match the dataset. "
                    f"model labels: {list(sorted(label_name_to_id.keys()))}, dataset labels: {list(sorted(self.label_list))}."
                    f"\nIgnoring the model labels as a result.\n"
                )
        elif self.task_name is None or self.train_file is not None:
            label_to_id = {v: i for i, v in enumerate(self.label_list)}
        else:
            pass

        if label_to_id is not None:
            model_config.label2id = label_to_id
            model_config.id2label = {i: label for label, i in label_to_id.items()}
        elif self.task_name is not None and not self.is_regression:
            model_config.label2id = {l: i for i, l in enumerate(self.label_list)}
            model_config.id2label = {i: l for i, l in enumerate(self.label_list)}
        else:
            pass

        self.logger.info(f"\nmodel_config.label2id: {model_config.label2id}\t"
                         f"model_config.id2label: {model_config.id2label}\n")

        def generate_features(examples):
            # Ensure that each input sequence text is str
            examples[sentence1_key] = list(map(lambda t: str(t), examples[sentence1_key]))
            if sentence2_key is not None:
                examples[sentence2_key] = list(map(lambda t: str(t), examples[sentence2_key]))

            # Tokenize the texts
            texts = (examples[sentence1_key],) if sentence2_key is None \
                else (examples[sentence1_key], examples[sentence2_key])

            # usually for seq2seq lm
            if self.add_task_prompt:
                sentences1 = texts[0]
                if not batched:
                    sentences1 = [sentences1]
                
                for idx, sentence in enumerate(sentences1):
                    sentences1[idx] = f'{self.task_name} {sentence}'
                if not batched:
                    sentences1 = sentences1.pop()

                texts = (sentences1,) if sentence2_key is None else (sentences1, examples[sentence2_key])

            result = tokenizer(
                *texts, padding="max_length" if self.pad_to_max_seq_length else False, 
                max_length=self.max_seq_length, truncation=True
            )
            result["id"] = examples.get("idx", examples.get("id", -1))

            if "label" in examples:
                # Note: if batched=False, examples["label"] is int object
                if label_to_id is not None and batched:
                    # Map labels to IDs (not necessary for GLUE tasks)
                    # This situation may occur: some value in 'examples["label"]' does not existed in 'label_to_id',
                    # etc. for MNLI testing set, all of examples["label"] is -1
                    result["labels"] = [label_to_id.get(l) for l in examples["label"]]
                else:
                    # In all cases, rename the column to labels because the model will expect that.
                    result["labels"] = examples["label"]

            return result

        if self.train_data is not None:
                data_ref = self.train_data
        elif self.val_data is not None:
            data_ref = self.val_data
        elif self.test_data is not None:
            data_ref = self.test_data
        else:
            raise RuntimeError(f"'train', 'val' and 'test' data split are all NONE.")


        if accelerator is not None:
            with accelerator.main_process_first():
                features = self.data.map(
                    generate_features,
                    batched=batched,
                    remove_columns=data_ref.column_names,
                    desc=f"Running tokenizer on {self.dataset_name} dataset",
                    load_from_cache_file=self.load_from_cache
                )
        else:
            features = self.data.map(
                generate_features,
                batched=batched,
                remove_columns=data_ref.column_names,
                desc=f"Running tokenizer on {self.dataset_name} dataset",
                load_from_cache_file=self.load_from_cache
            )
        self.features.update(features)
        
        return self.features


@DATA.register_module(name='seq2seq_text_classification')
class Seq2SeqTextClsDataContainer(TCDataContainer):
    """
    Text classifiction data container for seq2seq model.
    """

    def __init__(
        self, max_answer_length: int = 10,
        ignore_pad_token_for_loss: bool = True,
        ignored_value_for_loss: int = -100, **kwargs
    ):
        super().__init__(**kwargs)

        self.max_answer_length = max_answer_length
        self.ignored_value_for_loss = ignored_value_for_loss
        self.ignore_pad_token_for_loss = ignore_pad_token_for_loss

    def gen_features(self, tokenizer, model_config, accelerator=None, batched=True, **kwargs):
        """
        Generate features, i.e. tokenized data.
        """

        feature_keys = TASK_TO_KEYS.get(self.task_name) or ("sentence1", "sentence2")

        def _concat_sentence_pair(sentence_pair: Union[Tuple, List], keys: Union[List[str], Tuple[str]]):
            """
            Concat multiple sentences to a sentence.
            Note: num of input sentences must equals to num of keys that are not None.
            """
            
            sentence_to_join = [
                f"{feat_key}: {sentence_pair[i]}" \
                    for i, feat_key in enumerate(filter(lambda k: k is not None, keys))
            ]
            return ' '.join(sentence_to_join)
        
        def _shift_tokens_right(input_ids: Union[List[List], np.array], pad_token_id: int, decoder_start_token_id: int):
            """
            Shift input ids one token to the right.
            """

            input_ids_arr = np.array(input_ids)

            shifted_input_ids = np.zeros_like(input_ids_arr)
            shifted_input_ids[:, 1:] = input_ids_arr[:, :-1]
            
            shifted_input_ids[:, 0] = decoder_start_token_id
            # Replace possible -100 values in labels by `pad_token_id`
            shifted_input_ids = np.where(shifted_input_ids == self.ignored_value_for_loss, pad_token_id, shifted_input_ids)
            assert (shifted_input_ids >= 0).all(), "Verify that `shifted_input_ids` has only positive values"

            if isinstance(input_ids, List):
                shifted_input_ids = shifted_input_ids.tolist()

            return shifted_input_ids

        def generate_features(examples):
            padding = "max_length" if self.pad_to_max_seq_length else False
            
            '''Process input texts'''

            sentence_pairs = [examples[feat_key] for feat_key in feature_keys if feat_key is not None]
            if not batched:
                sentence_pairs = [[sentences] for sentences in sentence_pairs]
            
            texts = [_concat_sentence_pair(pair, feature_keys) for pair in zip(*sentence_pairs)]
            # Text-to-text model need task prompt to do classification task
            if self.task_name is not None:
                texts = [f"{self.task_name} {text}" for text in texts]

            '''Tokenize'''

            features = tokenizer(
                texts, padding=padding,
                truncation=True, max_length=self.max_seq_length
            )
            features["id"] = examples.get("idx", examples.get("id", -1))

            '''Process labels'''

            if "label" in examples:
                # If the raw label is int, map it to class name
                if isinstance(examples["label"], int) or is_seq_of(examples["label"], int):
                    cls_id_to_str_label = {
                        cls_id: str_label for str_label, cls_id in \
                            STR_LABEL_TO_CLS_ID.get(self.task_name, {}).items()
                    }

                    cls_ids = examples["label"]
                    # Compatible with 'batched=False'
                    if isinstance(cls_ids, int):
                        cls_ids = [cls_ids]
                    
                    # Note: if some of the class ids are not existed in the mapping, use their str representation instead.
                    str_labels = [cls_id_to_str_label.get(cls_id, str(cls_id)) for cls_id in cls_ids]
                    # str_labels = [str(self.label_list[cls_id]) for cls_id in cls_ids]
                    # Compatible with 'batched=False'
                    if not batched:
                        str_labels = str_labels.pop()
                else:
                    if self.is_regression:
                        float_labels = examples["label"]
                        # Compatible with 'batched=False'
                        if isinstance(float_labels, float):
                            float_labels = [float_labels]
                        
                        str_labels = [str(l) for l in float_labels]
                        # Compatible with 'batched=False'
                        if not batched:
                            str_labels = str_labels.pop()
                    else:
                        str_labels = examples["label"]

                with tokenizer.as_target_tokenizer():
                    labels = tokenizer(
                        str_labels,
                        padding=padding, truncation=True,
                        max_length=self.max_answer_length
                    )

                # Label token ids
                labels_token_id = labels["input_ids"]
                # Compatible with 'batched=False'
                if not batched:
                    assert is_seq_of(labels_token_id, int)
                    labels_token_id = [labels_token_id]

                    assert isinstance(str_labels, str)
                    str_labels = [str_labels]

                # If we are padding here, replace all 'pad_token_id' in the labels by 'ignored_value_for_loss'
                # cuz we want to ignore padding in the loss.
                if padding and self.ignore_pad_token_for_loss:
                    labels_token_id = [
                        [(l if l != tokenizer.pad_token_id else self.ignored_value_for_loss) for l in label]
                        for label in labels_token_id
                    ]
                # Note: if the class name not exsited in the mapping, we will set its class id to -1
                class_ids = [STR_LABEL_TO_CLS_ID.get(self.task_name, {}).get(label, -1) for label in str_labels]
                # Compatible with 'batched=False'
                if not batched:
                    labels_token_id = labels_token_id.pop()
                    class_ids = class_ids.pop()

                # Ensure that features and labels are one-to-one
                if isinstance(labels_token_id[0], List) and isinstance(features["input_ids"][0], List):
                    assert len(labels_token_id) == len(features["input_ids"])
                if is_seq_of(class_ids, int) and isinstance(features["input_ids"][0], List):
                    assert len(class_ids) == len(features["input_ids"])

                features["labels"] = labels_token_id
                features["class_id"] = class_ids

                features["decoder_input_ids"] = _shift_tokens_right(
                    features["labels"],
                    model_config.pad_token_id,
                    model_config.decoder_start_token_id
                )

            return features

        if accelerator is not None:
            with accelerator.main_process_first():
                features = self.data.map(
                    generate_features,
                    batched=batched,
                    remove_columns=self.train_data.column_names,
                    desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} dataset",
                    load_from_cache_file=self.load_from_cache
                )
        else:
            features = self.data.map(
                generate_features,
                batched=batched,
                remove_columns=self.train_data.column_names,
                desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} dataset",
                load_from_cache_file=self.load_from_cache
            )
        self.features.update(features)
        
        return self.features

    def _get_dataloader(
        self, data: Union[DatasetDict, Dataset, IterableDatasetDict, IterableDataset], 
        batch_size: int, mode: bool = 'train',
        num_workers: int = 0, pin_memory: bool = True, 
        tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast] = None,
        model: nn.Module = None, seed: int = 0, rank: int = 0, **kwargs
    ):
        """
        Returns a dataloader according to the given dataset with specified batch size.

        Args:
            data (Union[DatasetDict, Dataset, IterableDatasetDict, IterableDataset]) : Dataset object.
            batch_size (int) : Number of data samples in a batch.
            train: (bool) : Training or not. Default is False.
            tokenizer (Union[PretrainedTokenizer, PretrainedTokenizerFast], optional) : Tokenizer object. Default is None.
        
        Returns:
            An instance of torch.utils.data.DataLoader.
        """

        if data is None or not len(data):
            self.logger.info(f"Note: input {mode} data IS NONE, SKIP building dataloader.")
            return None
        
        if not self.rank:
            # Log a few random samples from the training set
            for index in random.sample(range(len(data)), 3):
                self.logger.info(f"=> Sample {index} of the {mode} set: {data[index]}.")
        
        label_pad_token_id = self.ignored_value_for_loss \
            if self.ignore_pad_token_for_loss else tokenizer.pad_token_id
            
        data_collator = DataCollatorForSeq2Seq(
            tokenizer,
            model=model,
            label_pad_token_id=label_pad_token_id,
            pad_to_multiple_of=8 if self.use_fp16 else None,
        )

        with Timer(self.logger, job=f"=> Build {mode} dataloader"):
            shuffle = True if mode == 'train' else False
            dataloader = DataLoader(
                data, batch_size=batch_size,
                shuffle=shuffle, num_workers=num_workers,
                collate_fn=data_collator, pin_memory=pin_memory,
                # Set 'worker_init_fn' for randomness of multi-process
                # Random seed of different sub process in different rank is different
                worker_init_fn=reseed_workers_fn(num_workers, seed, rank=rank) if shuffle else None
            )

        return dataloader
