import os
import random

from logging import Logger
from typing import Dict, List, Tuple, Union

from torch.utils.data import DataLoader

from transformers.tokenization_utils import PreTrainedTokenizer
from transformers.tokenization_utils_fast import PreTrainedTokenizerFast
from transformers.data.data_collator import default_data_collator, DataCollatorWithPadding

from datasets import load_dataset, load_metric

from datasets.arrow_dataset import Dataset
from datasets.iterable_dataset import IterableDataset
from datasets.dataset_dict import DatasetDict, IterableDatasetDict

from utils.misc import Timer
from utils.dist import get_world_size
from utils.seed import reseed_workers_fn

from data.builder import DATA


BASE = os.path.dirname(__file__)


@DATA.register_module(name='nlp')
class NLPDataContainer:
    """
    A base data container of NLP tasks.
    Data container performs load dataset, generate features, form dataloader and any other data processing jobs.
    """
    
    # Local dataset scripts, 
    # they should be a script or a directory containing a script with the same name as the dataset
    DATASET_SCRIPT = {'glue': 'glue/glue.py', 'squad': 'squad/squad.py', 'cmrc2018': 'cmrc2018/cmrc2018.py'}
    METRIC_SCRIPT = {'glue': 'metrics/glue/glue.py', 'squad': 'metrics/squad/squad.py'}
    
    def __init__(
        self, dataset_name: str = None, task_name: str = None,
        train_file: str = None, val_file: str = None, test_file: str = None,
        train_batch_size: int = 4, val_batch_size: int = 4, test_batch_size: int = 1,
        num_workers: int = 0, pin_memory: bool = True, seed: int = 0, rank: int = 0,
        debug: bool = False, num_debug_samples: int = 0, use_fp16: bool = False, metric: str = 'accuracy', 
        logger: Logger = None, load_from_cache: bool = True,
        pad_to_max_seq_length: bool = True, max_seq_length: int = 128, **kwargs
    ):
        assert not (dataset_name is None and train_file is None and val_file is None)

        self.dataset_name = dataset_name
        self.task_name = task_name
        
        # Local dataset files
        self.train_file = train_file
        self.val_file = val_file
        self.test_file = test_file

        self.train_batch_size = train_batch_size
        if train_batch_size is None:
            self.train_batch_size = 1
        self.val_batch_size = val_batch_size
        if val_batch_size is None:
            self.val_batch_size = 1
        self.test_batch_size = test_batch_size
        
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        
        # Random seed
        self.seed = seed
        # Local rank in distributed training
        self.rank = rank

        # When in debug mode, data container will only select part of samples from dataset
        self.debug = debug
        # Num of samples will be selected when debugging
        self.num_debug_samples = max(num_debug_samples, 0) or self.train_batch_size * get_world_size() * 3

        self.use_fp16 = use_fp16

        # Whether to load features from cache
        # If a cache file storing the current computation can be identified, use it instead of recomputing.
        self.load_from_cache = load_from_cache

        self.logger = logger

        # Metric identifier, accuracy, f1, etc.
        self.metric = metric
        # A function or a callable object defines how to compute metrics
        self.metric_computor = self.load_metric()

        # Max sequence length
        self.max_seq_length = max_seq_length
        # Whether to pad all sequences to the max length
        self.pad_to_max_seq_length = pad_to_max_seq_length

        train_data_key = kwargs.pop('train_data_key', 'train')
        val_data_key = kwargs.pop('val_data_key', 'validation')
        test_data_key = kwargs.pop('test_data_key', 'test')
        self.train_data_key = train_data_key
        self.val_data_key = val_data_key
        self.test_data_key = test_data_key

        # Raw dataset & splited dataset
        self.data = self.train_data = self.val_data = self.test_data = None
        # Load dataset
        self.load_data()

        # Tokenized data
        self.features = {data_key: None for data_key in [train_data_key, val_data_key, test_data_key]}
        if set(self.features.keys()) != set(self.data.keys()):
            self.logger.warning(f"data keys in features:{set(self.features.keys())} mismatch those in data:{set(self.data.keys())}.")

        # Dataloaders
        self.dataloaders = {data_key: None for data_key in [train_data_key, val_data_key, test_data_key]}

    def load_data(self):
        """
        Get the datasets: you can either provide your own CSV/JSON training and evaluation files (see below)
        or specify a benchmark task (the dataset will be downloaded automatically from the datasets Hub).
        
        In distributed training, the load_dataset function guarantee that 
        only one local process can concurrently download the dataset.
        """

        # Loading the dataset from local csv or json file.
        if not (self.train_file is None and self.val_file is None):
            # For CSV/JSON files, this script will use as labels the column called 'label' and as pair of sentences the
            # sentences in columns called 'sentence1' and 'sentence2' if such column exists or the first two columns not named
            # label if at least two columns are provided.

            # If the CSVs/JSONs contain only one non-label column, the script does single sentence classification on this
            # single column. You can easily tweak this behavior (see below)
            data_files = {}
            if self.train_file is not None:
                data_files[self.train_data_key] = self.train_file
            if self.val_file is not None:
                data_files[self.val_data_key] = self.val_file
                if self.task_name and self.task_name.lower() == 'mnli':
                    data_files['validation_mismatched'] = self.val_file.replace('matched', 'mismatched')
            if self.test_file is not None:
                data_files[self.test_data_key] = self.test_file
                if self.task_name and self.task_name.lower() == 'mnli':
                    data_files['test_mismatched'] = self.test_file.replace('matched', 'mismatched')

            if isinstance(self.train_file, (List, Tuple)):
                f = self.train_file[0]
            elif isinstance(self.train_file, str):
                f = self.train_file
            elif isinstance(self.val_file, (List, Tuple)):
                f = self.val_file[0]
            elif isinstance(self.val_file, str):
                f = self.val_file
            else:
                raise RuntimeError(f"'train_file' or 'val_file' must be str or Sequence of str.")

            extension = f.split('.')[-1]
            data = load_dataset(extension, data_files=data_files)

            self.logger.info(f"Loaded local Dataset:\n{data}")
        # Downloading & loading a dataset.
        else:
            data = None
            if self.dataset_name is not None and self.DATASET_SCRIPT.get(self.dataset_name):
                local_script = os.path.join(BASE, self.DATASET_SCRIPT[self.dataset_name])
                if os.path.exists(local_script):
                    try:
                        data = load_dataset(local_script, self.task_name)
                        self.logger.info(f"Note: load dataset with local script:'{local_script}'.")
                    except:
                        self.logger.warninig(f"Note: failed with loading local dataset script:'{local_script}', use the online one instead.")
            if data is None:
                data = load_dataset(self.dataset_name, self.task_name)
            
            self.logger.info(f"Loaded Dataset:\n{data}")
        
        # See more about loading any type of standard or custom dataset at
        # https://huggingface.co/docs/datasets/loading_datasets.html.
        
        self.data = data
        self.logger.info(f"\nData Splits: {set(self.data.keys())}")
        self.logger.info(f"Data Columns: {data.column_names}\n")

        # Note:
        # The final train, val & test data usually processed by tokenizer
        # It is the initial state here
        self.train_data = data.get(self.train_data_key)
        self.val_data = data.get(self.val_data_key)
        self.test_data = data.get(self.test_data_key)
        self._checkout_data_split()

        if self.debug:
            self._select_part_of_data_for_debug(max_samples=self.num_debug_samples)

        return data
    
    def _checkout_data_split(self):
        if self.train_data is None:
            self.logger.warning(f"TRAIN data IS NONE, please checkout whether this is the normal behavior.")
        if self.val_data is None:
            self.logger.warning(f"VAL data IS NONE, please checkout whether this is the normal behavior.")
        if self.train_data is None:
            self.logger.warning(f"TEST data IS NONE, please checkout whether this is the normal behavior.")

    def _select_part_of_data_for_debug(self, max_samples=-1):
        """
        Select part of samples from dataset when in debug mode.
        """

        if not self.debug:
            return

        if max_samples <= 0:
            max_samples = self.train_batch_size * get_world_size() * 3
        assert max_samples > 0, f"Num of samples to select must be greater than 0, but got:{max_samples}"

        self.logger.info(f"Debug mode on!")
        # Note: num of samples should not exceed the size of dataset
        if self.train_data is not None:
            num_train_samples = min(max_samples, len(self.train_data))

            self.train_data = self.train_data.select(range(num_train_samples))
            self.logger.info(f"{num_train_samples} train samples selected.")

            idx = random.randint(0, num_train_samples - 1)
            self.logger.info(f"[train sample {idx}]:\n{self.train_data[idx]}\n")

            self.data[self.train_data_key] = self.train_data
        if self.val_data is not None:
            num_val_samples = min(max_samples, len(self.val_data))

            self.val_data = self.val_data.select(range(num_val_samples))
            self.logger.info(f"{num_val_samples} val samples selected.")

            idx = random.randint(0, num_val_samples - 1)
            self.logger.info(f"[val sample {idx}]:\n{self.val_data[idx]}\n")

            self.data[self.val_data_key] = self.val_data
        if self.test_data is not None:
            num_test_samples = min(max_samples, len(self.test_data))

            self.test_data = self.test_data.select(range(num_test_samples))
            self.logger.info(f"{num_test_samples} test samples selected.")

            idx = random.randint(0, num_test_samples)
            self.logger.info(f"[test sample {idx}]:\n{self.test_data[idx]}\n")
            self.data[self.test_data_key] = self.test_data

    def load_metric(self):
        """
        Load a Callable object defines how to compute metrics.
        """
        if self.dataset_name is not None:
            metric_computor = None
            if self.dataset_name in self.METRIC_SCRIPT:
                local_scipt = os.path.join(BASE, self.METRIC_SCRIPT[self.dataset_name])
                if os.path.exists(local_scipt):
                    try:
                        metric_computor = load_metric(local_scipt, self.task_name)
                        self.logger.info(f"Note: load metric from local script:'{local_scipt}'.")
                    except:
                        self.logger.warning(f"Note: failed with loading local metric script:'{local_scipt}', use the online one instead.")
            if metric_computor is None:
                metric_computor = load_metric(self.dataset_name, self.task_name)
        else:
            assert self.metric is not None
            metric_computor = load_metric(self.metric)
        
        return metric_computor

    def gen_features(self, **kwargs):
        """
        Generate features, i.e. tokenized data.
        """
        
        raise NotImplementedError("This method should be implemented by sub-class")

    @classmethod
    def _get_dataloader(
        cls, data: Union[DatasetDict, Dataset, IterableDatasetDict, IterableDataset], 
        batch_size: int, mode: bool = 'train',
        num_workers: int = 0, pin_memory: bool = True, 
        pad_to_max_seq_length: bool = True, tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast] = None,
        use_fp16: bool = False, seed: int = 0, rank: int = 0, logger: Logger = None, **kwargs
    ):
        """
        Returns a dataloader according to the given dataset with specified batch size.

        Args:
            data (Union[DatasetDict, Dataset, IterableDatasetDict, IterableDataset]) : Dataset object.
            batch_size (int) : Number of data samples in a batch.
            train: (bool) : Training or not. Default is False.
            tokenizer (Union[PretrainedTokenizer, PretrainedTokenizerFast], optional) : Tokenizer object. Default is None.
        
        Returns:
            An instance of torch.utils.data.DataLoader.
        """

        if data is None or not len(data):
            logger.info(f"Note: input {mode} data IS NONE, SKIP building dataloader.")
            return None
        
        if not rank:
            # Log a few random samples from the training set:
            for index in random.sample(range(len(data)), 2):
                logger.info(f"=> Sample {index} of the {mode} set: {data[index]}.")
        
        data_collator = kwargs.pop('data_collator', None)
        if data_collator is None:
            if pad_to_max_seq_length:
                # If padding was already done ot max length, 
                # we use the default data collator that will just convert everything to tensors.
                data_collator = default_data_collator
            else:
                # Otherwise, `DataCollatorWithPadding` will apply dynamic padding for us (by padding to the maximum length of
                # the samples passed). When using mixed precision, we add `pad_to_multiple_of=8` to pad all tensors to multiple
                # of 8s, which will enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta).
                assert tokenizer is not None
                data_collator = DataCollatorWithPadding(tokenizer, pad_to_multiple_of=(8 if use_fp16 else None))

        with Timer(logger, job=f"=> Build {mode} dataloader"):
            shuffle = True if mode == 'train' else False
            dataloader = DataLoader(
                data, batch_size=batch_size,
                shuffle=shuffle, num_workers=num_workers,
                collate_fn=data_collator, pin_memory=pin_memory,
                # Set 'worker_init_fn' for randomness of multi-process
                # Random seed of different sub process in different rank is different
                worker_init_fn=reseed_workers_fn(num_workers, seed, rank=rank) if shuffle else None
            )

        return dataloader

    def get_dataloaders(self, features=None, tokenizer=None, **kwargs) -> Dict[str, DataLoader]:
        """
        Get dataloaders of train, eval, test dataset.
        """
        
        if features is None:
            features = self.features
        
        batch_size_mapping = {
            self.train_data_key: self.train_batch_size,
            self.val_data_key: self.val_batch_size,
            self.test_data_key: self.test_batch_size
        }
        
        for k, features in features.items():
            batch_size = batch_size_mapping.get(k, 1)
            self.dataloaders[k] = self._get_dataloader(
                features, batch_size, mode=k,
                num_workers=self.num_workers, pin_memory=self.pin_memory,
                pad_to_max_seq_length=self.pad_to_max_seq_length, tokenizer=tokenizer,
                use_fp16=self.use_fp16, seed=self.seed, rank=self.rank, logger=self.logger, **kwargs
            )
        
        return self.dataloaders
