import os
import torch
import numpy as np

from itertools import chain
from typing import Dict, List

from datasets import load_metric
from dataclasses import dataclass

from torch.utils.data import DataLoader

from transformers import BatchEncoding, PreTrainedTokenizerBase

from data.builder import DATA
from data.nlp import NLPDataContainer


@DATA.register_module(name='span_masked_language_modeling')
class SpanMLMDataContainer(NLPDataContainer):
    def __init__(
        self,
        file_extension: str = '.json', metric: str = 'accuracy',
        train_dir: str = None, val_dir: str = None, test_dir: str = None,
        mlm_prob: float = 0.15, mean_noise_span_len: float = 3.0, **kwargs
    ):
        self.file_extension = file_extension

        self.val_dir = val_dir
        self.test_dir = test_dir
        self.train_dir = train_dir

        if self.train_dir:
            kwargs.update(train_file=self.extract_target_files_from_dir(self.train_dir, self.file_extension))
        if self.val_dir:
            kwargs.update(val_file=self.extract_target_files_from_dir(self.val_dir, self.file_extension))
        if self.test_dir:
            kwargs.update(test_file=self.extract_target_files_from_dir(self.test_dir, self.file_extension))

        # The probability with which to (randomly) mask tokens in the input
        self.mlm_prob = mlm_prob
        # The average span length of the masked tokens
        self.mean_noise_span_len = mean_noise_span_len

        super().__init__(metric=metric, **kwargs)

    @staticmethod
    def extract_target_files_from_dir(directory: str, extension: str):
        """
        Extract the files with specified format from a directory.
        """

        return list(
            map(
                lambda p: os.path.join(directory, p),
                filter(lambda f: f.endswith(extension), os.listdir(directory))
            )
        )

    @classmethod
    def compute_inputs_and_targets_len(cls, inputs_len: int, noise_density: float, mean_noise_span_len: int):
        """
        Refer to:
            <https://github.com/google-research/text-to-text-transfer-transformer/blob/84f8bcc14b5f2c03de51bd3587609ba8f6bbd1cd/t5/data/preprocessors.py#L2466>
        
        We assume that each noise span in the input is replaced by extra_tokens_per_span_inputs sentinel tokens,
        and each non-noise span in the targets is replaced by extra_tokens_per_span_targets sentinel tokens.
        This function tells us the required number of tokens in the raw example (for split_tokens())
        as well as the length of the encoded targets. 

        Note that this function assumes the inputs and targets will have EOS appended and includes 
        that in the reported length.

        Args:
            inputs_len (int): desired length of the tokenized input tokens.
            noise_density (float): ratio of tokens to mask for span masked language modeling loss.
            mean_noise_span_len (float): mean span length of masked tokens.
        """

        def _tokens_len_to_inputs_and_targets_len(tokens_len):
            num_noise_tokens = int(round(tokens_len * noise_density))
            num_non_noise_tokens = tokens_len - num_noise_tokens
            num_noise_spans = int(round(num_noise_tokens / mean_noise_span_len))

            # Inputs contain all non-noise tokens, sentinels for all noise spans and one EOS token.
            _inputs_len = num_non_noise_tokens + num_noise_spans + 1
            # Targets contain all noise tokens, sentinels for all noise spans and one EOS token.
            _targets_len = num_noise_tokens + num_noise_spans + 1

            return _inputs_len, _targets_len
        
        expected_tokens_len = inputs_len
        expected_inputs_len, _ = _tokens_len_to_inputs_and_targets_len(expected_tokens_len + 1)
        while expected_inputs_len <= inputs_len:
            expected_tokens_len += 1
            expected_inputs_len, _ = _tokens_len_to_inputs_and_targets_len(expected_tokens_len + 1)
        
        inputs_len, targets_len = _tokens_len_to_inputs_and_targets_len(expected_tokens_len)
        # Minor hack to get the targets length to be equal to inputs length
        # which is more likely to have been set to a nice round number.
        if noise_density == .5 and targets_len > inputs_len:
            targets_len -= 1
            expected_tokens_len -= 1
        
        return expected_tokens_len, targets_len
    
    def load_metric(self):
        return load_metric(self.metric)
    
    def gen_features(self, tokenizer, batched=True, **kwargs):
        # Text column name of dataframe
        text_column_name=kwargs.pop('text_column_name', 'text')

        self.expanded_inputs_len, self.targets_len = self.compute_inputs_and_targets_len(
            self.max_seq_length, self.mlm_prob, self.mean_noise_span_len
        )
        self.logger.info(f"\n=> expanded inputs len = {self.expanded_inputs_len}, targets len = {self.targets_len}\n")

        def _generate_features(examples):
            # We tokenize every text, then concatenate them together before splitting them in smaller parts.
            # Since we make sure that all sequences are of the same length, no attention_mask is needed.
            tokenized_examples = tokenizer(examples[text_column_name], return_attention_mask=False)
            # Concatenate all texts from dataset and generate chunks of expanded_inputs_length.
            concated_examples = {k: list(chain(*tokenized_examples[k])) for k in tokenized_examples.keys()}
            
            # Number of tokens of all texts
            total_texts_len = len(concated_examples[list(tokenized_examples.keys())[0]])
            # Token length of each sample is 'expanded_inputs_len', so we make 'total_texts_len' the multiple
            # of 'expanded_inputs_len', this will truncate the extra parts
            if total_texts_len >= self.expanded_inputs_len:
                total_texts_len = (total_texts_len // self.expanded_inputs_len) * self.expanded_inputs_len
            
            # Split by chunks of 'expanded_inputs_len'
            features = {
                k: [v[i:i + self.expanded_inputs_len] for i in range(0, total_texts_len, self.expanded_inputs_len)]
                for k, v in concated_examples.items()
            }

            return features

        # We don't let main process begin first here cuz this will slow up the progress
        features = self.data.map(
            _generate_features,
            batched=batched,
            remove_columns=self.train_data.column_names,
            desc=f"[rank{self.rank}]Running tokenizer on {self.dataset_name} dataset",
            load_from_cache_file=self.load_from_cache
        )
        self.features.update(features)
        
        return self.features
    
    def get_dataloaders(self, features=None, tokenizer=None, **kwargs) -> Dict[str, DataLoader]:
        model = kwargs.pop('model')
        data_collator = DataCollatorForSpanMaksedLanguageModeling(
            tokenizer=tokenizer,
            noise_density=self.mlm_prob,
            mean_noise_span_len=self.mean_noise_span_len,
            input_length=self.max_seq_length,
            target_length=self.targets_len,
            pad_token_id=model.config.pad_token_id,
            decoder_start_token_id=model.config.decoder_start_token_id,
            return_tensors=kwargs.pop('return_tensors', True),
            prepend_batch_axis=kwargs.pop('prepend_batch_axis', False)
        )
        kwargs.update(data_collator=data_collator)

        return super().get_dataloaders(features, tokenizer, **kwargs)


@dataclass
class DataCollatorForSpanMaksedLanguageModeling:
    """
    Data collator used for T5 span-masked language modeling.
    It is made sure that after masking the inputs are of length `data_args.max_seq_length` and targets are also of fixed length.
    For more information on how T5 span-masked language modeling works, one can take a look
    at the `official paper <https://arxiv.org/pdf/1910.10683.pdf>`__
    or the `official code for preprocessing <https://github.com/google-research/text-to-text-transfer-transformer/blob/master/t5/data/preprocessors.py>`__ .
    
    Args:
        tokenizer (:class:`~transformers.PreTrainedTokenizer` or :class:`~transformers.PreTrainedTokenizerFast`):
            The tokenizer used for encoding the data.
        noise_density (:obj:`float`):
            The probability with which to (randomly) mask tokens in the input.
        mean_noise_span_len (:obj:`float`):
            The average span length of the masked tokens.
        input_length (:obj:`int`):
            The expected input length after masking.
        target_length (:obj:`int`):
            The expected target length after masking.
        pad_token_id: (:obj:`int`):
            The pad token id of the model
        decoder_start_token_id: (:obj:`int):
            The decoder start token id of the model
    """

    tokenizer: PreTrainedTokenizerBase

    noise_density: float
    mean_noise_span_len: float

    input_length: int
    target_length: int

    pad_token_id: int
    decoder_start_token_id: int

    return_tensors: bool
    prepend_batch_axis: bool

    def __call__(self, examples: List[Dict[str, np.ndarray]]) -> Dict[str, np.ndarray]:
        data_keys = examples[0].keys()
        assert 'input_ids' in data_keys, f"data keys must contain 'input_ids'."

        # Convert list to dict and tensorize input
        batch = BatchEncoding({
            k: np.array([examples[i][k] for i in range(len(examples))])
            for k in data_keys
        })

        input_ids = batch['input_ids']
        batch_size, expanded_inputs_len = input_ids.shape

        # Bool type, True for masked tokens, False for others
        # (B,expanded_inputs_len)
        noise_masks = np.asarray([self._create_noise_mask(expanded_inputs_len) for _ in range(batch_size)])
        # Labels are those masked input tokens, so the 'label_masks' is reversed 'noise_masks'
        label_masks = ~noise_masks

        # Value of each position are one of 0, -1, sentinel id
        # (B,expanded_inputs_len)
        input_ids_sentinel = self._create_sentinel_ids(noise_masks.astype(np.int8))
        labels_sentinel = self._create_sentinel_ids(label_masks.astype(np.int8))

        # (B,input_length)
        batch['input_ids'] = self._filter_input_ids(input_ids, input_ids_sentinel)
        assert batch['input_ids'].shape[-1] == self.input_length, \
            f"`input_ids` are incorrectly preprocessed. `input_ids` length is {batch['input_ids'].shape[-1]}, but should be {self.target_length}."
        
        # (B,target_length)
        batch['labels'] = self._filter_input_ids(input_ids, labels_sentinel)
        assert batch['labels'].shape[-1] == self.target_length, \
            f"`labels` are incorrectly preprocessed. `labels` length is {batch['labels'].shape[-1]}, but should be {self.target_length}."
        
        # Note: to check that tokens are correctly preprocessed, u can run 
        # `self.tokenizer.batch_decode(input_ids)` and `self.tokenizer.batch_decode(labels)` here.

        batch['decoder_input_ids'] = self._shift_tokens_right(batch['labels'], self.pad_token_id, self.decoder_start_token_id)
        
        if self.return_tensors:
            batch = self._convert_to_tensors(batch)

        return batch

    def _create_noise_mask(self, seq_len: int) -> np.ndarray:
        """
        This function is copy of `random_spans_helper <https://github.com/google-research/text-to-text-transfer-transformer/blob/84f8bcc14b5f2c03de51bd3587609ba8f6bbd1cd/t5/data/preprocessors.py#L2682>`__ .
        
        Noise mask consisting of random spans of noise tokens.
        The number of noise tokens and the number of noise spans and non-noise spans
        are determined deterministically as follows:
            
            num_noise_tokens = round(length * noise_density)
            num_non_noise_spans = num_noise_spans = round(num_noise_tokens / mean_noise_span_len)

        Spans alternate between non-noise and noise, beginning with non-noise.
        Subject to the above restrictions, all masks are equally likely.
        
        Args:
            seq_len (int): length of the in-coming token sequence
            noise_density (float): approximate density of output mask
            mean_noise_span_len (float): the average span length of the masked tokens.
        
        Returns:
            a boolean array with shape (seq_len,)
        """

        # Avoid degeneracy by ensuring positive numbers of noise and nonnoise tokens.
        num_noise_tokens = min(
            max(int(round(self.noise_density * seq_len)), 1),
            seq_len - 1
        )
        num_non_noise_tokens = seq_len - num_noise_tokens
        # Avoid degeneracy by ensuring positive numbers of noise and nonnoise tokens.
        num_noise_spans = max(int(round(num_noise_tokens / self.mean_noise_span_len)), 1)

        def _random_segment(num_items, num_segments):
            """
            Partition a sequence of items randomly into non-empty segments.
            
            Args:
                num_items: an integer scalar > 0
                num_segments: an integer scalar in [1, num_items]
            
            Returns:
                a Tensor with shape [num_segments] containing positive integers that add
                up to num_items
            """

            # Mark the count of segments to: x, so x segments only need (x-1) segment indicator.
            # and because we will insert a item to make the segment id start with 0(see below),
            # the range should be 'num_items' - 1 (instead of num_items).
            mask = np.arange(num_items - 1) < num_segments - 1
            np.random.shuffle(mask)
            # Pad 1 zero-value to the head, in order to make the 'segment_id' start with 0
            mask = np.pad(mask, (1, 0))

            # Those positions with same ids belong to a common segment.
            segment_ids = np.cumsum(mask)
            # Count length of sub segments assuming that list is sorted
            # (num_segments,)
            _, segments_len = np.unique(segment_ids, return_counts=True)

            return segments_len

        # Pick the lengths of the noise spans and the non-noise spans
        # (num_noise_spans,)
        noise_span_lens = _random_segment(num_noise_tokens, num_noise_spans)
        # (num_noise_spans,)
        non_noise_span_lens = _random_segment(num_non_noise_tokens, num_noise_spans)
        
        # Spans alternate between non-noise and noise, beginning with non-noise.
        # (num_noise_spans,2)->(num_noise_spans*2,)
        interleaved_span_lens = np.reshape(
            np.stack([non_noise_span_lens, noise_span_lens], axis=-1),
            (num_noise_spans * 2,)
        )
        # The last span start position is indicated by the 2nd last
        spans_start = np.cumsum(interleaved_span_lens)[:-1]
        spans_start_indicator = np.zeros((seq_len,), dtype=np.int8)
        spans_start_indicator[spans_start] = 1

        span_ids = np.cumsum(spans_start_indicator)
        # 0 for non-noise & 1 for noise
        # Odd positions are the noise since we beginning with non-noise spans(see above),
        # this ensure that masked positions belong to noise tokens.
        is_noise = (span_ids % 2).astype(bool)

        return is_noise[:seq_len]

    def _create_sentinel_ids(self, mask):
        """
        Sentinel ids creation given the indices that should be masked.
        The start indices of each mask are replaced by the sentinel ids in increasing order. 
        Consecutive mask indices to be deleted are replaced with `-1`.
        """

        # Only the start position of each span will be kept
        start_indicators = mask * (1 - np.roll(mask, 1, axis=-1))
        start_indicators[:, 0] = mask[:, 0]

        sentinel_ids = np.where(start_indicators != 0, np.cumsum(start_indicators, axis=-1), 0)
        sentinel_ids = np.where(start_indicators != 0, len(self.tokenizer) - sentinel_ids, 0)
        
        # Masked positions with start position excluded of each masked span(1 for these postions)
        masked_exclude_each_start = mask - start_indicators
        # So the value of masked positions with start position excluded of each span will be replaced by -1
        sentinel_ids -= masked_exclude_each_start

        # Those un-masked are kept to be 0
        return sentinel_ids

    def _filter_input_ids(self, input_ids, sentinel_ids):
        """
        Puts sentinel mask on `input_ids` and fuse consecutive mask tokens into a single mask token by deleting.
        This will reduce the sequence length from `expanded_inputs_length` to `desired_input_length`.
        """

        batch_size = input_ids.shape[0]

        # 'sentinel_ids == 0' are those postions of non-masked tokens.
        # (B,expanded_inputs_length)
        input_ids_w_sentinel = np.where(sentinel_ids == 0, input_ids, sentinel_ids)
        # Filter out those masked tokens(which indicated by value -1)
        # (B,desired_input_length-1)
        input_ids_wo_masked_tokens = input_ids_w_sentinel[input_ids_w_sentinel >= 0].reshape((batch_size, -1))

        # Append eos token
        filtered_input_ids = np.concatenate(
            [
                input_ids_wo_masked_tokens,
                np.full((batch_size, 1), self.tokenizer.eos_token_id, dtype=np.int32)
            ],
            axis=-1
        )
        return filtered_input_ids

    def _shift_tokens_right(self, input_ids: np.array, pad_token_id: int, decoder_start_token_id: int) -> np.ndarray:
        """
        Shift input ids one token to the right.
        """

        shifted_input_ids = np.zeros_like(input_ids)
        shifted_input_ids[:, 1:] = input_ids[:, :-1]
        
        shifted_input_ids[:, 0] = decoder_start_token_id
        shifted_input_ids = np.where(shifted_input_ids == -100, pad_token_id, shifted_input_ids)

        return shifted_input_ids
    
    def _convert_to_tensors(self, items):
        """
        Convert the inner content to tensors.

        Args:
            tensor_type (`str` or [`~file_utils.TensorType`], *optional*):
                The type of tensors to use. If `str`, should be one of the values of the enum
                [`~file_utils.TensorType`]. If `None`, no modification is done.
            prepend_batch_axis (`int`, *optional*, defaults to `False`):
                Whether or not to add the batch dimension during the conversion.
        """

        # Do the tensor conversion in batch
        for key, value in items.items():
            try:
                if self.prepend_batch_axis:
                    value = [value]
                if not torch.is_tensor(value):
                    items[key] = torch.tensor(value)
            except:  # noqa E722
                if key == "overflowing_tokens":
                    raise ValueError(
                        "Unable to create tensor returning overflowing tokens of different lengths. "
                        "Please see if a fast version of this tokenizer is available to have this feature available."
                    )
                raise ValueError(
                    "Unable to create tensor, you should probably activate truncation and/or padding "
                    "with 'padding=True' 'truncation=True' to have batched tensors with the same length."
                )

        return items
