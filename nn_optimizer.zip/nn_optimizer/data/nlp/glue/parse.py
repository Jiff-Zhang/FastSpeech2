import argparse

from config.data.glue.cfg import TASK_TO_KEYS


def parse_args():
    """Parse command line arguments & update default configurations"""

    parser = argparse.ArgumentParser(
        description="Finetune a transformers model on a text classification task"
    )

    parser.add_argument(
        "--task_name",
        type=str,
        default=None,
        help="The name of the glue task to train on.",
        choices=list(TASK_TO_KEYS.keys()),
    )
    parser.add_argument('--cfg', type=str, metavar="FILE", help='path to config file')
    parser.add_argument(
        "--train_file", type=str, default=None, help="A csv or a json file containing the training data."
    )
    parser.add_argument(
        "--val_file", type=str, default=None, help="A csv or a json file containing the validation data."
    )

    parser.add_argument(
        "--max_seq_length",
        type=int,
        help=(
            "The maximum total input sequence length after tokenization. Sequences longer than this will be truncated,"
            " sequences shorter will be padded if `--pad_to_max_lengh` is passed."
        )
    )
    parser.add_argument(
        "--pad_to_max_seq_length",
        action="store_true",
        help="If passed, pad all samples to `max_seq_length`. Otherwise, dynamic padding is used.",
    )
    parser.add_argument(
        "--model_type",
        type=str,
        help="Path to pretrained model or model identifier from huggingface.co/models."
    )
    parser.add_argument(
        "--cls_dropout",
        type=float,
        help='model classifier dropout rate'
    )
    parser.add_argument(
        "--use_slow_tokenizer",
        action="store_true",
        help="If passed, will use a slow tokenizer (not backed by the 🤗 Tokenizers library).",
    )

    parser.add_argument(
        "--train_batch_size",
        type=int,
        help="Batch size (per device) for the training dataloader.",
    )
    parser.add_argument(
        "--val_batch_size",
        type=int,
        help="Batch size (per device) for the evaluation dataloader.",
    )

    parser.add_argument(
        "--lr",
        type=float,
        help="Initial learning rate (after the potential warmup period) to use.",
    )
    parser.add_argument('--linear_scaled_lr', action='store_true',
                        help='linear scale the learning rate according to total batch size')
    parser.add_argument("--optimizer", type=str, help='optimizer name')
    parser.add_argument("--child_tuning_adamw_mode", type=str,
                        help='Child Tuning AdamW optimizer mode, choices of [None, "F", "D"]')
    parser.add_argument(
        "--lr_scheduler_type",
        type=str,
        help="The scheduler type to use.",
        choices=["linear", "constant_linear", "cosine", "cosine_with_restarts", "polynomial", "constant", "constant_with_warmup"],
    )
    parser.add_argument("--weight_decay", type=float, default=None, help="Weight decay to use.")
    
    parser.add_argument("--epochs", type=int, help="Total number of training epochs to perform.")
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        help="Number of updates steps to accumulate before performing a backward/update pass.",
    )
    parser.add_argument(
        "--warmup_steps", type=int, help="Number of steps for the warmup in the lr scheduler."
    )
    parser.add_argument('--early_stop', action='store_true', help='whether to use early stopping')
    parser.add_argument('--max_early_stop_epochs', type=int,
                        help="Early stop when we cannot get better performance by continuous epochs of this value")

    parser.add_argument("--seed", type=int, help="A seed for reproducible training.")
    parser.add_argument('--resume', type=str, help='path to the checkpoint should be resume from')
    parser.add_argument('--auto_resume', action='store_true', help='whether to auto resume from history')
    parser.add_argument("--output_dir", type=str, default="outputs", help="Where to store the final model.")

    parser.add_argument("--push_to_hub", action="store_true", help="Whether or not to push the model to the Hub.")
    parser.add_argument("--hub_model_id", type=str, 
                        help="The name of the repository to keep in sync with the local `output_dir`."
    )
    parser.add_argument("--hub_token", type=str, help="The token to use to push to the Model Hub.")
    
    parser.add_argument("--opts", default=None, nargs='+', help="Modify config options by adding 'KEY VALUE' pairs")

    # Prune
    parser.add_argument('--pruning', action='store_true', help='whether to prune')
    parser.add_argument('--aug_train', action='store_true')
    parser.add_argument('--pred_distill', action='store_true')
    parser.add_argument('--temperature', type=float)
    parser.add_argument('--sparse_steps', type=int, help='total sparse steps, default is the training steps')
    parser.add_argument('--prune_sparsity',type=float, help='sparsity rate')
    parser.add_argument('--prune_deploy_device',type=str,
                        help='also known as balance. options none, fix=asic, fpga')
    parser.add_argument('--prune_group_size',type=int, help='also known as bank_size')
    parser.add_argument('--prune_frequency',type=int, help='also known as bank_size')
    parser.add_argument('--fixed_mask', type=str, help="Fixed mask path.")
    parser.add_argument('--mask', type=str, help="mask path")

    # Kd
    parser.add_argument('--kd_on', action='store_true', help='whether to use knowledge distillation')
    parser.add_argument('--kd_cls_loss', default='soft_ce', help='kd loss for output logits')
    parser.add_argument('--kd_reg_loss', default='mse', help='kd loss for Transformer layers')
    parser.add_argument('--teacher_path', type=str, help='path to eacher state dict')
    parser.add_argument('--teacher_init', action='store_true', help='use teacher weight to initialize student')

    parser.add_argument('--debug', action='store_true', help='whether to debug')

    args, _ = parser.parse_known_args()
    # Sanity checks
    if args.task_name is None and args.train_file is None and args.val_file is None:
        raise ValueError("Need either a task name or a training/validation file.")
    else:
        if args.train_file is not None:
            extension = args.train_file.split(".")[-1]
            assert extension in ["csv", "json"], "`train_file` should be a csv or a json file."
        if args.val_file is not None:
            extension = args.val_file.split(".")[-1]
            assert extension in ["csv", "json"], "`validation_file` should be a csv or a json file."
    
    if args.push_to_hub:
        assert args.output_dir is not None, "Need an `output_dir` to create a repo when `--push_to_hub` is passed."

    return args
