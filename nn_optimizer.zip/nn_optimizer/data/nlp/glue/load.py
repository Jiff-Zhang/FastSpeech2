import time
import random
import datetime

from torch.utils.data import DataLoader
from datasets import load_dataset, load_metric
from transformers import default_data_collator, DataCollatorWithPadding

from utils.seed import reseed_workers_fn


def load_data(name="glue", task_name=None, train_file=None, val_file=None):
    """
    Get the datasets: you can either provide your own CSV/JSON training and evaluation files (see below)
    or specify a GLUE benchmark task (the dataset will be downloaded automatically from the datasets Hub).
    
    In distributed training, the load_dataset function guarantee that 
    only one local process can concurrently download the dataset.
    """

    # Downloading and loading a dataset from the hub.
    if task_name is not None:
        data = load_dataset(name, task_name)
    # Loading the dataset from local csv or json file.
    else:
        # For CSV/JSON files, this script will use as labels the column called 'label' and as pair of sentences the
        # sentences in columns called 'sentence1' and 'sentence2' if such column exists or the first two columns not named
        # label if at least two columns are provided.

        # If the CSVs/JSONs contain only one non-label column, the script does single sentence classification on this
        # single column. You can easily tweak this behavior (see below)
        data_files = {}
        if train_file is not None:
            data_files["train"] = train_file
        if val_file is not None:
            data_files["validation"] = val_file

        extension = (train_file if train_file is not None else val_file).split(".")[-1]
        data = load_dataset(extension, data_files=data_files)
    # See more about loading any type of standard or custom dataset at
    # https://huggingface.co/docs/datasets/loading_datasets.html.

    # Labels
    if task_name is not None:
        try:
            metric_computor = load_metric("glue", task_name)
        except:
            metric_computor = None

        is_regression = task_name == "stsb"
        if is_regression:
            num_labels = 1
        else:
            label_list = data["train"].features["label"].names
            num_labels = len(label_list)
    else:
        # Trying to have good defaults here, don't hesitate to tweak to your needs.
        is_regression = data["train"].features["label"].dtype in ["float32", "float64"]
        if is_regression:
            num_labels = 1
        else:
            try:
                metric_computor = load_metric("accuracy")
            except:
                metric_computor = None
                
            # A useful fast method:
            # https://huggingface.co/docs/datasets/package_reference/main_classes.html#datasets.Dataset.unique
            label_list = data["train"].unique("label")
            label_list.sort()  # Let's sort it for determinism
            num_labels = len(label_list)
    
    return data, label_list, num_labels, is_regression, metric_computor


def get_dataloader(data, tokenizer, config, logger, train=True, batch_size=None, debug=False, use_fp16=False):
    mode = 'train' if train else 'eval'
    if not batch_size:
        batch_size = config.DATA.TRAIN_BATCH_SIZE if train else config.DATA.VAL_BATCH_SIZE
    if debug:
        num_samples = batch_size * 8 * 10
        data = data.select(range(num_samples))
        logger.info(f"=> Debug mode on! {num_samples} {mode} samples\n")
    
    # Log a few random samples from the training set:
    for index in random.sample(range(len(data)), 2):
        logger.info(f"=> Sample {index} of the {mode} set: {data[index]}.")
    
    if config.DATA.PAD_TO_MAX_SEQ_LENGTH:
        # If padding was already done ot max length, 
        # we use the default data collator that will just convert everything to tensors.
        data_collator = default_data_collator
    else:
        # Otherwise, `DataCollatorWithPadding` will apply dynamic padding for us (by padding to the maximum length of
        # the samples passed). When using mixed precision, we add `pad_to_multiple_of=8` to pad all tensors to multiple
        # of 8s, which will enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta).
        data_collator = DataCollatorWithPadding(tokenizer, pad_to_multiple_of=(8 if use_fp16 else None))

    s = time.time()
    shuffle = True if train else False
    dataloader = DataLoader(
        data, batch_size=batch_size,
        shuffle=shuffle, num_workers=config.DATA.NUM_WORKERS,
        collate_fn=data_collator, pin_memory=config.DATA.PIN_MEMORY,
        # Set 'worker_init_fn' for randomness of multi-process
        # Random seed of different sub process in different rank is different
        worker_init_fn=reseed_workers_fn(
            config.DATA.NUM_WORKERS, config.SEED, rank=config.LOCAL_RANK
        ) if shuffle else None
    )
    used = time.time() - s
    logger.info(f"=> {mode} dataloader takes time:{datetime.timedelta(used)}\n")

    return dataloader


def get_train_val_dataloaders(data, tokenizer, config, logger, use_fp16=False):
    train_data = data['train']
    val_data = data['validation_matched' if config.DATA.TASK_NAME == 'mnli' else 'validation']

    train_dataloader = get_dataloader(train_data, tokenizer, config, logger, debug=config.DEBUG, use_fp16=use_fp16)
    val_dataloader = get_dataloader(val_data, tokenizer, config, logger, train=False, debug=config.DEBUG, use_fp16=use_fp16)

    return train_dataloader, val_dataloader
