import torch
import random

from itertools import cycle
from typing import Iterable
from bisect import bisect_right

from accelerate import Accelerator
from torch.utils.data.dataloader import DataLoader


class ConcatDataLoader:
    @staticmethod
    def cumsum(seq: Iterable):
        r, s = [], 0
        for sub in seq:
            # l = len(sub)
            # r.append(s + l)
            # s += l

            s += len(sub)
            r.append(s)

        return r
    
    def __new__(cls, dataloaders: Iterable[DataLoader], *args, **kwargs):
        dataloader_list = list(dataloaders)
        # If only one dataloader passed here,
        # we keep using the original type, not modifying anything.
        if len(dataloader_list) == 1:
            return dataloader_list.pop()
        # Otherwise, the truly ConcatDataloader type returns.
        else:
            return super().__new__(cls)

    def __init__(
        self, dataloaders: Iterable[DataLoader],
        shuffle: bool = True, random_select: bool = True,
        accelerator: Accelerator = None
    ):
        dataloader_list = list(dataloaders)
        if len(dataloader_list) > 1:
            # Cuz accelerate only process Pytorch DataLoader, we should do this spliting operation here,
            # instead of doing outside(i.e. in the main program flow)
            if accelerator is not None:
                dataloader_list = [accelerator.prepare_data_loader(dataloader) for dataloader in dataloader_list]
            self.dataloaders = dataloader_list

            # Whether to shuffle the order of batches yield from each dataloader.
            self.shuffle = shuffle
            # If true, random select a dataloader to yield batch in each data iteration. 
            self.random_select = random_select

            self._init()
    
    def _init(self):
        # Cumulate sum of batch counts.
        self.cum_num_batches = self.cumsum(self.dataloaders)
        self._verify()

        self.dataloader_iters = [iter(dataloader) for dataloader in self.dataloaders]
        if not self.random_select:
            self.batch_idx = 0
    
    def _verify(self):
        if len(self.dataloaders) != len(self.cum_num_batches):
            raise RuntimeError(f"num of dataloaders: {len(self.dataloaders)} != num of cum_num_batches: {len(self.cum_num_batches)}")
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.random_select:
            # If the dataloader has been selected is already stopped,
            # kick it out & select another one until there is no one can be picked. 
            while self.dataloader_iters:
                self.dataloader_idx = random.choice(range(len(self.dataloader_iters)))
                try:
                    return next(self.dataloader_iters[self.dataloader_idx])
                except StopIteration:
                    self.dataloader_iters.pop(self.dataloader_idx)
        else:
            if self.batch_idx < len(self):
                # Decide which dataloader should play now
                self.dataloader_idx = bisect_right(self.cum_num_batches, self.batch_idx)
                self.batch_idx += 1
                
                try:
                    return next(self.dataloader_iters[self.dataloader_idx])
                # In normal, this will not occur, because we use 'batch_idx' to extract data from all dataloaders
                except StopIteration:
                    pass

        self._reset()
        raise StopIteration

    def __len__(self):
        return self.cum_num_batches[-1]

    def _reset(self):
        if self.shuffle:
            random.shuffle(self.dataloaders)

        self._init()
    
    @property
    def batch_size(self):
        # We assume that the batch size of each dataloader equals,
        # so directly use the batch size of the first one dataloader.
        return self.dataloaders[0].batch_size


class MixupDataLoader:
    """
    A dataloader of Iterable type mixing up a batch yield from multiple dataloaders,
    'mixup' means shuffle the data from different dataloaders.
    
    Note:
        The final batch size is sum of batch size of each dataloader(not requiring batch).
    """

    def __new__(cls, dataloaders: Iterable[DataLoader], *args, **kwargs):
        dataloader_list = list(dataloaders)
        # If only one dataloader, we will keep the original dataloader type
        if len(dataloader_list) == 1:
            return dataloader_list.pop()
        # Otherwise, the truely 'MixupDataLoader' instance returns
        else:
            return super().__new__(cls)
    
    def __init__(self, dataloaders: Iterable[DataLoader], accelerator: Accelerator = None) -> None:
        dataloader_list = list(dataloaders)
        if len(dataloader_list) > 1:
            # The final batch size is sum of batch size of each dataloader.
            self.batch_size = sum(dataloader.batch_size for dataloader in dataloader_list)

            # Cuz accelerate only process Pytorch DataLoader, we should do this spliting operation here,
            # instead of doing outside(i.e. in the main program flow)
            if accelerator is not None:
                dataloader_list = [accelerator.prepare_data_loader(dataloader) for dataloader in dataloader_list]            
            self._dataloaders = dataloader_list

            max_dataloader_len = 0
            for i, dataloader in enumerate(dataloader_list):
                if len(dataloader) > max_dataloader_len:
                    max_idx = i
                    max_dataloader_len = len(dataloader)
            self._main_dataloader_idx = max_idx
            self._num_batches = max_dataloader_len

            # Beside the dataloader which has the most batches,
            # other ones will be set as an cycling iterator,
            # thus making them align with the dataloader that has the most batches. 
            self.data_chain = iter(
                zip(*[
                    cycle(dataloader) if i != max_idx else dataloader
                    for i, dataloader in enumerate(dataloader_list)
                ])
            )

    def __len__(self):
        return self._num_batches

    def __iter__(self):
        return self

    def __next__(self):
        try:
            # A tuple consist of batches yield from each dataloader.
            batch_tuple = next(self.data_chain)
            device = batch_tuple[0]['input_ids'].device
            
            data_keys = set(batch_tuple[0].keys())
            for batch in batch_tuple:
                data_keys.update(batch.keys())

            # Padding batch for missing keys, cuz data keys of each dataloader may not the same.
            for k in data_keys:
                for batch in batch_tuple:
                    if k not in batch:
                        if k == 'attention_mask':
                            batch[k] = torch.ones_like(batch['input_ids'])
                        elif 'id' in k:
                            batch[k] = torch.full(
                                (batch['input_ids'].size(0),), -1,
                                device=device, dtype=torch.long
                            )
                        # Leave for future
                        else:
                            pass

            # We compute the sample counts in-time instead of using sum of batch size of each dataloader here
            # incase of the 'batch padding' case.
            num_samples = sum(batch['input_ids'].size(0) for batch in batch_tuple)
            # Useful for mixing up & shuffling data inside each batch yield from each dataloader
            random_indices = torch.randperm(num_samples, device=device)

            # Concat the data generate from each dataloder
            mixup_batch = {}
            for k in data_keys:
                mixup_data = torch.empty(
                    (num_samples,) + batch_tuple[0][k].shape[1:],
                    device=device, dtype=batch_tuple[0][k].dtype
                )
                mixup_data[random_indices] = torch.cat(tuple(batch[k] for batch in batch_tuple))
                mixup_batch[k] = mixup_data
            
            return mixup_batch
        except StopIteration:
            self._reset()
            raise StopIteration

    def _reset(self):
        self.data_chain = iter(
            zip(*[
                cycle(dataloader) if i != self._main_dataloader_idx else dataloader
                for i, dataloader in enumerate(self._dataloaders)
            ])
        )
