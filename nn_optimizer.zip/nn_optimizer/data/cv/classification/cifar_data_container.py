from torchvision import transforms
from torchvision.datasets import CIFAR10,CIFAR100
from torch.utils.data.dataloader import DataLoader
from torch.utils.data.distributed import DistributedSampler

from data.builder import DATA


@DATA.register_module(name='cifar')
class Cifar10DataContainer:
    def __init__(self, root_dir, batch_size, num_classes, num_workers=16, rank=-1):
        super().__init__()
        
        self.batch_size = batch_size
        self.num_workers= num_workers
        self.root_dir = root_dir
        self.rank = rank
        self.dataloaders = {
            'train': None,
            'validation': None,
            'test': None
        }

        if num_classes==10:
            self.dataset = CIFAR10
        elif num_classes==100:
            self.dataset = CIFAR100
        else:
            raise NotImplementedError("nonsupport dataset type")

    def get_dataloaders(self):
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        trainset = self.dataset(root=self.root_dir, train=True, download=True, transform=transform)
        testset = self.dataset(root=self.root_dir, train=False, download=True, transform=transform)
        
        if self.rank != -1:
            train_sampler = DistributedSampler(trainset)
            test_sampler = DistributedSampler(testset)
            trainloader = DataLoader(trainset, batch_size=self.batch_size, shuffle=False,sampler=train_sampler,num_workers=self.num_workers)
            testloader = DataLoader(testset, batch_size=self.batch_size, shuffle=False,sampler=test_sampler,num_workers=self.num_workers)
        else:
            trainloader = DataLoader(trainset, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers)
            testloader = DataLoader(testset, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)
        
        # Make this compatible with other dataloader implements
        trainloader.data_size = len(trainset)
        testloader.data_size = len(testset)

        self.dataloaders.update(
            {
                'train': trainloader,
                'validation': testloader
            }
        )
        return self.dataloaders