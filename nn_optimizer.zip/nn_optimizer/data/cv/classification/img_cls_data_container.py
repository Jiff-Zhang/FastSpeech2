import os
import torch

from typing import List
from logging import Logger

from nvidia.dali import fn
from nvidia.dali import types
from nvidia.dali.pipeline import Pipeline
from nvidia.dali.plugin.base_iterator import LastBatchPolicy
from nvidia.dali.plugin.pytorch import DALIClassificationIterator

from data.builder import DATA
from data.cv.dali import DALIWrapper, INTERPOLATION_MAP


@DATA.register_module(name='dali_image_classification')
class DALIImgClsDataContainer:
    """
    Data container for image classification task.
    The main data processing based on the NVIDIA DALI, see https://github.com/NVIDIA/DALI for details.
    """
    
    # Target image file format.
    FILE_FILTERS =  [
        '*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tif', '*.tiff', '*.pnm', 
        '*.ppm', '*.pgm', '*.pbm', '*.jp2', '*.webp', '*.flac', '*.ogg', '*.wav'
    ]

    def __init__(
        self, num_classes: int, dataset_name: str = None, root_dir: str = None,
        train_file_list: str = None, val_file_list: str = None, train_files: List[str] = None, val_files: List[str] = None,
        labels: List[int] = None, file_filters: List[str] = None, mixup: float = 0., one_hot: bool = False,
        train_batch_size: int = 1, val_batch_size: int = 1, num_threads: int = 5, device_id: int = 0, seed: int = 42,
        interpolation: str = 'bilinear', crop_size: int = 224, crop_padding: int = 32, dali_cpu: bool = False,
        rank: int = 0, world_size: int = 1, channel_last: bool = False, debug: bool = False, logger: Logger = None,
        pad_last_batch: bool = True, train_reader_name: str = 'TrainReader', eval_reader_name: str = 'EvalReader'
    ):
        super().__init__()
        
        # Dataset name
        self.dataset_name = dataset_name or 'Data'

        # For getting dataset info conveniently
        self.train_reader_name = train_reader_name
        self.eval_reader_name = eval_reader_name

        # Num of categories
        self.num_classes = num_classes
        # Mixup alpha
        # Note: we will only apply mixup for training data(see 'get_dataloaders()' for detail)
        self.mixup = mixup
        # Whether to one-hot encoding labels
        # Note: When use mixup, taret must be one-hot encoded
        self.one_hot = one_hot or (mixup > 0.)

        # Data directory
        self.root_dir = root_dir
        self.train_dir = self.val_dir = None
        if train_file_list is None and train_files is None:
            assert root_dir is not None, f"'root_dir' should not be None when '*_file_list' & '*_files' are both None."
            self.train_dir = os.path.join(root_dir, 'train')
            self.val_dir = os.path.join(root_dir, 'val')
            assert os.path.isdir(self.train_dir), f"{self.train_dir} should be a directory that containing training data."
            assert os.path.isdir(self.val_dir), f"{self.val_dir} should be a directory that containing valiadation data."

        # Path to a text file that contains one whitespace-separated filename label pair per line.
        # The filenames are relative to the location of that file or to file_root, if specified.
        self.train_file_list = train_file_list
        self.val_file_list = val_file_list
        # A list of file paths to read the data from. 
        # If file_root is provided, the paths are treated as being relative to it.
        # This argument is mutually exclusive with file_list.
        self.train_files = train_files
        self.val_files = val_files
        assert not (root_dir is None and train_file_list is None and train_files is None), f"'root_dir', '*_file_list' and '*_files' should not be None at the same time!"
        
        # Labels accompanying contents of files listed in '*_files' argument.
        # If not used, sequential 0-based indices are used as labels
        self.labels = labels

        # Data file format
        # A list of glob strings to filter the list of files in the sub-directories of the file_root.
        # This argument is ignored when file paths are taken from file_list or files.
        self.file_filters = file_filters or DALIImgClsDataContainer.FILE_FILTERS

        # Batch size
        self.train_batch_size = train_batch_size
        self.val_batch_size = val_batch_size
        self.pad_last_batch = pad_last_batch

        # Number of CPU threads used by the pipeline
        self.num_threads = num_threads
        # Image crop size
        self.crop_size = crop_size
        self.crop_padding = crop_padding

        assert INTERPOLATION_MAP.get(interpolation), f"'interpolation' should be one of a keyword in: {INTERPOLATION_MAP.keys()}"
        # Interpolation method, it is a str keyword
        self.interpolation = interpolation

        # Id of GPU used by the pipeline
        self.device_id = device_id
        self.dali_device = 'cpu' if dali_cpu else 'gpu'

        # Random seed
        self.seed = seed
        # Local process rank
        self.rank = rank
        # Num of gpus
        self.world_size = world_size

        # Whether to turn on the debug switch
        self.debug = debug
        # Logger for log info
        self.logger = logger

        self.memory_format = torch.channels_last if channel_last else torch.contiguous_format

        self.data= {
            'train': None,
            'validation': None,
            'test': None
        }
        # This method will load the split data(i.e. training, validation, test set)
        self.build_pipelines()

        self.dataloaders = {
            'train': None,
            'validation': None,
            'test': None
        }
    
    def __repr__(self) -> str:
        return self.dataset_name
    
    @classmethod
    def _encode_data(
        cls, file_root=None, file_list=None, files=None, labels=None, file_filters=None, 
        shard_id=0, num_shards=1, shuffle=False, pad_last_batch=True, name='Reader'
    ):
        """
        Namely, reads image files.
        Each shard(gpu/process) only reads(encodes) its own part, and data will be padded so that each 
        shard will have the same counts of samples.

        Note: the encoded data still reamin on cpu.
        """
        
        return fn.readers.file(
            file_root=file_root,
            file_list=file_list,
            files=files,
            labels=labels,
            file_filters=file_filters,
            shard_id=shard_id,
            num_shards=num_shards,
            # Please do shuffle if this is training data.
            random_shuffle=shuffle,
            pad_last_batch=pad_last_batch,
            # Note: set a name for reader is necessary! it is convenient for getting the data info such as:
            # data size, batch size, number of iterations for each shard, etc.
            name=name
        )
    
    @classmethod
    def _decode_data(cls, encoded_data, device='mixed', output_type=types.RGB, dali_device='gpu'):
        """
        Decoding the encoded data, usually convert them to RGB format.
        when 'dali_device' set to 'gpu', decoder will move the data from cpu to gpu if 'device' is set to 'mixed'.
        """
        
        return fn.decoders.image(
            encoded_data,
            device=device,
            output_type=output_type,
            device_memory_padding=211025920,
            host_memory_padding=140544512
        ) if dali_device == 'gpu' else fn.decoders.image(encoded_data, device='cpu', output_type=types.RGB)
    
    @classmethod
    def _build_pipeline(
        cls, batch_size, num_threads, device_id, seed,
        file_root=None, file_list=None, files=None, labels=None,
        file_filters=None, shard_id=0, num_shards=1, pad_last_batch=True, reader_name='Reader',
        crop_size=224, crop_padding=32, interpolation='bilinear', dali_device='gpu', stage='train'
    ):
        """
        Build a data processing pipeline. Including encoding, decoding & data augmentation, etc.
        """
        
        pipeline = Pipeline(
            batch_size=batch_size,
            # Number of CPU threads
            num_threads=num_threads,
            device_id=device_id,
            seed=seed
        )
        with pipeline:
            # Encode
            encoded_images, labels = cls._encode_data(
                name=reader_name,
                file_root=file_root, file_list=file_list, files=files, labels=labels, file_filters=file_filters, 
                shard_id=shard_id, num_shards=num_shards, shuffle=(stage == 'train'), pad_last_batch=pad_last_batch
            )
            # Decode
            images = cls._decode_data(encoded_images, dali_device=dali_device)
            
            # Resize, crop
            if stage == 'train':
                images = fn.random_resized_crop(
                    images,
                    device=dali_device,
                    size=[crop_size] * 2,
                    interp_type=INTERPOLATION_MAP[interpolation],
                    random_aspect_ratio=[0.75, 4.0 / 3.0],
                    random_area=[0.08, 1.0],
                    # Maximum number of attempts used to choose random area and aspect ratio
                    num_attempts=100
                )
            else:
                images = fn.resize(
                    images,
                    device=dali_device,
                    # The length of the shorter dimension of the resized image.
                    resize_shorter=crop_size + crop_padding
                )
            # Crop, flip, normalize
            images = fn.crop_mirror_normalize(
                images,
                device=dali_device,
                dtype=types.FLOAT,
                output_layout=types.NCHW,
                crop=[crop_size] * 2,
                mean=[0.485 * 255, 0.456 * 255, 0.406 * 255],
                std=[0.229 * 255, 0.224 * 255, 0.225 * 255],
                # We only apply flip(horizontally) for training data.
                mirror=fn.random.coin_flip(probability=.5) if stage == 'train' else False
            )
            pipeline.set_outputs(images, labels)
        pipeline.build()

        return pipeline

    def build_pipelines(self):
        """
        Build pipelines for training & validation data.

        Note: It is better to set 'reader_name', cuz we can easily get the reader meta data(e.g. epoch size, etc.)
        """
        
        train_pipe = self._build_pipeline(
            self.train_batch_size, self.num_threads, self.device_id, self.seed, pad_last_batch=self.pad_last_batch,
            file_root=self.train_dir, file_list=self.train_file_list, files=self.train_files,
            labels=self.labels, file_filters=self.file_filters, shard_id=self.rank, num_shards=self.world_size,
            reader_name=self.train_reader_name, crop_size=self.crop_size, interpolation=self.interpolation, dali_device=self.dali_device
        )
        self.logger.info(f"Train data meta:\n{train_pipe.reader_meta(name=self.train_reader_name)}")

        val_pipe = self._build_pipeline(
            self.val_batch_size, self.num_threads, self.device_id, self.seed,
            file_root=self.val_dir, file_list=self.val_file_list, files=self.val_files, pad_last_batch=self.pad_last_batch,
            labels=self.labels, file_filters=self.file_filters, shard_id=self.rank, num_shards=self.world_size,
            crop_size=self.crop_size, crop_padding=self.crop_padding, interpolation=self.interpolation,
            reader_name=self.eval_reader_name, dali_device=self.dali_device, stage='eval'
        )
        self.logger.info(f"Eval data meta:\n{val_pipe.reader_meta(name=self.eval_reader_name)}")

        '''
        Available metadata keys:

        ``epoch_size``:        raw epoch size

        ``epoch_size_padded``: epoch size with the padding at the end to be divisible by the number of shards

        ``number_of_shards``:  number of shards

        ``shard_id``:          shard id of given reader

        ``pad_last_batch``:    if given reader should pad last batch

        ``stick_to_shard``:    if given reader should stick to its shard
        '''

        self.data.update({
            'train': train_pipe,
            'validation': val_pipe
        })

        return self.data

    @staticmethod
    def _get_dataloader(
        pipeline, num_classes, num_shards, reader_name='Reader',
        keys=('data', 'label'), size=-1, pad_last_shard=True,
        one_hot=False, mixup=0., memory_format=torch.contiguous_format
    ):
        """
        Build a dataloader according to the given pipeline.
        """
        
        # Set 'reader_name' in order to get number of samples by: pipeline.epoch_size(name="Reader")
        # dataloader = DALIClassificationIterator(pipeline, reader_name="Reader", fill_last_batch=False)
        dataloader = DALIClassificationIterator(
            pipeline, size=size, reader_name=reader_name,
            last_batch_padded=False, last_batch_policy=LastBatchPolicy.FILL
        )
        # By default, DALI iterator will generate outputs from all pipelines,
        # so we use wrapper here to get only the output of current pipeline.
        return DALIWrapper(
            dataloader, num_classes, num_shards, pad_last_shard=pad_last_shard,
            keys=keys, one_hot=one_hot, mixup=mixup, memory_format=memory_format
        )

    def get_dataloaders(self):
        """
        Build dataloaders for training & validation data.
        
        Note: if turning on the debug swtich, we will only load a subset of data, for quickly verification.
        """
        
        num_train_samples_per_shard = num_val_samples_per_shard = -1
        if self.debug:
            num_samples_per_shard = self.train_batch_size * 10
            # Note: epoch_size() receive a parameter: 'name', when it is not specified, this method will returns a dict
            num_train_samples_per_shard = min(num_samples_per_shard, list(self.data['train'].epoch_size().values())[0])
            num_val_samples_per_shard = min(num_samples_per_shard, list(self.data['validation'].epoch_size().values())[0])
            self.logger.info(
                f"\nDebug: {self.debug}\n"
                f"Select {num_train_samples_per_shard} train samples & {num_val_samples_per_shard} val samples per shard."
            )

        train_reader_name = self.train_reader_name if not self.debug else None
        train_loader = self._get_dataloader(
            self.data['train'], self.num_classes, self.world_size, pad_last_shard=True,
            size=num_train_samples_per_shard, reader_name=train_reader_name, one_hot=self.one_hot, mixup=self.mixup,
            memory_format=self.memory_format
        )
        if self.mixup:
            self.logger.info(f"Note: use mixup(alpha={self.mixup}) augmentation for training data, label will be one-hot encoded\n")

        eval_reader_name = self.eval_reader_name if not self.debug else None
        val_loader = self._get_dataloader(
            self.data['validation'], self.num_classes, self.world_size, pad_last_shard=True,
            size=num_val_samples_per_shard, reader_name=eval_reader_name, one_hot=self.one_hot,
            memory_format=self.memory_format
        )

        self.dataloaders.update({
            'train': train_loader,
            'validation': val_loader
        })
        return self.dataloaders
