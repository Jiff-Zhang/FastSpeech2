import torch
import numpy as np

from nvidia.dali import types

from utils.misc import one_hot_encode


# Map setting str to concrete interpolation method
INTERPOLATION_MAP = {
    "bicubic": types.INTERP_CUBIC,
    "bilinear": types.INTERP_LINEAR,
    "triangular": types.INTERP_TRIANGULAR
}


class DALIWrapper:
    @classmethod
    def mixup_data(cls, data, target, alpha):
        """
        Mixup augmentation.
        Note: target should be one-hot encoded.
        """
        
        c = np.random.beta(alpha, alpha)

        batch_size = data.size(0)
        permuted_indices = torch.randperm(batch_size).to(data.device)

        mixed_data = c * data + (1. - c) * data[permuted_indices]
        mixed_target = c * target + (1. - c) * target[permuted_indices]

        return mixed_data, mixed_target

    @classmethod
    def gen_wrapper(
        cls, dali_iterator, num_classes, keys=('data', 'label',),
        one_hot=False, mixup=0., memory_format=torch.contiguous_format
    ):
        image_key, target_key = keys[:2]
        for all_pipelines_data in dali_iterator:
            data = all_pipelines_data[0]

            image = data[image_key].contiguous(memory_format=memory_format)
            # (b,1)->(b,)
            target = data[target_key].to(image.device).long().squeeze(1)
            if one_hot:
                target = one_hot_encode(target, num_classes, dtype=torch.float, device=target.device)
            if mixup:
                image, target = cls.mixup_data(image, target, mixup)

            yield image, target

        dali_iterator.reset()

    def __init__(
        self, dali_iterator, num_classes, num_shards, pad_last_shard=True,
        keys=('data', 'label',), one_hot=False, mixup=0., memory_format=torch.contiguous_format
    ):
        self.dali_iterator = dali_iterator
        self.num_shards = num_shards
        self.num_classes = num_classes
        self.pad_last_shard = pad_last_shard
        self.keys = keys
        self.mixup = mixup
        # When use mixup, target must be one-hot encoded
        self.one_hot = one_hot or (mixup > 0.)
        self.memory_format = memory_format

    def __iter__(self):
        return DALIWrapper.gen_wrapper(
            self.dali_iterator, self.num_classes, keys=self.keys,
            one_hot=self.one_hot, mixup=self.mixup, memory_format=self.memory_format
        )
    
    @property
    def reader_name(self):
        return self.dali_iterator._reader_name

    @property
    def batch_size(self):
        return self.dali_iterator.batch_size
    
    @property
    def data_size(self):
        return self.dali_iterator._size

    def __len__(self):
        return len(self.dali_iterator)
