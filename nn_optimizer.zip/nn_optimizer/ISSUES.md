I. RuntimeError: CUDA error: no kernel image is available for execution on the device
   1. Checkout your pytorch env:
      ! python -m torch.utils.collect\_env
   2. Check CUDA & corresponding Driver, Pytorch versions:
      https://blog.csdn.net/weixin_42069606/article/details/105198845
   3. Install corresponding Pytorch or CUDA version.
