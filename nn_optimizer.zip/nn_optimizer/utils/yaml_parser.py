
import os
from easydict import EasyDict
import yaml

def yaml_loader(filepath):
    # basedir = os.path.abspath(os.path.dirname(__file__))
    # cfg_path = os.path.join(basedir, config_file)
    if isinstance(filepath, str) and os.path.isfile(filepath):
        with open(filepath) as f:
            cfg = yaml.safe_load(f)
            cfg = EasyDict(cfg)
    else:
        raise ValueError('yaml file does not exist')
    return cfg


