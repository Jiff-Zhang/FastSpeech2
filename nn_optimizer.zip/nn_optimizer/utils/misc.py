import os
import glob
import time
import datetime
import warnings

import torch
import torch.nn as nn

from logging import Logger
from typing import List, Sequence

from getpass import getuser
from socket import gethostname


class Timer:
    """
    A timer as context manager used for computing execution time.
    Example:
        with Timer(logging.logger(), job='Test timer'):
            print('do anything')
        
        # Test timer cost time: 5.316734313964844e-05s
    """
    
    def __init__(self, logger: Logger, job='Job'):
        self.logger = logger
        self.job = job

    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        self.end = time.time()
        self.logger.info(f"{self.job} cost time: {datetime.timedelta(seconds=(self.end - self.start))}s\n")

        # Return false to raise exception to parent
        return False


def one_hot_encode(tensor, num_classes, dtype=torch.float, device='cuda'):
    """
    one-hot encoding.
    """

    if tensor.ndim > 2:
        raise ValueError(f"'tensor' should not have more than 2 dims, but got:{tensor.ndim}")
    if tensor.ndim == 2:
        assert tensor.size(-1) == 1, f"'tensor' size at last dim should be 1, but got:{tensor.size(-1)}"
    index_tensor = tensor if tensor.ndim == 2 else tensor.unsqueeze(1)
    
    one_hot = torch.zeros(tensor.size(0), num_classes, dtype=dtype, device=device)
    one_hot = one_hot.scatter(1, index_tensor, 1.)

    return one_hot


def is_seq_of(seq: Sequence, expected_item_type: type, expected_seq_type: type = None) -> bool:
    """Check whether it is a sequence of some type.
    Args:
        seq (Sequence): The sequence to be checked.
        expected_item_type (type): Expected type of sequence items.
        expected_seq_type (type, optional): Expected sequence type.
    Returns:
        bool: Whether the sequence is valid.
    """

    assert isinstance(expected_item_type, type)

    if expected_seq_type is None:
        expected_seq_type = Sequence
    else:
        assert isinstance(expected_seq_type, type)
    
    if not isinstance(seq, expected_seq_type):
        return False
    
    for item in seq:
        if not isinstance(item, expected_item_type):
            return False
    
    return True


def auto_resume_helper(checkpoint_dir):
    all_checkpoints = [ckp for ckp in os.listdir(checkpoint_dir) 
                       if (ckp.endswith('.pth') or ckp.endswith(".bin"))]
    if not all_checkpoints:
        return None
    
    return max([os.path.join(checkpoint_dir, ckp) for ckp in all_checkpoints], key=os.path.getmtime)


def load_checkpoint(model, optimizer, lr_scheduler, config, logger, root_dir=None):
    if config.resume_path.startswith('https'):
        checkpoint = torch.hub.load_state_dict_from_url(
            config.resume_path, map_location='cpu', check_hash=True
        )
    else:
        # Path to checkpoint can be absolute path or the relative path under the 'model_cards' dir
        path_to_checkpoint = config.resume_path
        if not os.path.exists(path_to_checkpoint):
            root_dir = root_dir or os.path.join(os.path.dirname(__file__), '..')
            path_to_checkpoint = os.path.join(root_dir, path_to_checkpoint)
        checkpoint = torch.load(path_to_checkpoint, map_location='cpu')

    msg = model.load_state_dict(checkpoint['model'], strict=False)
    logger.info(msg)

    if 'optimizer' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer'])
    if 'lr_scheduler' in checkpoint:
        lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
    if 'epoch' in checkpoint:
        config.defrost()
        config.trainer.start_epoch = checkpoint['epoch'] + 1
        config.freeze()
        logger.info(f"=> Resumed from epoch{checkpoint['epoch']}")
    
    metrics = checkpoint.get('metric', {})
    del checkpoint
    
    torch.cuda.empty_cache()

    return metrics


def save_checkpoint(checkpoint_dir, model, optimizer, lr_scheduler, 
                    epoch, model_config, results, tokenizer=None, accelerator=None, best=False):
    os.makedirs(checkpoint_dir, exist_ok=True)

    model_config_dict = model_config.to_dict()
    if getattr(model_config, 'num_labels', None) is not None:
        model_config_dict.update(num_labels=model_config.num_labels)

    save_state = {'model': model.state_dict(),
                  'optimizer': optimizer.state_dict(),
                  'lr_scheduler': lr_scheduler.state_dict(),
                  'epoch': epoch,
                  'model_config': model_config_dict,
                  'metric': results}

    if best:
        # Delete previous checkpoints
        for prev in glob.glob(os.path.join(checkpoint_dir, '*.pth')):
            os.remove(prev)

    # TODO: make this more general
    metric = results.get('accuracy', 0.)
    checkpoint = os.path.join(checkpoint_dir, f'epoch{epoch}-acc{metric:.2f}.pth')
    torch.save(save_state, checkpoint)
    
    return checkpoint


def get_grad_norm(parameters: List[torch.Tensor], norm_type: float = 2.) -> float:
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]
    parameters = [param for param in parameters if param.grad is not None]

    total_norm = 0.
    for param in parameters:
        norm = param.grad.data.norm(p=norm_type).item()
        total_norm += norm ** norm_type
    total_norm = total_norm ** (1. / norm_type)

    return total_norm


def get_host_info():
    """
    Get hostname and username.
    Return empty string if exception raised, e.g. ``getpass.getuser()`` will
    lead to error in docker container
    """

    host = ''
    try:
        host = f'{getuser()}@{gethostname()}'
    except Exception as e:
        warnings.warn(f'Host or user not found: {str(e)}')
    finally:
        return host


def is_method_overridden(method, base_class, derived_class):
    """
    Check if a method of base class is overridden in derived class.

    Args:
        method (str): the method name to check.
        base_class (type): the class of the base class.
        derived_class (type | Any): the class or instance of the derived class.
    """

    assert isinstance(base_class, type), "base_class doesn't accept instance, Please pass class instead."
    # We allow derived class accept an instance
    if not isinstance(derived_class, type):
        derived_class = derived_class.__class__

    base_method = getattr(base_class, method)
    derived_method = getattr(derived_class, method)

    return derived_method != base_method


def cmp_models(m1: nn.Module, m2: nn.Module, strict: bool = True):
    """
    Checkout whether the 2 models are the same object,
    and checkout their parameters are equal to each other one-by-one.
    If strict is True, require two modules are the same object.
    """
    
    if strict and m1 is not m2:
        raise RuntimeError("The 2 models are not the same object.")
    
    m2_named_params = dict(m2.named_parameters())
    m1_named_params = dict(m1.named_parameters())
    for n, p in m1_named_params.items():
        p_ = m2_named_params.get(n)
        if not torch.equal(p, p_):
            raise ValueError(
                f"Model parameter:{n} are different in the 2 models, "
                f"they are:\n{p}\n\n{p_}"
            )
