import inspect

from copy import deepcopy
from typing import Callable, Union, List

from .misc import is_seq_of


class Registry:
    """
    A registry to map strings to classes.
    Registered object could be built from registry.

    Example:
        >>> MODEL = Registry('MODEL')
        >>> @MODEL.register_module(name=RESNET)
        >>> class ResNet:
        >>>     pass
        >>> resnet = MODEL.build(dict(type='RESNET'))

    Args:
        name (str): Registry name.
        build_func(func, optional): Build function to construct instance from
            Registry, func:`default_build_func` is used if ``build_func`` is not specified. Default: None.
    """

    def __init__(self, name: str, build_func: Callable = None):
        self.name = name
        self._module_dict = {}

        if build_func is None:
            self.build_func = Registry.default_build_func
        else:
            assert isinstance(build_func, Callable)
            self.build_func = build_func
    
    @classmethod
    def default_build_func(cls, config: dict, registry, default_args: dict = None) -> object:
        """Build a module from config dict.

        Args:
            config (dict): Config dict. It should at least contain the key "type".
            registry (:obj:`Registry`): The registry to search the type from.
            default_args (dict, optional): Default initialization arguments.

        Returns:
            object: The constructed object.
        """

        # Note: in case of modifying the original config,
        # we do deepcopy here. So, please do not put some shared objects to config,
        # instead, u can put them to default_args.
        args_from_config = deepcopy(config)
        if default_args is not None:
            for k, v in default_args.items():
                args_from_config.setdefault(k, v)

        obj_type = args_from_config.pop('type')
        if isinstance(obj_type, str):
            obj_cls = registry.get(obj_type)
            if obj_cls is None:
                raise KeyError(f"'{obj_type}' is not in {registry}")
        elif inspect.isclass(obj_type) or isinstance(obj_type, Callable):
            obj_cls = obj_type
        else:
            raise TypeError(f"'type' in config must be a str or valid type, but got '{type(obj_type)}'")
        
        try:
            return obj_cls(**args_from_config)
        except Exception as e:
            # Normal TypeError does not print class name.
            raise type(e)(f'{obj_cls.__name__}: {e}')
    
    @property
    def module_dict(self):
        return self._module_dict
    
    def __len__(self):
        return len(self._module_dict)

    def __contains__(self, key):
        return key in self._module_dict
    
    def __repr__(self) -> str:
        return f"[{self.__class__.__name__}] (name={self.name}), (item={self._module_dict})"
    
    def _register_module(self, module_cls, module_name=None, force=False):
        if not (inspect.isclass(module_cls) or isinstance(module_cls, Callable)):
            raise TypeError(f"'module_cls' must be a class or callable, but got '{type(module_cls)}'")

        if module_name is None:
            module_name = module_cls.__name__
        if isinstance(module_name, str):
            module_name = [module_name]
        
        for name in module_name:
            if name in self and not force:
                raise KeyError(f"'{name}' is already registered in {self.name}")
            self._module_dict[name] = module_cls
    
    def register_module(self, name: Union[str, List[str], type] = None, module: Union[type, Callable] = None, force: bool = False):
        """
        Register a module.

        A record will be added to `self._module_dict`, whose key is the specified name or the class
        name if not specified, and value is the class itself.
        It can be used as a decorator or a normal function.

        Example:
            >>> MODEL = Registry('MODEL')
            >>> @MODEL.register_module()
            >>> class ResNet:
            >>>     pass

            >>> @MODEL.register_module(name='MOBILENET')
            >>> class MobileNet:
            >>>     pass

            >>> class YOLOv3:
            >>>     pass
            >>> MODEL.register_module(YOLOv3)

        Args:
            name (str | None): The module name to be registered. If not
                specified, the class name will be used. Default: None
            module (type | Callable): Module class to be registered. Default: None
            force (bool, optional): Whether to override an existing class with
                the same name. Default: False.
        """

        if not isinstance(force, bool):
            raise TypeError(f"force must be a boolean, but got '{type(force)}'")

        if isinstance(name, type):
            return self._register_module(name, force=force)
        
        if not (name is None or isinstance(name, str) or is_seq_of(name, str)):
            raise TypeError(
                f"'name' must be either of None, an instance of str or a sequence of str, but got '{type(name)}'"
            )

        # Use it as a decorator: @x.register_module()
        if module is None:
            def _register(module_cls):
                self._register_module(module_cls, module_name=name, force=force)
                return module_cls
            return _register
        # Use it as a normal method: x.register_module(module=SomeClass)
        else:
            self._register_module(module, module_name=name, force=force)
            return module
    
    def get(self, key):
        """
        Get the registry record.

        Args:
            key (str): The class name in string format.

        Returns:
            class: The corresponding class.
        """

        return self._module_dict.get(key)
    
    def build(self, *args, **kwargs):
        return self.build_func(*args, **kwargs, registry=self)

    @classmethod
    def build_from_external(cls, external: Callable, *args, **kwargs):
        """
        Build an object from external function.

        Example:
            >>> def build_model_func(model_cfg):
            >>>    ...
            >>> MODEL = Registry('model')
            >>> model = MODEL.build_from_external(build_model_func, model_cfg)
        """

        if not isinstance(external, Callable):
            raise TypeError(f"external must be Callable, but got '{type(external)}'")

        return external(*args, **kwargs)
