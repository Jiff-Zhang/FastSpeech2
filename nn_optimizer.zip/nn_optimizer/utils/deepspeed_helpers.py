import os
import deepspeed

from logging import Logger
from typing import Dict, Union

from deepspeed import DeepSpeedEngine

from torch.nn import Module
from torch.optim import Optimizer
from torch.optim.lr_scheduler import _LRScheduler

from yacs.config import CfgNode as CN

from transformers import AutoConfig
from transformers.deepspeed import HfDeepSpeedConfig

from config.cfg import convert_to_dict


def init_hf_dscfg(cfg: CN, model_pretrained_path: str, logger: Logger):
    if getattr(cfg, 'auto_config_with_model_hidden_size', False):
        zero_optim_stage = int(cfg.ds_cfg.zero_optimization.stage)
        if zero_optim_stage > 1:
            # Prefer to use local config file, in case of network problems.
            root = os.path.join(os.path.dirname(__file__), '..')
            config_path = os.path.join(root, f'models/hf_local/{model_pretrained_path}/config.json')
            if os.path.exists(config_path):
                model_config = AutoConfig.from_pretrained(config_path)
                logger.info(f'Note: local config file:{config_path} loaded.')
            else:
                model_config = AutoConfig.from_pretrained(model_pretrained_path)

            d_model = getattr(model_config, 'd_model', 0)
            if d_model:
                cfg.defrost()

                cfg.ds_cfg.zero_optimization.reduce_bucket_size = d_model ** 2
                if zero_optim_stage == 2:
                    cfg.ds_cfg.zero_optimization.allgather_bucket_size = d_model ** 2
                else:
                    cfg.ds_cfg.zero_optimization.stage3_prefetch_bucket_size = 0.9 * (d_model ** 2)
                    cfg.ds_cfg.zero_optimization.stage3_param_persistence_threshold = 10 * d_model

                logger.info(f"Note: config ZeRO optimizer setting with model hidden size.\n")
                cfg.freeze()
            
            del model_config

    deepspeed_cfg = convert_to_dict(cfg.ds_cfg)
    hfds_cfg = HfDeepSpeedConfig(deepspeed_cfg)

    return hfds_cfg


def init_ds_engine(
    model: Module, deepspeed_config: Union[Dict, CN],
    optimizer: Optimizer = None,
    lr_scheduler: _LRScheduler = None,
    teacher: Module = None
):
    ds_cfg_dict = convert_to_dict(deepspeed_config)

    model, optimizer, _, lr_scheduler = deepspeed.initialize(
        model=model,
        optimizer=optimizer,
        lr_scheduler=lr_scheduler,
        config=ds_cfg_dict
    )
    if teacher is not None:
        if ds_cfg_dict.get('zero_optimization') and ds_cfg_dict['zero_optimization']['stage'] == 3:
            teacher = deepspeed.initialize(model=teacher, config=deepspeed_config)[0]
        else:
            # Note: If ZeRO-2, optimizer is always required when using deepspeed.initialize(),
            # so we recommend u to use deepspeed.init_inference() instead.
            teacher = deepspeed.init_inference(teacher)
    
    return model, optimizer, teacher, lr_scheduler


def load_ds_ckpt(
    ds_engine: DeepSpeedEngine, ckpt_dir: str, ckpt_tag: str, logger: Logger, root: str = None,
    load_optimizer_states: bool = True, load_lr_scheduler_states: bool = False, load_module_only: bool = False
):
    if root is not None:
        ckpt_dir = os.path.join(root, ckpt_dir)
    if not os.path.exists(ckpt_dir):
        raise ValueError(f"Checkpoint direcotry:{ckpt_dir} not found.")
    if not os.path.exists(os.path.join(ckpt_dir, ckpt_tag)):
        raise ValueError(f"Checkpoint tag:{ckpt_tag} cannot be found in directory:{ckpt_dir}.")

    ckpt_path, client_sd = ds_engine.load_checkpoint(
        ckpt_dir,
        tag=ckpt_tag,
        load_module_only=load_module_only,
        load_optimizer_states=load_optimizer_states,
        load_lr_scheduler_states=load_lr_scheduler_states
    )
    if ckpt_path:
        logger.info(f"DeepSpeed checkpoint from {ckpt_path} loaded.")
    else:
        logger.warning("DeepSpeed checkpoint loading failed, please checkout your checkpoint directory.")

    return ckpt_path, client_sd


def resume_ds_states(
    cfg: CN,
    ds_engine: DeepSpeedEngine, lr_scheduler: _LRScheduler,
    logger: Logger, root: str = None
):
    # Note: this will automatically load model & optimizer states,
    # nut not lr scheduler cuz we set 'load_lr_scheduler_states=False'
    # this is because we don't wrap lr scheduler by deepspeed when we are in training stage.
    _, client_sd = load_ds_ckpt(
        ds_engine, cfg.deepspeed.ckpt_dir, cfg.deepspeed.ckpt_tag,
        logger, root=root, load_optimizer_states=cfg.deepspeed.load_optimizer_states
    )
    if not client_sd:
        logger.warning("DeepSpeed resuming failed, please checkout your checkpoint directory or any other things related.")
        return

    if 'lr_scheduler' in client_sd and cfg.deepspeed.load_lr_scheduler_states:
        lr_scheduler.load_state_dict(client_sd['lr_scheduler'])
    if 'epoch' in client_sd:
        cfg.defrost()
        cfg.trainer.start_epoch = client_sd['epoch'] + 1
        cfg.freeze()
        logger.info(f"Resumed from epoch{client_sd['epoch']}")

    metrics = client_sd.get('metric', {})
    metrics_info = f"\t[Metrics]:{metrics}\n" if metrics else "\n"
    logger.info(
        f"[Start Epoch]:{cfg.trainer.start_epoch}\t"
        f"[Lr]:{ds_engine.client_optimizer.param_groups[0]['lr']}{metrics_info}"
        f"Done!\n"
    )

    del client_sd
