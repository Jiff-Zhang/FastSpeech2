import os
import json

import numpy as np
from scipy import signal
from scipy.spatial.distance import cosine
import pandas as pd


def get_image_list(image_dir, suffix=None):
    image_list = []
    for root, dirname, filenames in os.walk(image_dir):
        if not filenames:
            continue
        for fn in filenames:
            if suffix is not None:
                if isinstance(suffix, str):
                    suffix = [suffix]
                image_suffix = fn.split(".")[-1]
                if image_suffix not in suffix:
                    continue
            image_list.append(os.path.join(root, fn))
    return image_list


def readlines(filename):
    with open(filename, "r") as f:
        lines = f.read().strip().split("\n")
    return lines


def calc_psnr(x, y, max_val=255.0):
    mse = np.square(x - y).mean()
    return 10 * np.log10(max_val ** 2 / mse)


def matlab_style_gauss2D(shape=(3, 3), sigma=0.5):
    """
    2D gaussian mask - should give the same result as MATLAB's fspecial('gaussian',[shape],[sigma])
    Acknowledgement : https://stackoverflow.com/questions/17190649/how-to-obtain-a-gaussian-filter-in-python (Author@ali_m)
    """
    m, n = [(ss - 1.0) / 2.0 for ss in shape]
    y, x = np.ogrid[-m : m + 1, -n : n + 1]
    h = np.exp(-(x * x + y * y) / (2.0 * sigma * sigma))
    h[h < np.finfo(h.dtype).eps * h.max()] = 0
    sumh = h.sum()
    if sumh != 0:
        h /= sumh
    return h


def calc_ssim(X, Y, sigma=1.5, K1=0.01, K2=0.03, R=255):
    """
    X : y channel (i.e., luminance) of transformed YCbCr space of X
    Y : y channel (i.e., luminance) of transformed YCbCr space of Y
    Please follow the setting of psnr_ssim.m in EDSR (Enhanced Deep Residual Networks for Single Image Super-Resolution CVPRW2017).
    Official Link : https://github.com/LimBee/NTIRE2017/tree/db34606c2844e89317aac8728a2de562ef1f8aba
    The authors of EDSR use MATLAB's ssim as the evaluation tool,
    thus this function is the same as ssim.m in MATLAB with C(3) == C(2)/2.
    """
    gaussian_filter = matlab_style_gauss2D((11, 11), sigma)

    X = X.astype(np.float64)
    Y = Y.astype(np.float64)

    window = gaussian_filter

    ux = signal.convolve2d(X, window, mode="same", boundary="symm")
    uy = signal.convolve2d(Y, window, mode="same", boundary="symm")

    uxx = signal.convolve2d(X * X, window, mode="same", boundary="symm")
    uyy = signal.convolve2d(Y * Y, window, mode="same", boundary="symm")
    uxy = signal.convolve2d(X * Y, window, mode="same", boundary="symm")

    vx = uxx - ux * ux
    vy = uyy - uy * uy
    vxy = uxy - ux * uy

    C1 = (K1 * R) ** 2
    C2 = (K2 * R) ** 2

    A1, A2, B1, B2 = (
        2 * ux * uy + C1,
        2 * vxy + C2,
        ux ** 2 + uy ** 2 + C1,
        vx + vy + C2,
    )
    D = B1 * B2
    S = (A1 * A2) / D
    mssim = S.mean()

    return mssim


def calc_performance(performance_batch_size_list, graph, model_path):
    model_dir = os.path.dirname(model_path)
    performance_results = dict()
    core_list = [1, 4]
    flops = ""
    performance = Performance(graph)
    for batch_size in performance_batch_size_list:
        for core in core_list:
            if core > batch_size:
                continue
            performance_dict = performance.performance(batch_size, core, model_dir)
            GFlops = str(performance_dict["GFlops"])
            MParams = str(performance_dict["MParams"])
            int8_fps = (
                str(round(performance_dict["fps_int8_lower"], 2))
                + "/"
                + str(round(performance_dict["fps_int8_upper"], 2))
            )
            bfloat16_fps = (
                str(round(performance_dict["fps_bf16_lower"], 2))
                + "/"
                + str(round(performance_dict["fps_bf16_upper"], 2))
            )
            util_rate_int8 = str(performance_dict["util_rate_int8"])
            util_rate_bfloat16 = str(performance_dict["util_rate_bf16"])
            key = str(core) + "core" + str(batch_size) + "batch"
            performance_results[key + "_int8_fps"] = int8_fps
            performance_results[key + "_bfloat16_fps"] = bfloat16_fps
            performance_results[key + "_util_rate_int8"] = util_rate_int8
            performance_results[key + "_util_rate_bfloat16"] = util_rate_bfloat16
    performance_results["GFLOPS"] = GFlops
    performance_results["Params(M)"] = MParams
    return performance_results


def init_dataframe(result_info, tasks):
    model_names = [task.model_name for _, task in tasks.items()]
    cur_dataframe = pd.DataFrame(columns=result_info["header"])
    cur_dataframe["model"] = model_names
    cur_dataframe = cur_dataframe.rename(index=cur_dataframe.model)
    if result_info["load_org_result"]:
        org_dataframe = pd.read_csv(result_info["path"])
        org_dataframe = org_dataframe.rename(index=org_dataframe.model)
        cur_dataframe.update(org_dataframe)
        cur_dataframe = pd.merge(cur_dataframe, org_dataframe, how="outer")
        cur_dataframe = cur_dataframe.rename(index=cur_dataframe.model)
    cur_dataframe.fillna("", inplace=True)
    cur_dataframe.loc[cur_dataframe["model"].isin(model_names), "status"] = ""
    return cur_dataframe


def generate_balance_group_mask(shape: list, sparsity=0.0625):
    channels = shape[2]
    R = shape[0]
    S = shape[1]

    non_zero_number = int(channels * sparsity)
    if non_zero_number == 0:
        non_zero_number = 1

    group_mask = np.zeros(shape, dtype=np.int)

    for r in range(R):
        for s in range(S):
            grid_mask = np.zeros(channels, dtype="i1")
            grid_mask[:non_zero_number] = 1
            np.random.shuffle(grid_mask)
            group_mask[r, s, :] = grid_mask

    return group_mask


def generate_balance_block_mask(shape: list, sparsity=0.0625, partitions=8):
    assert len(shape) == 3
    assert (shape[0] == 1) and (shape[1] == 1)

    partition_channels = int(shape[2] / partitions)
    partition_shape = shape[0:2] + [partition_channels]

    mask = np.zeros(shape)

    for pi in range(partitions):
        group_mask = generate_balance_group_mask(partition_shape, sparsity=sparsity)
        for ci in range(partition_channels):
            mask[:, :, ci * 8 + pi] = group_mask[:, :, ci]
    return mask


def generate_balance_weights_mask_for_1x1(
    shape: list, sparsity=0.0625, partitions=8, dtype="int8"
):
    assert len(shape) == 4
    assert (shape[0] == 1) and (shape[1] == 1)

    in_channels = shape[2]
    block_channels = []
    while in_channels:
        if dtype == "int8":
            num_group = 512
        elif dtype == "bf16":
            num_group = 256
        if in_channels > num_group:
            block_channels.append(num_group)
            in_channels = in_channels - num_group
        else:
            block_channels.append(in_channels)
            in_channels = 0

    mask = np.zeros(shape)
    filters = shape[3]

    for fi in range(filters):
        for bi in range(len(block_channels)):
            block_mask = generate_balance_block_mask(
                shape[:2] + [block_channels[bi]],
                sparsity=sparsity,
                partitions=partitions,
            )
            mask[
                :,
                :,
                sum(block_channels[:bi]) : sum(block_channels[:bi])
                + block_channels[bi],
                fi,
            ] = block_mask

    return mask


def generate_balance_weights_mask(
    shape: list, sparsity=0.0625, partitions=8, dtype="int8"
):
    assert len(shape) == 4

    in_channels = shape[2]
    partition_channels = []
    while in_channels:
        if dtype == "int8":
            Cgb = 64
        elif dtype == "bf16":
            Cgb = 32
        if in_channels > Cgb:
            partition_channels.append(Cgb)
            in_channels = in_channels - Cgb
        else:
            partition_channels.append(in_channels)
            in_channels = 0

    partitions = len(partition_channels)

    mask = np.zeros(shape)
    num_filters = shape[3]

    for fi in range(num_filters):
        for pi in range(partitions):
            mask[
                :,
                :,
                sum(partition_channels[:pi]) : sum(partition_channels[:pi])
                + partition_channels[pi],
                fi,
            ] = generate_balance_group_mask(
                shape[0:2] + [partition_channels[pi]], sparsity=sparsity
            )
    return mask


def generate_mask(shape: list, sparsity=0.0625, partitions=8, dtype="int8"):
    if shape[0] == 1 and shape[1] == 1:
        sparse_mask = generate_balance_weights_mask_for_1x1(
            shape, sparsity=sparsity, partitions=8, dtype=dtype
        )
    else:
        sparse_mask = generate_balance_weights_mask(
            shape, sparsity=sparsity, partitions=partitions, dtype=dtype
        )
    return sparse_mask


def generate_balance_sparse_weights(
    shape: list, sparsity=0.0625, partitions=8, r=1.0, dtype="int8"
):
    # weight_tensor = np.random.randint(low=low, high=high, size=shape, dtype='i1')
    # weight_tensor = np.random.normal(loc=0.0, scale=1.0, size=shape)
    weight_tensor = np.random.uniform(low=-0.1, high=0.1, size=shape)

    sparse_mask = generate_mask(
        shape, sparsity=sparsity, partitions=partitions, dtype=dtype
    )

    sparse_weigths = np.multiply(weight_tensor, sparse_mask)
    return sparse_weigths


def cosine_similarity(a, b):
    if type(a) is not np.ndarray:
        a = a.numpy()
    if type(b) is not np.ndarray:
        b = b.numpy()
    a = a.flatten()
    b = b.flatten()
    similarity = cosine(a, b)
    return similarity


def compare_two_data(input1, input2, abs_threshold=5, relative_threshold=0.1):
    if type(input1) is not np.ndarray:
        input1 = input1.numpy()
    if type(input2) is not np.ndarray:
        input2 = input2.numpy()

    indices = list(np.ndindex(input1.shape))
    input1 = input1.flatten()
    input2 = input2.flatten()

    all_equal = all(input1 == input2)
    cnt = 0
    if all_equal:
        return cnt
    if np.isnan(input1).all() and np.isnan(input2).all():
        return cnt

    diff = abs(input1 - input2)
    min_input = np.minimum(abs(input1), abs(input2))
    r_diff = diff / min_input

    if max(r_diff) > relative_threshold and max(diff) > abs_threshold:
        for i in range(len(input1)):
            if diff[i] >= abs_threshold and r_diff[i] >= relative_threshold:
                cnt += 1
                if cnt < 20:
                    logger.warn(
                        "{} {} < == > {} diff:{:.5f} relative_diff:{:.5f}".format(
                            indices[i], input1[i], input2[i], diff[i], r_diff[i]
                        )
                    )
    return cnt
