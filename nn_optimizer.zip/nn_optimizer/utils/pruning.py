import torch


def get_max_prune_rate(in_channel):
    if in_channel <= 8:
        return 0.0
    elif in_channel <= 16:
        return 1 / 2
    elif in_channel <= 32:
        return 3 / 4
    elif in_channel <= 64:
        return 7 / 8
    else:
        return 1.0


def generate_prune_keys(model, model_name):
    prune_keys = set()
    for name, parameter in model.named_parameters():
        # DeBERTa
        if 'deberta' in model_name.lower():
            # FFN
            if ('intermediate.dense.weight' in name or 'output.dense.weight' in name) \
                and ('attention' not in name):
                prune_keys.add(name)
            # Attention
            # Optional: prune all kind of attentions(i.e. pos_proj, pos_q_proj)
            # if 'attention.self.in_proj.weight' in name or 'attention.self.pos_proj.weight' in name \
            #     or 'attention.self.pos_q_proj.weight' in name or 'attention.output.dense.weight' in name:
            if 'attention.self.in_proj.weight' in name or 'attention.output.dense.weight' in name:
                prune_keys.add(name)
        # Bert
        elif 'bert' in model_name.lower():
            # FFN
            if ('intermediate.dense.weight' in name or 'output.dense.weight' in name) \
                and ('attention' not in name):
                prune_keys.add(name)
            # Attention
            if 'attention.self.query.weight' in name or 'attention.self.key.weight' in name or \
                'attention.self.value.weight' in name or 'attention.output.dense.weight' in name:
                prune_keys.add(name)
        # T5
        elif 't5' in model_name.lower():
            # FFN
            if 'DenseReluDense' in name:
                sub_module = ['wi', 'wo']
                for mod_name in sub_module:
                    if f'DenseReluDense.{mod_name}.weight' in name:
                        prune_keys.add(name)
            # Attention
            if 'SelfAttention' in name or 'EncDecAttention' in name:
                sub_module = ['q', 'k', 'v', 'o']
                for mod_name in sub_module:
                    if f'Attention.{mod_name}.weight' in name:
                        prune_keys.add(name)
        # Other cases
        else:
            if 'weight' in name and parameter.ndim >= 2:
                prune_keys.add(name)

    return prune_keys


def test_model_sparsity(model, model_id, logger, eps=0.):
    prune_keys = generate_prune_keys(model, model_id)

    total_params = total_zeros = 0
    layer_sparsity = {}.fromkeys(prune_keys, 0.)

    for n, p in filter(lambda np: np[0] in prune_keys, model.named_parameters()):
        num_ele = torch.numel(p)
        num_zero = (p.abs() <= eps).sum().item()

        sparsity = num_zero / num_ele
        layer_sparsity[n] = sparsity
        logger.info(f"get sparsity:{sparsity} of param:{n}")

        total_params += num_ele
        total_zeros += num_zero
    total_sparsity = total_zeros / total_params
    logger.info(f"Total Sparsity:{total_sparsity}\n")

    return layer_sparsity, total_sparsity
