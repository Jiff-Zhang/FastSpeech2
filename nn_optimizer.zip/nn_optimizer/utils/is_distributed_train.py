import os
import torch


def is_distributed():
    distributed = False
    world_size = 1
    visible_devices = []

    # assert torch.cuda.device_count() > 1, 'no GPU available'

    if_world_size_set = False
    if_visible_set = False
    if 'WORLD_SIZE' in os.environ:
        world_size = int(os.environ["WORLD_SIZE"])
        assert world_size <= torch.cuda.device_count(), 'world_size greater than GPU count'
        if_world_size_set = True
    if "CUDA_VISIBLE_DEVICES" in os.environ:
        visible_devices = [int(i) for i in os.environ["CUDA_VISIBLE_DEVICES"].split(',')]
        # assert len(visible_devices) <= torch.cuda.device_count(), 'visible GPU count greater than GPU count'
        if_visible_set = True

    if if_visible_set == True:
        if if_world_size_set == True:
            assert world_size == len(visible_devices), 'WORLD_SIZE not equal with len of CUDA_VISIBLE_DEVICES'
            if world_size == 1:
                distributed = False
                visible_devices = visible_devices
            else:
                distributed = True
                visible_devices = visible_devices
        else:
            if len(visible_devices) == 1:
                distributed = False
                world_size = 1
                visible_devices = [0]
            else:
                distributed = True
                world_size = len(visible_devices)
                visible_devices = visible_devices
    else:
        distrubuted = False
        world_size = 0
        visible_devices = []
    return [distributed, world_size, visible_devices]


    # if if_world_size_set == True or if_visible_set == True:
    #     if if_world_size_set == True and if_visible_set == False:
    #         if world_size == 1:
    #             distributed = False
    #             visible_devices = [0]
    #         else:
    #             distributed = True
    #             visible_devices = [i for i in range(world_size)]
    #     elif if_world_size_set == True and if_visible_set == True:
    #         assert world_size == len(visible_devices), 'WORLD_SIZE not equal with len of CUDA_VISIBLE_DEVICES'
    #         if world_size == 1: distributed = False
    #         else: distributed = True
    #     elif if_world_size_set == False and if_visible_set == True:
    #         if len(visible_devices) == 1:
    #             distributed = False
    #             world_size = 1
    #         else:
    #             distributed = True
    #             world_size = len(visible_devices)
    # else:
    #     if torch.cuda.device_count() == 1:
    #         distributed = False
    #         world_size = 1
    #         visible_devices = [0]
    #     elif torch.cuda.device_count() > 1:
    #         distributed = True
    #         world_size = torch.cuda.device_count()
    #         visible_devices = [i for i in range(world_size)]
    #     else:
    #         distributed = False
    #         raise ValueError('no GPU available')
   
    # return [distributed, world_size, visible_devices]
