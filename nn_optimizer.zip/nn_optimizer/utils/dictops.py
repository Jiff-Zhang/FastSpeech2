
from easydict import EasyDict


def dict2easydict(din):
    if isinstance(din, dict) ==True:
        return EasyDict(din)
    else:
        raise ValueError('dict to easydict input type error')


def dict_flat(dict_a: dict, dict_o: dict):
    if isinstance(dict_a, dict):
        for key, val in dict_a.items():
            if isinstance(val, dict):
                dict_flat(val, dict_o)
            else:
                dict_o.update({key:val})
    return


def dict_onelayer(dict_a: dict, dict_o: dict):
    return dict_flat(dict_a, dict_o)






