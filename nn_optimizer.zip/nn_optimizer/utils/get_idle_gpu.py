import torch
import os


def get_idle_gpu_list():
    cuda_idx_list = []
    ret = []
    gpu_nums = torch.cuda.device_count()
    if gpu_nums <= 0:
        raise ValueError(r'GPU count less or equal 0')
    if os.environ.get('CUDA_VISIBLE_DEVICES') is None:
        gpu_list = [i for i in range(gpu_nums)]
        for idx, gpu_idx in enumerate(gpu_list):
            key = "no processes are running"
            if key in torch.cuda.list_gpu_processes(gpu_idx):
                ret.append(torch.device('cuda:{}'.format(idx)))
                cuda_idx_list.append(idx)
    else:
        gpu_list = [int(i) for i in os.environ['CUDA_VISIBLE_DEVICES'].split(',')]
        print(f'------------------------------------>gpu_list == {gpu_list}')
        for idx, gpu_idx in enumerate(gpu_list):
            ret.append(torch.device('cuda:{}'.format(idx)))
            cuda_idx_list.append(idx)
    
    return ret, cuda_idx_list
    
def check_idle_gpu_resource():
    if torch.cuda.is_available():
        number_of_gpu = torch.cuda.device_count()
        idle_gpus = []
        for cuda in range(number_of_gpu):
            key = "no processes are running"
            if key in torch.cuda.list_gpu_processes(cuda):
                idle_gpus.append(cuda)
        return idle_gpus, len(idle_gpus)
    else:
        return [], 0

def get_needed_gpu(n:int, specify_gpu_list:list=[]):
    r"""
    n (int) : specify how many gpus which will get from available gpu list
    specify_gpu_list (list): if specify_gpu_list is empty, n available gpu will be returned.
    if specify_gpu_list is not empty, the specify GPU in specify_gpu_list will be returned. example of specify_gpu_list is [2,5,6]
    """
    glist, cuda_idx_list = get_idle_gpu_list()
    ret = []
    if len(specify_gpu_list) == 0:
        if len(glist) <= 0 or len(glist) < n:
            raise ValueError(r'available GPU count is insufficient')
        if n <= 0 or not isinstance(n, int):
            raise ValueError(r'input parameter wrong')
        if os.environ.get('CUDA_VISIBLE_DEVICES') is None:
            ret = [glist[i] for i in range(n)]
            clist = [cuda_idx_list[i] for i in range(n)]
            cuda_idx_list = clist
        else:
            ret = glist
    else:
        if len(glist) <= 0 or len(specify_gpu_list) > len(glist):
            raise ValueError(r'available GPU count is insufficient')
        indexlist = [glist[i].index for i in range(len(glist))]
        for i in range(len(specify_gpu_list)):
            if specify_gpu_list[i] not in indexlist:
                raise ValueError(r'specified GPU is not in available GPU list') 
            else:
                ret.append(torch.device('cuda:{}'.format(specify_gpu_list[i])))
                cuda_idx_list.append(i)
        
    return ret, cuda_idx_list

if __name__ == '__main__':

    l = get_needed_gpu(2)

    aaaaa=0

