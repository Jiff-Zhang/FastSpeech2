import torch


FP16 = torch.float16


def _truncate(tensor, low, high):
    return tensor.sign() * tensor.abs().clamp(min=low, max=high)


def truncate_fp16(module, to_fp16=False):
    FP16_LOW, FP16_HIGH = 5.9e-8, 6.5e4

    # Leaf module
    if not module._modules:
        for name, param in module.named_parameters():
            # Ignore those already fp16 and do not require gradients
            if param.dtype is FP16:
                continue

            try:
                truncated = _truncate(param.detach(), FP16_LOW, FP16_HIGH)
                param.data.copy_(truncated)
                if to_fp16:
                    param.data = param.data.to(FP16)
            except:
                print(f'Exception occured when parameter: {name} convert to fp16.')
                
                import sys
                sys.exit()


def to_fp16(module):
    truncate_fp16(module, to_fp16=True)
