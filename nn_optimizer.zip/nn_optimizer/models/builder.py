import os
import time
import datetime

import torch
import torch.nn as nn

from typing import List
from logging import Logger

from torch.nn.parallel import DistributedDataParallel as DDP

from transformers import AutoModelForSequenceClassification, AutoModelForMultipleChoice, \
    AutoModelForQuestionAnswering, AutoTokenizer, AutoModelForSeq2SeqLM, AutoConfig

from timm import models
from models.custom.resnet import resnet_model_dict
from models.custom.nv_models.resnet import nv_model_dict

from utils.misc import Timer
from utils.registry import Registry


ROOT = os.path.join(os.path.dirname(__file__), '..')

MODEL_TO_KEYS = {
    'image_classification': {'timm':models.__dict__,'custom':resnet_model_dict,'nvidia':nv_model_dict},
    'seq2seq_lm': AutoModelForSeq2SeqLM,
    'multiple_choice': AutoModelForMultipleChoice,
    'question_answering': AutoModelForQuestionAnswering,
    'text_classification': AutoModelForSequenceClassification
}

MODULE_NAME_TO_CLS = {
    'linear': nn.Linear,
    'embedding': nn.Embedding
}


def _set_pt_model_memory_format(model, channels_last=False):
    if hasattr(torch, 'channels_last') and  hasattr(torch, 'contiguous_format'):
        if channels_last:
            memory_format = torch.channels_last
        else:
            memory_format = torch.contiguous_format
        model = model.to(memory_format=memory_format)


def _distributed_wrap_model(model, device_ids=None):
    stream = torch.cuda.Stream()

    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        model = DDP(model, device_ids=device_ids)
    torch.cuda.current_stream().wait_stream(stream)

    return model


_convert_bn_to_sync_bn = nn.SyncBatchNorm.convert_sync_batchnorm


MODEL = Registry('model')


def _build_cv_teacher(teacher_path, model_cls, name,num_classes, device, device_ids, channels_last=False, distributed=False):
    if not os.path.exists(teacher_path):
        parent = os.path.join(os.path.dirname(__file__), '..')
        teacher_path = os.path.join(parent, teacher_path)
    assert os.path.exists(teacher_path), f"path to teacher: '{teacher_path}' not existed"

    teacher = model_cls(pretrained=False)
    if 'resnet' in name and teacher.fc.out_features != num_classes:
        in_features = teacher.fc.in_features
        bias = teacher.fc.bias is not None
        teacher.fc = teacher.fc.__class__(in_features, num_classes, bias=bias)

    teacher_state_dict = torch.load(teacher_path, map_location='cpu')
    teacher_model_dict = teacher_state_dict['model']

    teacher.load_state_dict(teacher_model_dict)
    teacher.to(device)
    _set_pt_model_memory_format(teacher, channels_last=channels_last)
    if distributed:
        teacher = _distributed_wrap_model(teacher, device_ids=device_ids)

    # Note: must set the teacher to eval mode
    teacher.eval()

    return teacher, teacher_model_dict


@MODEL.register_module(name='image_classification')
def build_img_cls_model(
    name, logger, num_classes, task='image_classification',model_source='timm',
    pretrained=True, pretrained_weight=None, distributed=True, rank=0, device_ids=None,
    sync_bn=False, channels_last=False, **kwargs
):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    s = time.time()
    # NoteL: Only main process will load preatrained weight
    model = MODEL_TO_KEYS[task][model_source][name](pretrained=pretrained and rank == 0,
                                                    num_classes=num_classes)
    # TODO: make this more elegant
    # Change the classification head to consitent with 'num_classes'
    # if  model.fc.out_features != num_classes:
    #     in_features = model.fc.in_features
    #     bias = model.fc.bias is not None
    #     model.fc = model.fc.__class__(in_features, num_classes, bias=bias)
    #     logger.warning(f"\nChange model.fc.out_features to: {num_classes}")
    if sync_bn:
        model = _convert_bn_to_sync_bn(model)
    if pretrained_weight:
        logger.info(f"load pretrained weight from {pretrained_weight}")
        model.load_state_dict(torch.load(pretrained_weight,map_location='cpu')['model'])
    model.to(device)

    _set_pt_model_memory_format(model, channels_last=channels_last)
    if distributed:
        model = _distributed_wrap_model(model, device_ids=device_ids)
    used = time.time() - s

    model_tag = f"pretrained " if pretrained else ""
    logger.info(f"=> Build {model_tag}{name} model")
    logger.info(f"{str(model)}\n")
    logger.info(f"=> Load model takes time: {datetime.timedelta(seconds=used)}\n")
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f"=> Number of model parameters: {n_parameters}")
    if hasattr(model, 'flops'):
        flops = model.flops()
        logger.info(f"=> Number of FLOPs: {flops / 1e9}G\n")
    
    return model


def _postprocess_nlp_model(
    model: nn.Module, logger,
    cls_dropout = None, num_labels = None,
    freezed_modules: List[str] = None, **kwargs
):
    # Alter the classifier dropout rate
    if cls_dropout is not None and getattr(model, 'dropout', None):
        if hasattr(model.dropout, 'drop_prob'):
            old_drop_rate = model.dropout.drop_prob
            model.dropout.drop_prob = cls_dropout
        else:
            old_drop_rate = model.dropout.p
            model.dropout.p = cls_dropout
        logger.info(f"\nSet model classifier dropout rate from "
                    f"{old_drop_rate} to {cls_dropout}\n")

        # Also change the value in model config
        # TODO: make this more general
        # Deberta
        if hasattr(model.config, 'cls_dropout'):
            model.config.cls_dropout = cls_dropout
        # BERT
        elif hasattr(model.config, 'classifier_dropout'):
            model.config.classifier_dropout = cls_dropout
        # Other cased
        else:
            pass

    # Change the label mapping of model
    if num_labels is not None:
        if hasattr(model, 'num_labels') and model.num_labels != num_labels:
            model.num_labels = num_labels

        if getattr(model.config, 'num_labels', None) != num_labels:
            model.config.num_labels = num_labels

        if getattr(model, 'classifier', None) and model.classifier.out_features != num_labels:
            logger.warning(f"\nModel classifier does not match the dataset category:\n"
                        f"model output features: {model.classifier.out_features}, dataset number of labels: {num_labels}\n"
                        f"Now, change to consistent with dataset.\n")
            
            in_features, bias = model.classifier.in_features, model.classifier.bias
            model.classifier = model.classifier.__class__(in_features, num_labels, bias=bias is not None)

    # Modules to be freezed
    if freezed_modules:
        freezed_modules_cls = [MODULE_NAME_TO_CLS[module_name] for module_name in freezed_modules]
        logger.info(f"\nNote: These type of modules:{freezed_modules} will be freezed and thus no grad.")

        def no_grad(module):
            if type(module) in freezed_modules_cls:
                module.requires_grad_(False)

        model.apply(no_grad)


@MODEL.register_module(name='nlp')
def build_nlp_model(
    pretrained_id: str, task: str, model_config, logger: Logger,
    pretrained_path: str = None, from_config: bool = False,
    ignore_mismatched_sizes: bool = False, obj: str = 'model', **kwargs
):
    with Timer(logger, job=f'Build {obj}'):
        logger.info(
            f"[Object]: {obj.title()}; [Name]: {kwargs.pop('name', pretrained_id)}; "
            f"[Type]: NLP; [Task]: {task}; [Pretrained Id]: {pretrained_id}\n"
        )

        # Build model
        if from_config:
            logger.warning(
                f"Note: u're building {obj} without pretrained weight, "
                f"please make sure what u're doing."
            )
            # Note: from_config() method will not load pretrained weight!
            model = MODEL_TO_KEYS[task].from_config(model_config)
        else:
            model = MODEL_TO_KEYS[task].from_pretrained(
                pretrained_path or pretrained_id,
                config=model_config, ignore_mismatched_sizes=ignore_mismatched_sizes
            )
        _postprocess_nlp_model(model, logger, **kwargs)

        # Num parameters
        n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
        logger.info(f"[{obj.title()} Params]: {n_parameters}")

        logger.info(f"\n[Model Config]\n{model_config}")
        # Model structure
        logger.info(f"{str(model)}\n")

    return model


@MODEL.register_module(name='tokenizer')
def build_tokenizer(pretrained_id: str, logger: Logger, use_fast: bool = True):
    with Timer(logger, job='Build tokenizer'):
        pretrained_id_or_local_path = pretrained_id

        # TODO: still have a probelm to fix:
        # tokenized samples may not have key:'overflow_to_sample_mapping'
        # although we've set 'return_overflowing_tokens=True' when samples passed to tokenizer
        
        # Prefer to use local files, in case of network problems.
        # local_path = os.path.join(ROOT, f'models/hf_local/{pretrained_id}/')
        # if os.path.exists(local_path):
        #     pretrained_id_or_local_path = local_path
        #     logger.info(f"Note: try to load vocabulary files in directory:'{local_path}' for tokenizer..")
        
        tokenizer = AutoTokenizer.from_pretrained(pretrained_id_or_local_path, use_fast=use_fast)

    return tokenizer


def build_model(cfg, default_args: dict = None):
    return MODEL.build(cfg, default_args=default_args)


MODEL_CONFIG = Registry('model_config')


@MODEL_CONFIG.register_module(name='nlp')
def build_model_config(pretrained_id: str, logger, model_config_path: str = None, num_labels: int = 2):
    # Model config
    if model_config_path is None:
        model_config_path = os.path.join(ROOT, f'models/hf_local/{pretrained_id}/config.json')
    else:
        model_config_path = os.path.join(ROOT, model_config_path)

    if os.path.exists(model_config_path):
        model_config = AutoConfig.from_pretrained(model_config_path, num_labels=num_labels)
        logger.info(f"Note: using local model config:{model_config_path}")
    else:
        model_config = AutoConfig.from_pretrained(pretrained_id, num_labels=num_labels)

    return model_config


def build_model_config(cfg, default_args: dict = None):
    return MODEL_CONFIG.build(cfg, default_args=default_args)
